package p1;

public class Rectangle extends BoundedShape
{

	int w,h;

	public Rectangle()
	{
		this.w=5;
		this.h=5;
	}
	public Rectangle(int w,int h)
	{
		
		this.w=w;
		this.h=h;
	}
	@Override
	public String toString() {
		return "Rectangle [w=" + this.w + ", h=" + this.h + "]";
	}
	@Override
	public double area() 
	{
		System.out.println("Inside Rectangle class area ");
		return this.w*this.h;
	}
	
	
	
}
