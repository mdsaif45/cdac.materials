package p1;
import static java.lang.Math.PI; //static import  

//If we extend abstract class
//Rule: we need to compulsory implement all the abstract methods inside the subclass

public class Circle extends BoundedShape 
{
	double radius;
	public Circle(double radius)
	{
		
		this.radius=radius;
		
	}
	@Override
	public String toString() {
		return "Circle [radius=" + radius +  "]";
	}
	@Override
	public double area() 
	{
		System.out.println("Inside Circle class Area");
		return PI*radius*radius;
	}
	
	
}
