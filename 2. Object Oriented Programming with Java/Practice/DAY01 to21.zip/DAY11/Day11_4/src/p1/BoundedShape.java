package p1;

//if any class consist of abstract methods we have to make class as abstract
// Abstract classes consist of abstract method declarations
//and it may also consist of concrete methods too 

public abstract class BoundedShape 
{
	int x,y;
	public BoundedShape()
	{
		this.x=5;
		this.y=5;
	}
	
	public BoundedShape(int x,int y)
	{
		this.x=x;
		this.y=y;
	}
	@Override
	public String toString() {
		return "BoundedShape [x=" + x + ", y=" + y + "]";
	}
	
	//add a common method in the super class 
	// we will provide only method declaration
	
	public abstract double area();
	
	

}
