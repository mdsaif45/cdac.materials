package p1;

public class Square extends BoundedShape
{
	double side; //0.0  
	int x,y; //0 0 
	//NOTE : x and y are considered here to demonstrate how we can call x and y from the paramatrized constructor of sub class to super class 
	public Square()
	{
		this.side=5;
	
	}
	public Square(int x,int y,double side)
	{
		super(x,y);//this will call super class paramatrized constructor 
		this.side=side;
	}
	@Override
	public double area() 
	{
		System.out.println("Inside Sqaure area method ");
		return side*side;
	}
	@Override
	public String toString() {
		return "Square [side=" + side + super.toString() +"]";
	}
	
	
	

}
