package p2;
import p1.BoundedShape;
import p1.Rectangle;
import p1.Square;
import p1.Circle;

//import p1.*;

public class Day11_4 {

	public static void main(String[] args) 
	{
		BoundedShape []shape= {new Circle(5),new Rectangle(4,4),new Square(6,7,8)};
		//shape is an array of reference 
		
			
		for(BoundedShape s:shape) //s = shape[0]  circle   s=shape[1] Rectangle s=shape[2] Sqaure 
			{
				System.out.println(s); //toString()
				System.out.println("Area = "+s.area());
			}
	}

}
