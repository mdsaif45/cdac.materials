

class Machine
{
	public void start()
	{
		System.out.println("inside machine start method");
	}
}

class Laptop extends Machine
{
	public void start()
	{
		super.start();
		System.out.println("inside laptop start method");
	}
	
	public void stop()
	{
		System.out.println("inside stop method of laptop");
	}
	
	
}

public class Day11_1 
{

	public static void main(String[] args)
	{
		Machine m1=new Machine();
		Laptop l1=(Laptop)m1; //ClassCastException
		
		Machine m2=new Laptop();//UPCASTING 
		Laptop l2=(Laptop)m2; //VALID //DOWNCASTING 
		l2.start();
		l2.stop();
		
		Machine m3=new Laptop();//upcasting
		m3.start(); //laptop class start() internally go to start() of Machine (because super is used ) 
		
		//Laptop l4=new Machine(); // javac error 
		
		
		
		
	}
}

/*

public class Day11_1 
{

	public static void main(String[] args)
	{
		Machine m3=new Laptop(); //UPCASTING 
		Laptop l1=(Laptop) m3; //DOWNCASTING 
		//m3 is reference of super class
		// Laptop l1 is reference of sub class
		// super class ref is stored in sub class 
		// DOWNCASTING 
		l1.start(); //will call start() from Laptop 
		//since super() is written so eventually it will give a call to start() of super class also 
		l1.stop();
		System.out.println(l1);
		System.out.println(m3);
		
	}
}
*/


/*
public class Day11_1 {

	public static void main(String[] args)
	{
			
		Laptop lobj=new Laptop();
				
		Machine m2=lobj; // UPCASTING 
		//m2 is reference of super class
		//which is holding object of subclass 
		
		//Machine m2=new Laptop(); 
		m2.start(); //call to overrridden method is done which is from sub class 
		
		//m2.stop(); // NO INVALID //javac error 
		//stop() is not overridden method 
	}

}

*/


/*

public class Day11_1 {

	public static void main(String[] args)
	{
		Machine mobj=new Machine();
		mobj.start(); //start() is called from Machine class 
		
		Laptop lobj=new Laptop();
		lobj.start();
		lobj.stop();
		
		Machine m2=lobj; // UPCASTING 
		//m2 is reference of super class
		//which is holding object of subclass 
		
		//Machine m2=new Laptop(); 
		m2.start(); //call to overrridden method is done which is from sub class 
		
	}

}
*/