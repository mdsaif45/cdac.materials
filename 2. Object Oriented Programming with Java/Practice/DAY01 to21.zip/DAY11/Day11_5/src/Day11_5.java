
//interface declaration

interface Polygon
{
	public void getName();
	public void getNumberofSides();
	public void getArea();
	
}

class Rectangle implements Polygon
{

	@Override
	public void getName() 
	{
		System.out.println("RECTANGLE");
		
	}

	@Override
	public void getNumberofSides() 
	{
		System.out.println("FOUR SIDES");
		
	}

	@Override
	public void getArea() 
	{
		System.out.println("AREA RECTANGLE "+(5*3));
		
	}
	
}

class Square implements Polygon
{

	@Override
	public void getName() {
		System.out.println("Square");
		
	}

	@Override
	public void getNumberofSides() {
		System.out.println("Four Sides");
		
	}

	@Override
	public void getArea() {
		System.out.println("Square Area = "+(9*9));
		
	}
	
}

public class Day11_5 
{

	public static void main(String[] args)
	{
		
		Polygon p[]= {new Rectangle(),new Square()};
		// array of references of type Interface Polygon
		for(Polygon ply:p)
		{
			ply.getName();
			ply.getNumberofSides();
			ply.getArea();
		}	
		
		
	
	}

}


/*
public class Day11_5 
{

	public static void main(String[] args)
	{
		
		Rectangle r=new Rectangle();
		r.getName();
		r.getNumberofSides();
		r.getArea();
		
		Square s=new Square();
		s.getName();
		s.getNumberofSides();
		s.getArea();
		
	
	}

}

*/
