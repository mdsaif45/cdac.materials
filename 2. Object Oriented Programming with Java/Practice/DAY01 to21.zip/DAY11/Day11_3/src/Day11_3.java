import java.util.Scanner;

class Demo
{
	int n1;
	int n2;
	Demo()
	{
		
	}
	Demo(int n1,int n2)
	{
		this.n1=n1;
		this.n2=n2;
	}
}
public class Day11_3 {

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		Demo d1=new Demo(40,20);
		Demo d2=new Demo(sc.nextInt(),sc.nextInt());
		
	}
}


/*
 class Demo
 
{
	Demo()
	{
		System.out.println("parameterless constructor");
	}
	void disp()
	{
		System.out.println("inside disp method");
	}
}
public class Day11_3 {

	public static void main(String[] args) 
	{
		new Demo(); //anonymous object //valid 
		Demo d1=new Demo();
		d1.disp();
		
		new Demo().disp(); // VALID 
	
		
		System.out.println(new String("Sunbeam"));
		
		String str=new String("Sunbeam");
		System.out.println(str);
		
		
		
	}

}

*/
