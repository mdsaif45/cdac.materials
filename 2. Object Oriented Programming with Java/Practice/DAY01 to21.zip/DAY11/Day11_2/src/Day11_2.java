
//Nested Class

class Outer //Outer.class 
{
	Outer()
	{
		System.out.println("Inside Outer class parameterlss constructor ");
	}
	class Inner //Outer$Inner.class
	{
		Inner()
		{
			System.out.println("Inside Inner class parameterlss constructor ");
		}
	}
}
public class Day11_2  //Day11_2.class
{

	public static void main(String[] args) 
	{
		Outer o1=new Outer(); //create object of outer class 
		Outer.Inner i1=o1.new Inner(); //create object of inner class
	}

}
