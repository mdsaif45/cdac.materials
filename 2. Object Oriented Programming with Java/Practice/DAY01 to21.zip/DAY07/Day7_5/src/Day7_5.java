import java.util.Arrays;
import java.util.Scanner;

//Array and functions 
public class Day7_5 
{

	static Scanner sc=new Scanner(System.in);
	
	static void accept_arr(int arr[])
	{
		System.out.println("Enter Array Elements ");
		for(int i=0;i<arr.length;i++)
			arr[i]=sc.nextInt();
	}
	
	static void disp_arr(int arr[])
	{	
		System.out.println("\n Array Elements are ");
		for(int i=0;i<arr.length;i++)
			System.out.print(" "+arr[i]);
		//System.out.println();
		//for(int i:arr)
			//System.out.print(" "+i);
		//System.out.println();
		//System.out.println(Arrays.toString(arr));
		
		
	}
	
	static void sum(int a1[],int b1[])
	{
		int c[]=new int[5];
		for(int i=0;i<5;i++)
			c[i]=a1[i]+b1[i];
		System.out.println("\n Addition of two arrays are ");
		System.out.print(Arrays.toString(c));
	}
	
	public static void main(String[] args) 
	{
		int a[]=new int[5];
		int b[]=new int[5];
		System.out.println("Enter A array Data ");
		accept_arr(a);
		System.out.println("Enter B array Data ");
		accept_arr(b);
		
		System.out.println("Diplaying A array Data ");
		disp_arr(a);
		System.out.println("Diplaying B array Data ");
		disp_arr(b);
		
		sum(a,b);
		

	}

}
