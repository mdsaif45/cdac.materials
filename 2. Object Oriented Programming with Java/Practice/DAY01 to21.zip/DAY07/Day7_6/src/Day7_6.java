import java.util.Arrays;
import java.util.Scanner;

//Array and functions 
public class Day7_6 
{

	static Scanner sc=new Scanner(System.in);
	
	static void accept_arr(int arr[])
	{
		if(arr!=null)
	{
		System.out.println("Enter Array Elements ");
		for(int i=0;i<arr.length;i++)
			arr[i]=sc.nextInt();
	}
		else
			System.out.println("Array is declared as null");
	}
	
	static void disp_arr(int arr[])
	{	
		if(arr!=null)
		{
			
		
		System.out.println("\n Array Elements are ");
		for(int i=0;i<arr.length;i++)
			System.out.print(" "+arr[i]);
		
		}
		else
			System.out.println("Array is null can not display elements ");
		
		
	}
	
	
	
	public static void main(String[] args) 
	{
		int a[]=null;
		int b[]=null;
		accept_arr(a);
		accept_arr(b);
		
		
		disp_arr(a);
		
		disp_arr(b);
		

		

	}

}
