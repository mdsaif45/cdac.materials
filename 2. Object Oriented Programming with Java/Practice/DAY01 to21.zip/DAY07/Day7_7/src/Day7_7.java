import java.util.Arrays;
import java.util.Scanner;

class Employee
{
	String name;
	int age;
	float salary;
	
	Employee()
	{
		
	}

	public Employee(String name, int age, float salary) {
		
		this.name = name;
		this.age = age;
		this.salary = salary;
	}


	
	void accept()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Name : ");
		this.name=sc.next();
		System.out.println("Enter Age : ");
		this.age=sc.nextInt();
		System.out.println("Enter Salary : ");
		this.salary=sc.nextFloat();
		
	}
	
	void disp()
	{
		System.out.println("Name ="+this.name+" Age = "+this.age+" Salary = "+this.salary);
	}
}

public class Day7_7 
{

	public static void main(String[] args) 
	{
		Employee e[]=new Employee[3];
		//allocate the memory for each reference
		
		for(int i=0;i<3;i++)
			e[i]=new Employee(); //e[0] = new Employee() e[1]=new Employee()....
		
		for(int i=0;i<3;i++)
			System.out.println(e[i]); //e[i].toString()
		//accept the data for each object
		
		for(int i=0;i<3;i++)
			e[i].accept();
		//display the data for each object
		
		//for each Employee emp inside e array 
		//display each emp
		for(Employee emp:e)
			emp.disp();
		//for(int i=0;i<3;i++)
			//e[i].disp();
	}
}
	



/*
public class Day7_7 
{

	public static void main(String[] args) 
	{
		Employee e[]=new Employee[5];
		System.out.println(e);
		System.out.print(Arrays.toString(e));
		System.out.println();
		for(int i=0;i<5;i++)
			e[i].accept(); //NPE 
		
		for(int i=0;i<5;i++)
			e[i].disp(); // NPE 
		
	}
}

*/




/*
public class Day7_7 {

	public static void main(String[] args) 
	{
		Employee e[]=new Employee[5]; 
		//System.out.println(e); // hashcode//[LEmployee;@41a4555e ==> L means it is of non-primitive type
		//System.out.println(Arrays.toString(e)); // null null null null null
		
		//for(int i=0;i<5;i++)
			//System.out.print(" " +e[i]); // null null null null null
		
		//for each Employee 'emp' inside array 'e'
		//print the data 
		//emp = e[0]
		//emp = e[1]
		//emp = e[2]
		//emp = e[3]
		//emp = e[4]
		for(Employee emp:e)
			System.out.print(" "+emp); // null null null null null

	}

}

*/

/*
public class Day7_7 {

	public static void main(String[] args) 
	{
		Employee e1=new Employee(); //e1 is reference type
		e1.accept();
		e1.disp();
		

	}

}
*/