import java.time.LocalDate;

class Date
{
	int dd;
	int mm;
	int yy;
	
	Date()
	{
		
		LocalDate dt=LocalDate.now(); //returns object of type LocalDate 
		this.dd=dt.getDayOfMonth();
		this.mm=dt.getMonthValue();
		this.yy=dt.getYear();
	
	}

	@Override
	public String toString() {
		return "Date [dd=" + dd + ", mm=" + mm + ", yy=" + yy + "]";
	}
	
	
	
}


public class Day7_8 {

	public static void main(String[] args) 
	{
		Date[] d=new Date[3]; // array of reference of type Date
		
		//d[0] = null    //d[0] reference type 
		// d[1] = null    //d[1] reference type 
		//d[2] = null     //d[2] reference type 
		
		System.out.println(d);
		for(int i=0;i<3;i++)
			System.out.println(d[i]); //d[i].toString()
		
		// allocate the memory for each reference 
		for(int i=0;i<3;i++)
			d[i]=new Date();
		
		// d[0] = new Date(); //d[0] reference is holding the object of type Date
		//d[1] = new Date();
		//d[2] = new Date();
		
		
 		//for(int i=0;i<3;i++)
			//System.out.println(d[i]);
		
		//for each dobj of type Date inside the array d
		// print dobj 
		for(Date dobj:d)
			System.out.println(dobj);
		
		

	}

}



/*
public class Day7_8 {

	public static void main(String[] args) 
	{
		Date d1=new Date(); // d1 is object 
		//reference type of Date class 
		System.out.println(d1);
		

	}

}

*/
