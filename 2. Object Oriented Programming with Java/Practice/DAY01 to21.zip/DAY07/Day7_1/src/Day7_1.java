
//valid and invalid declarations of an array 

public class Day7_1 {

	public static void main(String[] args)
	{
		int arr1[]=null; //OK VALID 
		int []arr2=null; // valid
		//int [arr2]=null; // INVLAID 
		int arr3[]=new int[5];// VALID 
		int []arr4 = new int[10]; //VALID 
		//int arr5[3]; //INVALID 
		int arr5[]; // VALID (Declaration) 
		arr5=new int[6]; // defining 
		
		int arr6[]; // null reference // array is not yet initialized 
		System.out.println(arr6); //local variable may not be initialized 
		
		int arr7[]=new int[-4];		
		//java.lang.NegativeArraySizeException
		
		int arr8[]=new int[] {1,2,3}; // intialization of array elements 
		//int arr9[] = new int[5] {1,2,3}; // INVALID 
	
		//int arr9[]=new int[3] {1,2,3}; //INVALID
		
		
		int arr10=new int[3]; // invalid 
		//arr10 is value type hold one value 
		int arr11[]=new [5];  // invalid 
		
		int arr12[]=new int[5];//valid 
		
	
	}

}
