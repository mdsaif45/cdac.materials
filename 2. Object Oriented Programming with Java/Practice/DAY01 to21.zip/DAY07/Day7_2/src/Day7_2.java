
public class Day7_2 
{

	public static void main(String[] args) 
	{
		int arr1[]=new int[4] ; 
		for(int i=0;i<arr1.length;i++)
			System.out.print("  "+arr1[i]);
	}
}


/*
public class Day7_2 
{

	public static void main(String[] args) 
	{
		int arr1[]=new int[] {1,2,3,4}; 
		for(int i=0;i<4;i++)
			System.out.print("  "+arr1[i]);
	}
}
*/


/*
public class Day7_2 
{

	public static void main(String[] args) 
	{
		int arr1[]=new int[5] {1,2,3,4}; // javac error
		for(int i=0;i<4;i++)
			System.out.print("  "+arr1[i]);
	}
}
*/

/*
  // Partial initialization is done
   // remaining elements are getting the default value based upon type of an array 
public class Day7_2 {

	public static void main(String[] args) 
	{
		float arr1[]=new float[4];
		
		arr1[0]=10.5f;
		arr1[1]=20.5f;
		arr1[2]=30.5f;
		
		for(int i=0;i<4;i++)
			System.out.print("  "+arr1[i]);

	}

}
*/


/*

public class Day7_2 {

	public static void main(String[] args) 
	{
		int arr1[]=new int[5];
		//array of primitive type //array can hold primitive values 
		//array of value type // array can hold primitive values 
		//arr1 is reference type // arr1 name of an array pointing to arr1 location
		
		
		arr1[0]=10;
		arr1[1]=20;
		arr1[2]=30;
		
		for(int i=0;i<5;i++)
			System.out.print("  "+arr1[i]);

	}

}

*/


/*
public class Day7_2 {

	public static void main(String[] args) 
	{
		int arr1[]=new int[5];
		arr1[0]=10;
		arr1[1]=20;
		arr1[2]=30;
		arr1[3]=40;
		arr1[4]=50;
		for(int i=0;i<5;i++)
			System.out.print("  "+arr1[i]);

	}

}

*/
