import java.util.Arrays;

public class Day7_3 
{

	public static void main(String[] args) 
	{
		int arr[]=new int[] {11,22,33,44};
		float farr[]=new float[] {1.1f,2.2f,3.3f,4.4f};
		//System.out.println(Arrays.toString(arr));
		
		//System.out.println(Arrays.toString(farr));
		
		for(int i:arr)
			System.out.print(" "+i);
		
		System.out.println();
		for(float f:farr)
			System.out.print(" "+f);
		
	}
}


/*

//arrayname.toString() ===> it will display hashcode
//Arrays.toString(arrayname) ==> it will display array contents 

public class Day7_3 
{

	public static void main(String[] args) 
	{
		int arr[]=new int[] {11,22,33,44};
		System.out.println(arr); //arr.toString() 
		System.out.println("printing elements using for loop");
		for(int i=0;i<arr.length;i++)
			System.out.print(" "+arr[i]);
		System.out.println("\n Displaying the elements using Arrays.toString ");
		
		System.out.print(Arrays.toString(arr));
		
		System.out.println("\n Prining array elements using for each loop");
		
		//for each element of type integer 'i' inside array arr
		//display each element 
		//i=arr[0] i=arr[1] i=arr[2] i=arr[3] .... i=arr[lenght-1] 
		for(int i:arr)
			System.out.print(" " +i);
		
	}
}
*/

/*
public class Day7_3 
{

	public static void main(String[] args) 
	{
		int a[]=new int[5];
		boolean b[]=new boolean[5];
		char c[]=new char[5];
		double d[]=new double[5];
		float f[]=new float[5];
		
		
		System.out.println("Printing a ="+a+"  "+a.toString()); 
		System.out.println("Printing b ="+b); 
		System.out.println("Printing c ="+c); 
		System.out.println("Printing d ="+d); 
		System.out.println("Printing f ="+f); 
		
		System.out.println("Printing a class ="+a.getClass()); 
		System.out.println("Printing b class ="+b.getClass()); 
		System.out.println("Printing c class ="+c.getClass()); 
		System.out.println("Printing d class ="+d.getClass()); 
		System.out.println("Printing f class ="+f.getClass()); 
		
		System.out.println("Printing a class ="+a.getClass().getName()); 
		
	}
}

*/

/*
//when we call toString() on name of an array 
// toString() gets called from Object class

public class Day7_3 {

	public static void main(String[] args) 
	{
		int a[]=new int[4];
		a[0]=11;
		a[1]=22;
		a[2]=33;
		a[3]=44;
		System.out.println("Length of an array = "+a.length);
		System.out.println("Printing a ="+a); // a.toString()
		// [I@hashcode
		// [ ==> indicates its an array of 1D type 
		// I ==>indicates Integer type of values
		System.out.println("calling to string "+a.toString());
		
	}

}

*/
