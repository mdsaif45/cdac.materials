import java.util.Scanner;

public class Day7_4 {

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		int n;
		System.out.println("enter number of elements you wish to insert in array ");
		n=sc.nextInt();
		int arr[]=new int[n];
		System.out.println("Enter Array elements ");
		for(int i=0;i<arr.length;i++)
			arr[i]=sc.nextInt();
		
		System.out.println("\n Array elements are ");
		for(int i:arr)
			System.out.print(" " +i);


	}

}



/*
public class Day7_4 {

	public static void main(String[] args) 
	{
		int arr[]=new int[5];
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Array elements ");
		for(int i=0;i<arr.length;i++)
			arr[i]=sc.nextInt();
		System.out.println("\n Array elements are ");
		for(int i:arr)
			System.out.println(i);


	}

}

*/
