//Garbage collection / finalize() 



class Test
{
	public Test()
	{
		System.out.println("Inside Constructor of Test class");
	}
	
	public void print()
	{
		System.out.println("Inside print of Test class");
	}
	
	@Override
	public void finalize()
	{
		System.out.println("Inside Finalize method "+this);
		Thread th=Thread.currentThread();
		System.out.println(th.getName());
		System.out.println(th.getState());
		
	}
	
}

public class Day21_8 {

	public static void main(String[] args)
	{
		
		Test t=new Test();
		t.print();
		System.out.println(t);
		t=null; // Compulsory Statement 
		System.gc();//Requesting the compiler to invoke Garbage Collection
	}

}
