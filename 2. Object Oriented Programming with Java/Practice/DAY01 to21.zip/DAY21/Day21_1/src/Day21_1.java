import java.util.Arrays;
import java.util.List;



//lambda expression with one local variable declaration
public class Day21_1 
{

	public static void main(String[] args) 
	{
		List<Integer> l1=Arrays.asList(1,2,3);
		
		l1.forEach(x->{
			int y=x*4;
			System.out.println(y);
		});
	}
}


/*
//multiline lambda expression
public class Day21_1 
{

	public static void main(String[] args) 
	{
		List<Integer> l1=Arrays.asList(1,2,3);
		l1.forEach(x->{
			x+=5;
			System.out.println(x);
		});
	}
}
*/


/*
public class Day21_1 
{

	public static void main(String[] args) 
	{
		List<Integer> l1=Arrays.asList(1,2,3);
		
		//System.out.println(l1);
		
		//imperative style of programming 
		
		//for(Integer ele:l1) //for each loop 
			//System.out.print(ele+" ");
		
		//imperative style of programming 
		
		//for(int i=0;i<l1.size();i++)
			//System.out.print(" " +l1.get(i));
		
		//Declarative style of programming 
		l1.forEach(x->System.out.println(x));
		// functional programming with lambda expression
	
		//(arguments) -> //code for implementation
		
		
	}

}
*/
