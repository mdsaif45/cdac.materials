import java.util.Arrays;
import java.util.List;

public class Day21_3 
{
	public static void main(String[] args) 
	{
		List<Integer> l1=Arrays.asList(10,20,30);
		//System.out.println(l1); //l1.toString() imperative
		
		//for(int i=0;i<l1.size();i++)
			//System.out.println(l1.get(i)); //imperative
	
		//for(Integer i:l1) //imperative 
			//System.out.println(i);
		
		//declarative 
		//l1.forEach(x->System.out.println(x));
		
		//Method Reference
		l1.forEach(System.out::println);
		//:: colon colon (double colon) operator 
	
	}
}

/*
interface Name // Functional interface
{
	public String getName(); //method declaration (abstract) 
}

public class Day21_3 
{
	public static void main(String[] args) 
	{
		//Method Reference 
		Name n = ()->{return "Hello Everyone!";};
		System.out.println(n.getName());
	}
}
*/


/*
// Sqaure interface is called as Functional Interface
// because it consist of only one abstract method declaration

// Method Reference 

// if we are implementing lambda expression for method implementations 
//then there is no need to write implements keyword 


interface Square
{
	public int getArea(int side); //abstract 
}

public class Day21_3 
{
	public static void main(String[] args) 
	{
		Square area=(side)->{return side*side;};
		
		//area is reference variable of interface Square
		
		System.out.println("Area of sqaure : "+area.getArea(5));
		
		
	}
}

*/
