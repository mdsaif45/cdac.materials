class One extends Thread
{
	public synchronized void run()
	{
		
		try {
			System.out.println("ONE");
			Thread.sleep(1500);
		 } 
		catch (InterruptedException e) {
			
			e.printStackTrace();
		}
	}

}



class Two extends Thread
{
	public synchronized void run()
	{
		
		try {
			System.out.println("TWO");
			Thread.sleep(1500);
		 } 
		catch (InterruptedException e) {
			
			e.printStackTrace();
		}
	}
}

public class Day21_9 {

	public static void main(String[] args) throws InterruptedException 
	{
		One o1=new One();
		Two t1=new Two();
		
		
		One o2=new One();
		Two t2=new Two();
		
		One o3=new One();
		Two t3=new Two();
		
		One o4=new One();
		Two t4=new Two();
		
		o1.start();
		
		t1.start();
		o2.start();
		
		t2.start();
		
		o3.start();
		t3.start();
		o4.start();
		t4.start();
		
		

	}

}
