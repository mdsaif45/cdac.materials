
//Day21_7 is implementing Runnable interface
//so we must override run() 


public class Day21_7 implements Runnable
{

	@Override
	public void run() 
	{
		System.out.println("Inside Run method thread is running");
		
	}

	
	public static void main(String[] args) 
	{
		Day21_7 obj=new Day21_7(); 
		//obj is Object of Day21_7 class implementing Runnable
		// obj can be considered as a reference variable of Runnable
		//interface 
		
		//is obj is Thread Object??? NO
		
		//obj.start(); // NOT ALLOWED 
		//start() is inside Thread class. start() is non static 
		// to call start() we need Thread object 
	
		//Requirement : to make runnable object  as Thread Object
		//solution use the constructor who can take parameter as runnable object 
		// Thread(Runnable target)
		Thread t=new Thread(obj);
		//t is Thread object 
		t.start(); //==> will call run() method 
		
		
	}

	
}
