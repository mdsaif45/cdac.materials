

public class Day21_5 extends Thread
 
{
	String name;
	Day21_5(String name)
	{
		this.name=name;
	}

	public void run()
	{
		
		for(int i=0;i<5;i++)
		{
			System.out.println("Printing "+this.getName()+" : "+i);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	
	}
	
	public static void main(String[] args) throws InterruptedException 
	{
		Day21_5 obj1=new Day21_5("First"); 
		obj1.start();
		Thread.sleep(2000);
		Day21_5 obj2=new Day21_5("Second"); 
		obj2.start();
		Thread.sleep(2000);
		Day21_5 obj3=new Day21_5("Third"); 
		obj3.start();
		Thread.sleep(2000);
		Day21_5 obj4=new Day21_5("Fourth"); 
		obj4.start();
		Thread.sleep(2000);
		
	}

}


/*
 public class Day21_5 extends Thread
 
{
	String name;
	Day21_5(String name)
	{
		this.name=name;
	}

	public void run()
	{
		
		System.out.println("Thread is running now "+this.name);
	
	}
	
	public static void main(String[] args) throws InterruptedException 
	{
		Day21_5 obj1=new Day21_5("First"); 
		obj1.start();
		Thread.sleep(2000);
		Day21_5 obj2=new Day21_5("Second"); 
		obj2.start();
		Thread.sleep(2000);
		Day21_5 obj3=new Day21_5("Third"); 
		obj3.start();
		Thread.sleep(2000);
		Day21_5 obj4=new Day21_5("Fourth"); 
		obj4.start();
		Thread.sleep(2000);
		
	}

}

*/

/*
public class Day21_5 extends Thread
{

	public void run()
	{
		System.out.println("Thread is running now "+this);
	}
	
	public static void main(String[] args) 
	{
		Day21_5 obj1=new Day21_5(); //obj is Thread Object 
		// because obj is object of class Day21_5 and it is 
		//extended from Thread class
		
		//Rule : if we want to start the execution of any thread
		//we should explicitly call start() 
		// start() will call run() implicitly 
		
		obj1.start();
		Day21_5 obj2=new Day21_5(); 
		obj2.start();
		
		Day21_5 obj3=new Day21_5(); 
		obj3.start();
		
		Day21_5 obj4=new Day21_5(); 
		obj4.start();
		
	}

}
*/