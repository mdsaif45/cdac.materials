

//Try as an assignment
// Create two classed Even and Odd (range from 1 to 25)  
// write a logic for printing even and odd numbers using Threads



class One extends Thread
{
	public void run()
	{
		System.out.println("ONE");
	}

}



class Two extends Thread
{
	public void run()
	{
		System.out.println("TWO");
	}
}

public class Day21_6 {

	public static void main(String[] args) throws InterruptedException 
	{
		One o1=new One();
		Two t1=new Two();
		o1.start();
		t1.start();
		Thread.sleep(1000);
		One o2=new One();
		Two t2=new Two();
		o2.start();
		t2.start();
		

	}

}
