


public class Day21_4 {

	public static void main(String[] args)

		{
			Thread th=Thread.currentThread();
			System.out.println("Priority = "+th.getPriority());
			System.out.println("MIN = "+Thread.MIN_PRIORITY);
			System.out.println("MAX = "+Thread.MAX_PRIORITY);
			System.out.println("NORMAL = "+Thread.NORM_PRIORITY);
			
			th.setPriority(3);
			System.out.println("Priority = "+th.getPriority());
		}
}	

/*
public class Day21_4 {

	public static void main(String[] args) throws InterruptedException
	{
		Thread th=Thread.currentThread();
		System.out.println("Is it alive = "+th.isAlive());
		th.setDaemon(true);
		System.out.println("Is it alive = "+th.isAlive()); //throw Exception
		//th is currentThread
		//currentThread is main() which is live 
		
	}
}
*/

/*
public class Day21_4 {

	public static void main(String[] args) throws InterruptedException
	{
		Thread th=Thread.currentThread();
		System.out.println(th);//th.toString() 
		//Returns a string representation of this thread,
		//including the thread's name, priority, and thread group.
		
		System.out.println("Name = " +th.getName());
		System.out.println("Priority = "+th.getPriority());
		System.out.println("State = "+th.getState());
		th.setName("MYTHREAD");
		System.out.println("After setting the new Name =  "+th.getName());
		System.out.println(th);
		System.out.println("Is it alive = "+th.isAlive());
		System.out.println("Is it daemon = "+th.isDaemon());
		
		Thread.sleep(2500);
		System.out.println("Is it alive = "+th.isAlive());
		
		
	}
	
}

*/
