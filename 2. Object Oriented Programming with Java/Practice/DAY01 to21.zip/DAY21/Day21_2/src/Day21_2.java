import java.util.Arrays;
import java.util.List;


//java program to find the sum of even numbers from list 
//using declarative style of programming 
//Functional Programming (STREAMS (parrallel Programming) 

public class Day21_2 {

	public static void main(String[] args) 
	{
		List<Integer> numbers=Arrays.asList(11,22,33,44,55,66,77,88,99,100);
		
		System.out.println(numbers.stream()
				.filter(number->number%2==0)
				.mapToInt(e-> e*2 )
				.sum()); 
	}

}



/*

// java program to find the sum of even numbers from list 
// using imperative style of programming 

public class Day21_2 {

	public static void main(String[] args) 
	{
		List<Integer> numbers=Arrays.asList(11,22,33,44,55,66,77,88,99,100);
		
		int result = 0;
		for(Integer n:numbers) //set of numbers (stream)  ==> int values 
		{
			if(n%2==0) //checking the condition and then filtering the numbers 
				result+=n; //addition 
		}
		System.out.println(result); 
	}

}

*/