
//if we access any method from main
// and if that method is defined inside the same class in which main() is residing
//then we should declare those methods as static 

public class Day5_7 
{
	
	static void sum(int num1,int num2)
	{
		System.out.println(num1+num2);
	}

	public static void main(String[] args) 
	{
		//sum(30,25);
		Day5_7.sum(60,60);
		

	}

}

//Day5_7 is class
// sum() ==> non static
// main() ==>static

//if we try to give a call to non static method from static methid
//javac error 
//when both the methods belongs to same scope 






