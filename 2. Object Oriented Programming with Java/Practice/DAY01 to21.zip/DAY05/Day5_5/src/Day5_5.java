import java.util.Scanner;

class Test
{
	int num1;
	int num2;
	void accept()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter First Number : ");
		this.num1=sc.nextInt();
		System.out.println("Enter Second Number : ");
		this.num2=sc.nextInt();
		
	}
	void disp()
	{
		System.out.println("First = "+this.num1+" Second = "+this.num2);
		
	}
	
	void sum()
	{
		System.out.println("Addition = "+(this.num1+this.num2));
	}
	
}

public class Day5_5 {

	public static void main(String[] args)
	{
		Test tobj=new Test();
		tobj.accept();
		tobj.disp();
		tobj.sum();

	}

}
