import java.util.Scanner;

class Employee
{
	private String name; 
	private int id; 
	private String dept; 
	private String desg; 
	private float salary; 
	
	//Constructor Overloading 
	// Constructor is taking multiple forms 
	// contructor is special member function of the class 
	public Employee() 
	{
		this("DEFAULT",1,"NONE","NONE",0.0f); //constructor chaining
		//this.name="DEFAULT";
		//this.id=1;
		//this.dept="NONE";
		//this.desg="NONE";
		//this.salary=0.0f;
	}

	//Employee e=new Employee("",1,"","",5.4f);
	
	
	public Employee(String name, int id, String dept, String desg, float salary) 
	{
		this.name = name;
		this.id = id;
		this.dept = dept;
		this.desg = desg;
		this.salary = salary;
	}

	//getters and setters are also member functions of the class 
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDept() {
		return dept;
	}

	public void setDept(String dept) {
		this.dept = dept;
	}

	public String getDesg() {
		return desg;
	}

	public void setDesg(String desg) {
		this.desg = desg;
	}

	public float getSalary() {
		return salary;
	}

	public void setSalary(float salary) {
		this.salary = salary;
	}

	// Facilitators 
	//member function
	//which gives me facility to accept the data 
	//and disp the data
	
	void accept()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Name : ");
		this.name=sc.next();
		System.out.println("Enter ID : ");
		this.id=sc.nextInt();
		
		System.out.println("Enter Dept : ");
		this.dept=sc.next();
		System.out.println("Enter Designation : ");
		this.desg=sc.next();
		System.out.println("Enter Salary : ");
		this.salary=sc.nextFloat();
		
	}
	void disp()
	{
		System.out.print(" Name = "+this.name+" ID = "+this.id+" Dept "+this.dept);
		System.out.println(" Designation = "+this.desg+" Salary= "+this.salary);
	}

	@Override
	public String toString() 
	{
		//return "Employee [name=" + name + ", dept=" + dept + ", desg=" + desg + "]";
		         
		return " NAME  "+this.name+ " DEPT "+this.dept;
				
	}
	

		
}


public class Day5_2 {

	public static void main(String[] args) 
	{
		Employee e1=new Employee();
		System.out.println("E1 Partial Information = "+e1);
		//e1.toString() ==> Employee class toString() will be called 
		Employee e2=new Employee("Akshita",1,"Training","Tech Head",60000.5f);
		System.out.println("E2 Partial Information = "+e2);
		
		
	}
}

