import java.util.Scanner;


//Requirement is not to create instance/object of the class
//we do not want to call the methods on object name
// Solution = declare the methods as static 


// If we wish to access the fields of the class 
// inside the static methods of the class
//then it is compulsory to declare those fields  as static 
class Test
{
	static int num1;
	static int num2;
	//if we wish to access the fields of class inside the static methods
	//then we should declare the fields as static 
	
	static void accept()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter First Number : ");
		num1=sc.nextInt();
		System.out.println("Enter Second Number : ");
		num2=sc.nextInt();
		
	}
	static void disp()
	{
		System.out.println("First = "+num1+" Second = "+num2);
		
	}
	
	static void sum()
	{
		System.out.println("Addition = "+(num1+num2));
	}
	
	void print()
	{
		System.out.println("Inside Print method");
	}
	
}

public class Day5_6 {

	public static void main(String[] args)
	{
		Test.accept(); //calling to static method 
		Test.disp(); //calling to static method
		Test.sum(); //calling to static method
		//Test.print();//javac error //because it is non static 
		Test tobj=new Test();
		tobj.print(); //calling to non static method 
	
	}

}
