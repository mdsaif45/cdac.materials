import java.util.Scanner;

class Employee
{
	private String name; 
	private int id; 
	private String dept; 
	private String desg; 
	private float salary; 
	
	//Constructor Overloading 
	// Constructor is taking multiple forms 
	// contructor is special member function of the class 
	public Employee() 
	{
		this("DEFAULT",1,"NONE","NONE",0.0f); //constructor chaining
		//this.name="DEFAULT";
		//this.id=1;
		//this.dept="NONE";
		//this.desg="NONE";
		//this.salary=0.0f;
	}

	//Employee e=new Employee("",1,"","",5.4f);
	
	
	public Employee(String name, int id, String dept, String desg, float salary) 
	{
		this.name = name;
		this.id = id;
		this.dept = dept;
		this.desg = desg;
		this.salary = salary;
	}

	//getters and setters are also member functions of the class 
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDept() {
		return dept;
	}

	public void setDept(String dept) {
		this.dept = dept;
	}

	public String getDesg() {
		return desg;
	}

	public void setDesg(String desg) {
		this.desg = desg;
	}

	public float getSalary() {
		return salary;
	}

	public void setSalary(float salary) {
		this.salary = salary;
	}

	// Facilitators 
	//member function
	//which gives me facility to accept the data 
	//and disp the data
	
	void accept()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Name : ");
		this.name=sc.next();
		System.out.println("Enter ID : ");
		this.id=sc.nextInt();
		
		System.out.println("Enter Dept : ");
		this.dept=sc.next();
		System.out.println("Enter Designation : ");
		this.desg=sc.next();
		System.out.println("Enter Salary : ");
		this.salary=sc.nextFloat();
		
	}
	void disp()
	{
		System.out.print(" Name = "+this.name+" ID = "+this.id+" Dept "+this.dept);
		System.out.println(" Designation = "+this.desg+" Salary= "+this.salary);
	}
	
	
}


public class Day5_1 {

	public static void main(String[] args) 
	{
		Employee e1=new Employee();
		System.out.println(e1);
		//object information
		//e1.toString() ==> from which class Object
		//because Employee class is not having toString() method 
		
	}
}



/*

public class Day5_1 {

	public static void main(String[] args) 
	{
		Employee e1=new Employee("Monish",2,"placement","head",5.5f);
		e1.disp();
		
		Employee e2=new Employee("Akshita",3,"training","head",8.5f);
		e2.disp();
		
		e2.setSalary(e1.getSalary()); //e2.setSalary(5.5)
		e2.disp();
		
		System.out.println("Update e1 id");
		
		e1.setId(50);
		e1.disp();
		
		Employee e3=new Employee();
		e3.accept(); 
	}
}
*/


/*
public class Day5_1 {

	public static void main(String[] args) 
	{
		Employee e=new Employee();
		//String str = e.getName();
		System.out.println("Name = "+e.getName());
		System.out.println("Designation = "+e.getDesg());
		System.out.println("Salary = "+e.getSalary());
		//System.out.println("Dept = "+e.dept);//NO //Private 
		
		System.out.println("Update the employee e salary ");
		
		e.setSalary(80000.45f); //setSalary() is called upon e object
		System.out.println("New salary = "+e.getSalary());
		
		
	}
}


*/


/*

public class Day5_1 {

	public static void main(String[] args) 
	{
		Employee e1=new Employee();
		Employee e2=new Employee("Akshita",1,"TCT","TechHead",60000.5f);
		Employee e3=new Employee();
		
		//this ==> e3 object
		e1.disp();
		e2.disp();
		e3.disp();
		System.out.println("Enter new values for e3");
		e3.accept();
		e3.disp();
		//System.out.println("Hashcode e1 "+e1); //e1.toString()
		//System.out.println("Hashcode e2 "+e2); //e2.toString()

		//System.out.println("Hashcode e3"+e3);
		
	}

}

*/
