import java.util.Scanner;



// We have created Date class object within Employee class Object
// Association 
// Employee has-a Date of joining 
//Car has-a Engine
// Employee has-a date of birth

class Date
{
	private int dd;
	private int mm;
	private  int yy;
	public Date() 
	{
		
	}
	public Date(int dd, int mm, int yy) {
		super();
		this.dd = dd;
		this.mm = mm;
		this.yy = yy;
	}
	public int getDd() {
		return dd;
	}
	public void setDd(int dd) {
		this.dd = dd;
	}
	public int getMm() {
		return mm;
	}
	public void setMm(int mm) {
		this.mm = mm;
	}
	public int getYy() {
		return yy;
	}
	public void setYy(int yy) {
		this.yy = yy;
	}
	@Override
	public String toString() {
		return "Date [dd=" + dd + ", mm=" + mm + ", yy=" + yy + "]";
	}
	
	
	
}


class Employee
{
	private String name; 
	private int empid; 
	private float salary; 
	Date dobj=new Date(); //ASSOCIATION
	// dobj is object now 
	public Employee()
	{
		
	}
	
	public Employee(String name, int empid, float salary, Date dobj) {
		
		this.name = name;
		this.empid = empid;
		this.salary = salary;
		this.dobj = dobj;
	}
	
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}
	public Date getDobj() {
		return dobj;
	}
	public void setDobj(Date dobj) {
		this.dobj = dobj;
	}
	@Override
	public String toString() {
		return "Employee [name=" + name + ", empid=" + empid + ", salary=" + salary + ", dobj=" + dobj + "]";
	}
	
	
	
	
}

public class Day5_4 
{

	public static void main(String[] args) 
	{
		Employee e1=new Employee();
		System.out.println(e1);
		//System.out.println(e.getDobj().getDd());
		
		Date d1=new Date(15,3,2022);
		Employee e2=new Employee("Akshita",1,50000.5f,d1);
		//it will call paramatrized constructor 
		//by passing two values and two reference 
		//Akshita ==> String ==> reference type / NP
		// 1 ==> int ==> value type / P
		// 50000.5 ==> float ==> value type / P
		// d1==> Date ==> referece / NP 
		System.out.println(e2);
		
		Employee e3=new Employee("Sparsh",2,70000.5f,new Date(16,3,2022));
		System.out.println(e3);
	}
}


