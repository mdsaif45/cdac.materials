import java.util.Scanner;

class Date
{
	int dd;
	int mm;
	int yy;
	public Date() 
	{
		
	}
	public Date(int dd, int mm, int yy) {
		super();
		this.dd = dd;
		this.mm = mm;
		this.yy = yy;
	}
	public int getDd() {
		return dd;
	}
	public void setDd(int dd) {
		this.dd = dd;
	}
	public int getMm() {
		return mm;
	}
	public void setMm(int mm) {
		this.mm = mm;
	}
	public int getYy() {
		return yy;
	}
	public void setYy(int yy) {
		this.yy = yy;
	}
	@Override
	public String toString() {
		return "Date [dd=" + dd + ", mm=" + mm + ", yy=" + yy + "]";
	}
	
	
	
}


class Employee
{
	private String name; 
	private int empid; 
	private float salary; 
	Date dobj; //dobj is field of the class Employee 
	//reference variable of Date class 
	//dobj is a field declared within the Employee class
	public Employee()
	{
		
	}
	//Employee e=new Employee("Akshita",1,70000,d1);
	//Date dobj=d1;
	public Employee(String name, int empid, float salary, Date dobj) {
		super();
		this.name = name;
		this.empid = empid;
		this.salary = salary;
		this.dobj = dobj;
	}
	
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}
	public Date getDobj() {
		return dobj;
	}
	public void setDobj(Date dobj) {
		this.dobj = dobj;
	}
	@Override
	public String toString() {
		return "Employee [name=" + name + ", empid=" + empid + ", salary=" + salary + ", dobj=" + dobj + "]";
	}
	
	
	
	
}

public class Day5_3 
{

	public static void main(String[] args) 
	{
		Employee e=new Employee();
		System.out.println(e);
		System.out.println(e.getDobj().getMm()); // NPE
	}
}




/*
public class Day5_3 
{

	public static void main(String[] args) 
	{
		Date d1=new Date(15,03,2021);// d1 is object 
		Employee e=new Employee("Akshita",1,70000,d1);
		System.out.println(e);//e.toString()
	}
}
*/

/*

public class Day5_3 {

	public static void main(String[] args) 
	{
		Date d1=new Date(15,03,2021);// d1 is object 
		Employee e=new Employee("Akshita",1,70000,d1);
		System.out.println(e.getName());
		System.out.println(e.getEmpid());
		System.out.println(e.getSalary());
		System.out.println(e.getDobj());
		System.out.println(e.getDobj().getDd());
		System.out.println(e.getDobj().getMm());
		System.out.println(e.getDobj().getYy());
		System.out.println("hashcode "+e.hashCode());
		System.out.println("class name "+e.getClass());
		System.out.println("name "+e.getClass().getName());
		System.out.println("hashcode " + e.dobj.hashCode());
		
		
		
	}
}

*/




/*

public class Day5_3 {

	public static void main(String[] args) 
	{
		Employee e=new Employee("Akshita",1,70000,null);
		//System.out.println(e);
		System.out.println(e.getName()); //Akshita
		System.out.println(e.getDobj()); //null
		//System.out.println(e.getDobj().getDd()); // NPE
		//System.out.println(e.getDobj().getMm()); //NPE 
		
	}
}
*/


/*


public class Day5_3 {

	public static void main(String[] args) 
	{
		Employee e=new Employee();
		System.out.println("Employee "+e);
		System.out.println("Displaying date object ");
		System.out.println(e.getDobj());
		
		System.out.println(e.getDobj().getDd()); //NPE 
		//e.getDobj() is retuning null
		//getDd() is called upon null reference
		// NPE 
		
		
		//Date dobj=null; // dobj is method local variable (method local reference)
		//which is allocated null
		//dobj.getDd(); //on null refernce we are calling method 
		// NPE 
		
	}
}

*/