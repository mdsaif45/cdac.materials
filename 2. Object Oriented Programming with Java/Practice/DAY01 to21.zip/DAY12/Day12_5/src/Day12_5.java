import java.util.Scanner;

//Rule : if we write ,multiple catch blocks along with  Exception catch block in the program
//it should be the last catch block from all the multiple catch blocks 
// or else it will throw javac error Unreachable code
// because Exception is super class of all the Exception classes in the Exception Hierarchy

public class Day12_5 {

	public static void main(String[] args) 
	{
		int a;
		Scanner sc=new Scanner(System.in);
		
		int num;
		try
		{
		System.out.println("Enter num ");
		a = sc.nextInt();
		System.out.println("A = "+a);
		
		num=Integer.parseInt(args[0]);
		System.out.println(num);
		}
		
		catch(Exception e ) //Generic Catch block 
		{
			System.out.println("wrong input given");
		}
		catch(ArrayIndexOutOfBoundsException e) //unreachable catch block //javac error 
		{
			System.out.println("No command line arguments are given ");
		}
	
	}

}


/*
public class Day12_5 {

	public static void main(String[] args) 
	{
		int a;
		Scanner sc=new Scanner(System.in);
		
		int num;
		try
		{
		System.out.println("Enter num ");
		a = sc.nextInt();
		System.out.println("A = "+a);
		
		num=Integer.parseInt(args[0]);
		System.out.println(num);
		}
		
		
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("No command line arguments are given ");
		}
		catch(Exception e )
		{
			System.out.println("wrong input given");
		}
	}

}

*/
