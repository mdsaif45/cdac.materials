import java.util.Scanner;

public class Day12_2 {

	public static void main(String[] args)
	{
		int a,b;
		int result;
		Scanner sc=null;
		sc=new Scanner(System.in);
		System.out.println("Enter First Number = ");
		a=sc.nextInt();
		System.out.println("Enter Second Number = ");
		b=sc.nextInt();
		result=a/b;
		System.out.println("Division = "+result);
		sc.close();
		
	}

}
