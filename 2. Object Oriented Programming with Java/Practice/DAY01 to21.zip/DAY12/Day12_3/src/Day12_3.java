import java.util.Scanner;

//if b=0 while performing a/b jvm throw ArithmeticException object (new ArithmeticException()) 
// and in this program we have matching catch block ArithmeticExceptio 
// thats why it user enters b=0 it is taking corrective actions
//it is terminating the application gracefully 

public class Day12_3 {

	public static void main(String[] args)
	{
		int a,b;
		int result;
		Scanner sc=null;
		sc=new Scanner(System.in);
	
		System.out.println("Enter First Number = ");
		a=sc.nextInt();
		System.out.println("Enter Second Number = ");
		b=sc.nextInt();
		try
		{
			result=a/b; //if b=0 AE object is thrown by jvm 
			System.out.println("Division = "+result);
		
		}
		catch(ArithmeticException e) //the object is caught by AE e , e is reference of type AE
		{
			System.out.println("Second number can not be zero");
		}
		sc.close();
		
	}

}
