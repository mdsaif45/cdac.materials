import java.util.Scanner;

//can abstract class implements interface = YES 


interface Test
{
	public void fn(); //abstract void fn(); 
}


abstract class Shape implements Test
{
	abstract void area();
	
}

//Test ===>  Shape ====> Demo  ===> MULTILEVEL Inheritance 
class Demo extends Shape   //class Demo extends Shape implements Test 
{

	@Override
	public void fn() 
	{
		System.out.println("Inside Function fn");
	}

	@Override
	void area() 
	{
		System.out.println("Inside Function area");
	}
	
}

public class Day12_1 {

	public static void main(String[] args) 
	{
		Demo d=new Demo();
		d.area();
		d.fn();
	}
}





/*
interface maths
{
	//method declaration
	public void add(); //it is considered as public abstract void add() 
	public void sub();
	public void mul();
	public void div();
	
}

class Test implements maths
{

	Scanner sc=new Scanner(System.in);
	@Override
	public void add() 
	{
		int a,b;
		System.out.println("Enter First Number ");
		a=sc.nextInt();
		System.out.println("Enter Second Number ");
		b=sc.nextInt();
		System.out.println("Addition = "+(a+b));
	}

	@Override
	public void sub() {
		
		int a,b;
		System.out.println("Enter First Number ");
		a=sc.nextInt();
		System.out.println("Enter Second Number ");
		b=sc.nextInt();
		System.out.println("Subtraction = "+(a-b));
	}

	@Override
	public void mul() {
		int a,b;
		System.out.println("Enter First Number ");
		a=sc.nextInt();
		System.out.println("Enter Second Number ");
		b=sc.nextInt();
		System.out.println("Multiplication = "+(a*b));
		
	}

	@Override
	public void div() {
	
		int a,b;
		System.out.println("Enter First Number ");
		a=sc.nextInt();
		System.out.println("Enter Second Number ");
		b=sc.nextInt();
		System.out.println("Division = "+(a/b));
	}
	
}


class Demo implements maths
{
	Scanner sc=new Scanner(System.in);
	@Override
	public void add() 
	{
		int a,b,c;
		System.out.println("Enter First Number ");
		a=sc.nextInt();
		System.out.println("Enter Second Number ");
		b=sc.nextInt();
		System.out.println("Enter Third Number ");
		c=sc.nextInt();
		System.out.println("Addition = "+(a+b+c));
	}

	@Override
	public void sub() {
		
		int a,b,c;
		System.out.println("Enter First Number ");
		a=sc.nextInt();
		System.out.println("Enter Second Number ");
		b=sc.nextInt();
		System.out.println("Enter Third Number ");
		c=sc.nextInt();
		System.out.println("Subtraction = "+(a-b-c));
	}

	@Override
	public void mul() {
		int a,b,c;
		System.out.println("Enter First Number ");
		a=sc.nextInt();
		System.out.println("Enter Second Number ");
		b=sc.nextInt();
		System.out.println("Enter Third Number ");
		c=sc.nextInt();
		System.out.println("Multiplication = "+(a*b*c));
		
	}

	@Override
	public void div() {
	
		int a,b;
		System.out.println("Enter First Number ");
		a=sc.nextInt();
		System.out.println("Enter Second Number ");
		b=sc.nextInt();
		System.out.println("Division = "+(a/b));
	}
	
	public void mod()
	{
		int a,b;
		System.out.println("Enter First Number ");
		a=sc.nextInt();
		System.out.println("Enter Second Number ");
		b=sc.nextInt();
		System.out.println("Mod = "+(a%b));
		
	}
	
	
}



public class Day12_1 {

	public static void main(String[] args) 
	{
		Test tobj=new Test(); //Test class is implementing maths interface 
		tobj.add(); //overridden method 
		tobj.sub();//overridden method 
		tobj.mul(); //overridden method 
		tobj.div(); //overridden method 
		//tobj.mod(); //NO mod() is not present inside Test class 
		
		Demo d=new Demo(); //Demo class is implementing maths interface 
		d.add(); //overridden method 
		d.sub(); //overridden method 
		d.mul(); //overridden method 
		d.div(); //overridden method 
		d.mod();  // non overridden method 

		
		
		
	}

}

*/
