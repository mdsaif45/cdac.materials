import java.util.InputMismatchException;
import java.util.Scanner;




/*
public class Day12_4 {

	public static void main(String[] args)
	{
		int a,b;
		int result;
		Scanner sc=null;
		sc=new Scanner(System.in);
	try
		{
			System.out.println("Enter First Number = ");
			a=sc.nextInt();
			System.out.println("Enter Second Number = ");
			b=sc.nextInt();
		
			result=a/b; //if b=0 AE object is thrown by jvm 
			System.out.println("Division = "+result);
		
		}
		catch(Exception e)  // Generic Catch Block 
		{
			System.out.println("Division can not be performed. "+e);
		}
		
		sc.close();
		
	}

}
*/

/*
//we can combine one or more number of Exception inside catch block using | sign



public class Day12_4 {

	public static void main(String[] args)
	{
		int a,b;
		int result;
		Scanner sc=null;
		sc=new Scanner(System.in);
	try
		{
			System.out.println("Enter First Number = ");
			a=sc.nextInt();
			System.out.println("Enter Second Number = ");
			b=sc.nextInt();
		
			result=a/b; //if b=0 AE object is thrown by jvm 
			System.out.println("Division = "+result);
		
		}
		catch(ArithmeticException | InputMismatchException e) 
		{
			System.out.println("Division can not be performed. "+e);
		}
		
		sc.close();
		
	}

}

*/


/*
//every try block must have atleast one catch block 
// whenever exception occurs within try block it tries to find
//matching catch block and then takes corrective action 

public class Day12_4 {

	public static void main(String[] args)
	{
		int a,b;
		int result;
		Scanner sc=null;
		sc=new Scanner(System.in);
	try
		{
			System.out.println("Enter First Number = ");
			a=sc.nextInt();
			System.out.println("Enter Second Number = ");
			b=sc.nextInt();
		
			result=a/b; //if b=0 AE object is thrown by jvm 
			System.out.println("Division = "+result);
		
		}
		catch(ArithmeticException e) //the object is caught by AE e , e is reference of type AE
		{
			System.out.println("Second number can not be zero. "+e);
		}
		catch(InputMismatchException i)
		{
			System.out.println("Input is not given in correct way. "+i);
		}
		sc.close();
		
	}

}


*/