

// we can call super class methods with the help of derived class object 
// we can not call sub class method with the help of 
//super class object directly  

class Person
{
	String name;
	int age;
	
	void disp_person()
	{
		System.out.println(" Name = "+this.name+" Age = "+this.age);
	}
}


class Employee extends Person
{
	int empid;
	int salary;
	
	void disp_emp()
	{
		System.out.println("EmpId = "+this.empid+" Salary = "+this.salary);
	}
}


public class Day10_2 {

	public static void main(String[] args)
	{
		Employee e=new Employee();
		e.disp_emp();
		e.disp_person();
		//disp_person() is called upon e (sub class object)
		
		Person p=new Person(); // VALID
		p.disp_person();
		//p.disp_emp(); //javac error 

	}

}
