import java.util.Scanner;

class Person
{
	private String name;
	private int age;
	
	
	public Person()
	{
		this.name="DEFAULT";
		this.age=1;
	}

	public Person(String name, int age) 
	{
		this.name = name;
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	void accept_person()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Name ");
		this.name=sc.next();
		System.out.println("Enter Age ");
		this.age=sc.nextInt();
	}
	
	void disp_person()
	{
		System.out.println(" Name = "+this.name+" Age = "+this.age);
				
	}
}


class Employee extends Person
{
	private int empid;
	private int salary;
	
	
	
	public Employee() 
	{
		super(); //optional to write super() 
		this.empid=1;
		this.salary=1;
	}
	

	public Employee(int empid, int salary,String name,int age) 
	{
		super(name,age); //call to paramatrized constructor is done
		//using super along with parameters 
		//explicit calls 
		//CONSTRUCTOR CHAINING 
		this.empid = empid;
		this.salary = salary;
		//super(name,age); //javac error 
		//Rule: constuctor call must be first statment 
		//this.name=name; // INVALID (Private )
		//this.age=age; // Invalid (Private
	}

	


	public int getEmpid() {
		return empid;
	}


	public void setEmpid(int empid) {
		this.empid = empid;
	}


	public int getSalary() {
		return salary;
	}


	public void setSalary(int salary) {
		this.salary = salary;
	}

	void accept_emp()
	{
		// accept_person();//valid
		 this. accept_person(); //valid 
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter EMPID : ");
		this.empid=sc.nextInt();
		System.out.println("Enter Salary :");
		this.salary=sc.nextInt();
		
	}

	void disp_emp()
	{
		this.disp_person();
		System.out.println("Empid = "+this.empid+ " Salary = "+this.salary);
		
	}
	
}


public class Day10_6 {

	public static void main(String[] args) 
	{
		Employee e=new Employee();
		e.disp_emp(); 
		e.accept_emp();
		e.disp_emp();
		e.setSalary(90000);
		System.out.println("After setting new salary "+e.getSalary());
		e.disp_emp();
	}
}

/*
public class Day10_6 {

	public static void main(String[] args) 
	{
		Employee e=new Employee(123,60000,"Akshita",34);
		e.disp_emp();
		
	}

}

*/


/*
public class Day10_6 {

	public static void main(String[] args) 
	{
		Employee e=new Employee();
		e.disp_emp();
		
	}

}
*/
