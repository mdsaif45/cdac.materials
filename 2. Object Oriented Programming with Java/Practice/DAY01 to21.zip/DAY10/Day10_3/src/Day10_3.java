

//Methods of super class can be called inside the subclass methods 
// with the help of this keyword 
//writing of this keyword is optional 


class Person
{
	String name;
	int age;
	
	void disp_person()
	{
		System.out.println(" Name = "+this.name+" Age = "+this.age);
				
	}
}


class Employee extends Person
{
	int empid;
	int salary;
	
	void disp_emp() // current object ==> e ==> this 
	{
		System.out.println("EmpId = "+this.empid+" Salary = "+this.salary);
		this.disp_person(); //call	to super class method is done inside the method of sub class
		
	}
}


public class Day10_3 {

	public static void main(String[] args)
	{
		Employee e=new Employee();
		e.disp_emp();//disp_emp() is called upon e object
		// this==> e 
		
		
		
	}

}


/*
//Methods of super class can be called inside the subclass methods 

class Person
{
	String name;
	int age;
	
	void disp_person()
	{
		System.out.println(" Name = "+this.name+" Age = "+this.age);
	}
}


class Employee extends Person
{
	int empid;
	int salary;
	
	void disp_emp()
	{
		System.out.println("EmpId = "+this.empid+" Salary = "+this.salary);
		disp_person(); //call	to super class method is done inside the method of sub class
		
	}
}


public class Day10_3 {

	public static void main(String[] args)
	{
		Employee e=new Employee();
		e.disp_emp();
		
		
		
	}

}


*/