
//super(along with parameters) will give a call to super class paramatrized
//constuctor 
//if we wish to call paramatrized constructor of super class
//it is compulsory to write super(...) inside the body of paramatrized
//constructor of sub class 


class Person
{
	String name;
	int age;
	Person()
	{
		System.out.println("Parameterless constructor Person");
		this.name="DEFAULT";
		this.age=1;
	}
	Person(String name,int age)
	{
		System.out.println("inside paramatrized constructor of Person");
		this.name=name;
		this.age=age;
	}
	
	void disp_person()
	{
		System.out.println(" Name = "+this.name+" Age = "+this.age);
				
	}
}


class Employee extends Person
{
	int empid;
	int salary;
	
	Employee()
	{
		super(); // please call super class constructor 
		//writing of super() is optional 
		System.out.println("Parameteless Constrcutor of Employee ");
		this.empid=1;
		this.salary=1;
	}
	
	Employee(int id,int salary,String name , int age)
	{
		super(name,age);
		//it will call paramatrized constructor of super class 
		System.out.println("Inside paramatrized constructor : Employee class ");
		this.empid=id;
		this.salary=salary;
	}
	void disp_emp() // current object ==> e ==> this 
	{
		System.out.println("EmpId = "+this.empid+" Salary = "+this.salary);
		this.disp_person(); //call	to super class method is done inside the method of sub class
		
	}
}


public class Day10_5 {

	public static void main(String[] args)
	{
		Employee e=new Employee(123,50000,"akshita",34);
		//it should give a call to paramatrized constructor of Employee class 
		
		e.disp_emp();//disp_emp() is called upon e object
		// this==> e 
		
		Employee e2=new Employee();
		e2.disp_emp();
		
	}

}


/*
// Parameterless constructor of super class is called automatically 
// from the parameterless constructor of sub class 
// whenver object of sub class is created it gives a call to 
//constructor of super class first and then sub class 

class Person
{
	String name;
	int age;
	Person()
	{
		System.out.println("Parameterless constructor Person");
		this.name="DEFAULT";
		this.age=1;
	}
	void disp_person()
	{
		System.out.println(" Name = "+this.name+" Age = "+this.age);
				
	}
}


class Employee extends Person
{
	int empid;
	int salary;
	
	Employee()
	{
		System.out.println("Parameteless Constrcutor of Employee ");
		this.empid=1;
		this.salary=1;
	}
	void disp_emp() // current object ==> e ==> this 
	{
		System.out.println("EmpId = "+this.empid+" Salary = "+this.salary);
		this.disp_person(); //call	to super class method is done inside the method of sub class
		
	}
}


public class Day10_4 {

	public static void main(String[] args)
	{
		Employee e=new Employee();
		e.disp_emp();//disp_emp() is called upon e object
		// this==> e 
		
		
		
	}

}


*/
