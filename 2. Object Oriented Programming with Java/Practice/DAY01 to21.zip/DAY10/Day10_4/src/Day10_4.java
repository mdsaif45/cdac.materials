//By rule , if we have user defined default constructor(parameterless) inside sub class
// then sub class user defined default constructor will give a call to
// super class constructor automatically
// if we wish to write it explicitly
//then we can use super() as the first statement inside the body of
// user defined default constructor
// Writing of super() is optional inside user defined default constructor 

class Person
{
	String name;
	int age;
	Person()
	{
		System.out.println("Parameterless constructor Person");
		this.name="DEFAULT";
		this.age=1;
	}
	void disp_person()
	{
		System.out.println(" Name = "+this.name+" Age = "+this.age);
				
	}
}


class Employee extends Person
{
	int empid;
	int salary;
	
	Employee()
	{
		super(); // please call super class constructor 
		//writing of super() is optional 
		System.out.println("Parameteless Constrcutor of Employee ");
		this.empid=1;
		this.salary=1;
	}
	void disp_emp() // current object ==> e ==> this 
	{
		System.out.println("EmpId = "+this.empid+" Salary = "+this.salary);
		this.disp_person(); //call	to super class method is done inside the method of sub class
		
	}
}


public class Day10_4 {

	public static void main(String[] args)
	{
		Employee e=new Employee(); // Parameterless constr gets called 
		e.disp_emp();//disp_emp() is called upon e object
		// this==> e 
		
		
		
	}

}


/*
// Parameterless constructor of super class is called automatically 
// from the parameterless constructor of sub class 
// whenver object of sub class is created it gives a call to 
//constructor of super class first and then sub class 

class Person
{
	String name;
	int age;
	Person()
	{
		System.out.println("Parameterless constructor Person");
		this.name="DEFAULT";
		this.age=1;
	}
	void disp_person()
	{
		System.out.println(" Name = "+this.name+" Age = "+this.age);
				
	}
}


class Employee extends Person
{
	int empid;
	int salary;
	
	Employee()
	{
		System.out.println("Parameteless Constrcutor of Employee ");
		this.empid=1;
		this.salary=1;
	}
	void disp_emp() // current object ==> e ==> this 
	{
		System.out.println("EmpId = "+this.empid+" Salary = "+this.salary);
		this.disp_person(); //call	to super class method is done inside the method of sub class
		
	}
}


public class Day10_4 {

	public static void main(String[] args)
	{
		Employee e=new Employee();
		e.disp_emp();//disp_emp() is called upon e object
		// this==> e 
		
		
		
	}

}


*/
