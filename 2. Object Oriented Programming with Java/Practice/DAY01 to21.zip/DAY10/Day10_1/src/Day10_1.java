import java.util.Arrays;
import java.util.StringTokenizer;

public class Day10_1 {

	public static void main(String[] args) 
	{
		String str="www sunbeaminfo in";
		String regex=" ";
		String arr[] = str.split(regex);
		
		//for each String s inside array of String arr print s 
		for(String s:arr)
			System.out.println(s);
		
		System.out.println(Arrays.toString(arr));
		
	}
	}


/*
//StringTokenizer(String str)
// Constructs a string tokenizer for the specified string.
 // here default delimeter is \n,\b,\t,\r or space chcarcter 

//StringTokenizer(String str, String delim)
//Constructs a string tokenizer for the specified string.
// here delimeters can be single or multiple , here delimiters are not printed or considered as tokens

//StringTokenizer(String str, String delim, boolean returnDelims)
// Constructs a string tokenizer for the specified string.
// if we pass returnDelims=true then it will consider delimeters as tokens and
//it will display tokens along with delimeters in output 




public class Day10_1 {

	public static void main(String[] args) 
	{
		String str="https://docs.oracle.com/javase/8/docs/api/java/lang/Object.html#hashCode--";
		String delim="/:.#-";
		StringTokenizer stk=new StringTokenizer(str,delim,true);
		
		String token=null;
		int count=0;
		
		while(stk.hasMoreTokens())
		{
			count++;
			token=stk.nextToken();
			System.out.print("  "+token);
		}
		System.out.println("\n total number of tokens = "+count);
	}
}
*/

/*
public class Day10_1 {

	public static void main(String[] args) 
	{
		String str="https://docs.oracle.com/javase/8/docs/api/java/lang/Object.html#hashCode--";
		String delim="/:.#-";
		StringTokenizer stk=new StringTokenizer(str,delim);
		
		String token=null;
		int count=0;
		
		while(stk.hasMoreTokens())
		{
			count++;
			token=stk.nextToken();
			System.out.print("  "+token);
		}
		System.out.println("\n total number of tokens = "+count);
	}
}

*/

/*
public class Day10_1 {

	public static void main(String[] args) 
	{
		String str="www sunbeaminfo in";
		StringTokenizer stk=new StringTokenizer(str);
		
		String token=null;
		while(stk.hasMoreTokens())
		{
			token=stk.nextToken();
			System.out.println(token);
		}
		
		String str1="www.google.co.in";
		StringTokenizer stk1=new StringTokenizer(str1,".");
		String token1=null;
		while(stk1.hasMoreTokens())
		{
			token1=stk1.nextToken();
			System.out.println(token1);
		}
		
	}
}

*/


/*
public class Day10_1 {

	public static void main(String[] args) 
	{
		String str="Sunbeam Pune Karad";
		StringTokenizer stk=new StringTokenizer(str);
		int count=stk.countTokens();
		System.out.println("Count = "+count);
		

	}

}

*/
