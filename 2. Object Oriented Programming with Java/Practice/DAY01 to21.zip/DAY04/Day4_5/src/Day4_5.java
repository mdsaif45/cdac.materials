import java.util.Scanner;

// Constructor Chaining 

class Employee
{
	String name;
	int id;
	float salary;
	Scanner sc=new Scanner(System.in);
	
	Employee() // constructor parameterless // User defined default constructor 
	{
		this("DEFAULT",1,1.1f); //call to parameterized constructor from parameterless 
	}
	
	Employee(String name,int id ,float salary) //parameterized 
	{
		System.out.println("Inside Paramatrized Constructor");
		this.name=name;
		this.id=id;
		this.salary=salary;
		
	}
	
	
	void accept()
	{
		
		System.out.println("Enter Name : ");
		this.name=sc.next();
		System.out.println("Enter ID : ");
		this.id=sc.nextInt();
		System.out.println("Enter Salary : ");
		this.salary=sc.nextFloat();

			
	}
	
	void disp()
	{
		System.out.println("Name = "+this.name+ " ID = "+this.id+ " Salary "+this.salary);
	}
}


public class Day4_5
{
	public static void main(String args[])
	{
		Employee e1=new Employee(); // call to user defined default constructor 
		Employee e2=new Employee("AKSHITA",50,60000.67f); // Parameterized constructor  will be called 
		e1.disp();
		e2.disp();
		
	
		
	}

}



