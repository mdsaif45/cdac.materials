import java.util.Scanner;

class Employee
{
	String name;
	int id;
	float salary;
	Scanner sc=new Scanner(System.in);
	
	void accept()
	{
		
		//method local reference variable
		//stack area ==> because of new ==> heap area
		System.out.println("Object Information = "+this);
		System.out.println("Enter Name : ");
		//this keyword is used to hold current object address
		//this gives the information about current object
		this.name=sc.next();
		System.out.println("Enter ID : ");
		this.id=sc.nextInt();
		System.out.println("Enter Salary : ");
		this.salary=sc.nextFloat();

			
	}
	
	void disp()
	{
		System.out.println("Name = "+this.name+ "ID = "+this.id+ " Salary "+this.salary);
	}
}


public class Day4_2
{
	public static void main(String args[])
	{
		
		Employee e=new Employee();
		System.out.println(e); // Hashcode  // Implicit call toString() 
		//getClass().getName() + '@' + Integer.toHexString(hashCode())
		System.out.println(e.toString()); // Explicit call 
		System.out.println("GET CLASS = "+e.getClass());
		System.out.println("Get NAME = "+e.getClass().getName());
		System.out.println(e.getClass().getTypeName());
		e.accept();
		e.disp();
	}

}




/*
public class Day4_2
{
	public static  void main(String args[])
	{
		Employee e=null; // null reference 
		//reference type 
		e=new Employee(); //  e is reference pointing to Employee object 
		e.accept();
		e.disp();
		
		//int i = new Employee();  // INVALID 
		//float f= new Employee(); // INVALID
		Employee e2= new Employee(); // VALID 
		
	}
}

*/


/*
public class Day4_2
{
	public static void main(String args[])
	{
		Employee e3=null; // initialized to null // null object 
		//e3 is method local variable (reference) initialized to null
		e3.accept(); // NPE (NullPointerException)
		// accept() is called upon null object 
		//accept() is called on e3 , which is null reference 
		
		e3.disp();
		
		
	}
}
*/


/*
public class Day4_2 {

	public static void main(String[] args) 
	{
		
		//Employee e1; // reference variable 
		//e1=new Employee(); // object 
		//e1.accept();
		
		
		//Employee e2=new Employee();
		//e2.accept(); //accept() is called upon e2 object
		//current object e2
		// this ===> e2
		
		//System.out.println("Object e1 = "+e1);
		//System.out.println("Object e2 = "+e2);
		//e1.disp();
		//e2.disp();
		
		
		
		//this keyword 
		// it is used to hold current object address
		
		Employee e3; // e3 is a method local variable reference 
		// uninitialized 
		// Compile time error ==> javac error 
		e3.accept();
		e3.disp();
		
		
	}

}


*/