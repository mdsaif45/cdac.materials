import java.util.Scanner;

// Constructor Chaining 
//while chaining of constructor we should write 
//this([parameters]) 
// this() should be the first statement inside the constructor


class Employee
{
	String name;
	int id;
	float salary;
	Scanner sc=new Scanner(System.in);
	
	Employee() // constructor parameterless // User defined default constructor 
	{
		this("Sunbeam");
	}
	
	Employee(String name) // Paramatrized 
	{
		//this.name=name; // ERROR 
		this("NEW",4,50.6f); // will give a call to next paramatrized constrctuctor 
	}
	
	Employee(String name,int id ,float salary) //parameterized 
	{
		System.out.println("Inside Paramatrized Constructor");
		this.name=name;
		this.id=id;
		this.salary=salary;
		
	}
	
	
	void accept()
	{
		
		System.out.println("Enter Name : ");
		this.name=sc.next();
		System.out.println("Enter ID : ");
		this.id=sc.nextInt();
		System.out.println("Enter Salary : ");
		this.salary=sc.nextFloat();

			
	}
	
	void disp()
	{
		System.out.println("Name = "+this.name+ " ID = "+this.id+ " Salary "+this.salary);
	}
}


/*

public class Day4_6
{
	public static void main(String args[])
	{
		Employee e1=new Employee(); // call to user defined default constructor 
		Employee e2=new Employee("AKSHITA",50,60000.67f); // Parameterized constructor  will be called 
		Employee e3=new Employee("Sunbeam");
		e1.disp();
		e2.disp();
		e3.disp();
		
	
		
	}

}

*/


public class Day4_6
{
	public static void main(String args[])
	{
		Employee e1;
		e1=new Employee(); // Akshita 0 0.0 
		e1.disp();
	}
}

