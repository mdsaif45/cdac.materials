import java.util.Scanner;


// parameterless constructor
//constrcutor  is used to initialize the fields of the class 
// In one class , two types of constructors are called
// Parameterelss and Paramatrized 
// it is called as Constructor Overloading 

class Employee
{
	String name;
	int id;
	float salary;
	Scanner sc=new Scanner(System.in);
	
	Employee() // constructor parameterless // User defined default constructor 
	{
		System.out.println("Inside Parameterless Constructor ");
		this.name="DEFAULT";
		this.id=1;
		this.salary=1;
	}
	
	Employee(String n,int i ,float s) //parameterized 
	{
		System.out.println("Inside Paramatrized Constructor");
		name=n;
		id=i;
		salary=s;
	}
	
	
	void accept()
	{
		
		System.out.println("Enter Name : ");
		this.name=sc.next();
		System.out.println("Enter ID : ");
		this.id=sc.nextInt();
		System.out.println("Enter Salary : ");
		this.salary=sc.nextFloat();

			
	}
	
	void disp()
	{
		System.out.println("Name = "+this.name+ " ID = "+this.id+ " Salary "+this.salary);
	}
}


public class Day4_4
{
	public static void main(String args[])
	{
		Employee e1=new Employee(); // call to user defined default constructor 
		Employee e2=new Employee("AKSHITA",50,60000.67f); // paramatrized constructor  will be called 
		// Intimate to the compiler that 
		//please initialize the object with my own user defined new values
		// but not with the default values 
		
		Employee e3=new Employee(); //DEFAULT 1  1
		e1.disp();
		e2.disp();
		e3.disp(); //DEFAULT 1  1 
		e3.accept(); //Sunbeam 4 70000.567f
		e3.disp(); //Sunbeam 4 70000.567f
		
	
		
	}

}

// If we do not specify the constructor within the class
// then also our fields of the class gets initialized 
// compiler gives a call to DEFAULT CONSTRUCTOR 
// of the Object Class 

// Constructor gets called once per object 




