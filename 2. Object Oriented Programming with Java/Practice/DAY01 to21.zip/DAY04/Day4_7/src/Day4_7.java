import java.util.Scanner;


//whenever we create fields of the class we receive package level visibility 

//GETTER
//if we want to fetch individual private fields from object

// SETTER
//if we want to allocate invidual private field inside the object

class Employee // default package 
{
	
	String name;  
	private int id;
	private float salary; 
	
	
	Employee() 
	{
		this("Sunbeam",1,1.1f);
	}
	
	
	Employee(String name,int id ,float salary) 
	{
		this.name=name;
		this.id=id;
		this.salary=salary;
		
	}
	
	
	void accept()
	{
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter Name : ");
		this.name=sc.next();
		System.out.println("Enter ID : ");
		this.id=sc.nextInt();
		System.out.println("Enter Salary : ");
		this.salary=sc.nextFloat();

			
	}
	
	int getId()
	{
		return this.id;
	}
	
	void setSalary(float salary)
	{
		this.salary=salary;
	}
	
	void disp()
	{
		System.out.println("Name = "+this.name+ " ID = "+this.id+ " Salary "+this.salary);
	}
}

public class Day4_7
{
	public static void main(String args[])
	{
		Employee e1=new Employee();
		System.out.println(e1.name); // ALLOWED 
		//System.out.println(e1.id); // NOT ALLOWED (private)
		
		System.out.println("ID of Employee e1 = "+e1.getId()); // ALLOWED 
		e1.disp();
		e1.setSalary(80000.5f);
		e1.disp();
		
		Employee e2=new Employee("ABCD",4,6.7f);
		e1.name=e2.name; // ALLOWED // NOT RECOMMENDED 
		//so it is always a good practice to keep the data memebrs as private 
		e1.disp();
		e2.disp();
	}
}

