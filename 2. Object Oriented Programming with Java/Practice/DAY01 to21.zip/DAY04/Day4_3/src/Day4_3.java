import java.util.Scanner;


// parameterless constructor
//constrcutor  is used to initialize the fields of the class 


class Employee
{
	String name;
	int id;
	float salary;
	Scanner sc=new Scanner(System.in);
	
	Employee() // constructor parameterless // User defined default constructor 
	{
		System.out.println("Inside Parameterless Constructor ");
		this.name="DEFAULT";
		this.id=1;
		this.salary=50000;
	}
	
	void accept()
	{
		
		System.out.println("Enter Name : ");
		this.name=sc.next();
		System.out.println("Enter ID : ");
		this.id=sc.nextInt();
		System.out.println("Enter Salary : ");
		this.salary=sc.nextFloat();

			
	}
	
	void disp()
	{
		System.out.println("Name = "+this.name+ " ID = "+this.id+ " Salary "+this.salary);
	}
}


public class Day4_3
{
	public static void main(String args[])
	{
		Employee e1=new Employee();
		// e object is created
		// constructor gets called implicitly 
		// here user defined parameterless constructor get called 
		
		
		
		//disp() is called explicitly 
		Employee e2=new Employee();
		e1.disp(); // DEFAULT 1 50000.0
		e2.disp(); 
		
		System.out.println("E1 Hashcode = "+e1); // e1.toString()
		System.out.println("E2 Hashcode = "+e2); // e2.toString()
		Employee e3; // reference
		e3=e2; // reference copy 
		//both the references are pointing to same location
		// SHALLOW COPY
		System.out.println("E3 Hashcode = "+e3);
		
	}

}

// If we do not specify the constructor within the class
// then also our fields of the class gets initialized 
// compiler gives a call to DEFAULT CONSTRUCTOR 
// of the Object Class 

// Constructor gets called once per object 




