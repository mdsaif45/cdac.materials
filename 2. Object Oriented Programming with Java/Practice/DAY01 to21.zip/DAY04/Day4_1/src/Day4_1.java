import java.util.Scanner;

class Student
{
	String name;
	int rn;
	void accept()
	{
		Scanner sc=new Scanner(System.in); // Object
		//sc is local reference variable inside accept()
		System.out.println("Enter Name : ");
		name=sc.next();
		System.out.println("Enter Roll no ");
		rn=sc.nextInt();
		sc.close();
	}
	void disp()
	{
		System.out.println("Name = "+name + " Rollno "+rn);
	}
	
	
}

public class Day4_1 {

	public static void main(String[] args) 
	{
		Student st; // st is reference of Student class // stack 
		st=new Student(); //new Student() ==> OBJECT 
		
		//similar to  Student st=new Student();
		
		st.accept(); //accept() is called upon st object
		//st will be current object 
		st.disp();// disp() is called upon st object
		//st will be current object 

	}

}
