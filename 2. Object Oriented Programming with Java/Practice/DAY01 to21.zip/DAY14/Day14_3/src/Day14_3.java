
class Test<T,U>
{
	T obj1; // field  // int i; //int is datatype i is variable //field  
	U obj2; // fields
	
	Test(T obj1,U obj2)
	{
		this.obj1=obj1;
		this.obj2=obj2;
	}
	
	void print()
	{
		System.out.println("Obj 1 = "+obj1+ " Obj2 = "+obj2 );
	
	}
	
	
}


public class Day14_3 {

	public static void main(String[] args)
	{
		Test t1=new Test(20,5.4f); //RAW TYPE 
		//if we don't specify the type parameter
		//while creating the object
		// then it is called as RAW TYPE 
		
		Test<String,Integer> t2=new Test<String,Integer>("Akshita",25);
		Test<String,String>t3=new Test<String,String>("Akshita","Sunbeam");
		Test<Float,Integer> t4=new Test<Float,Integer>(45.5f,2);
		t1.print();
		t2.print();
		t3.print();
		t4.print();
		
		

	}

}
