


public class Day14_4 
{

	//if we write <T> while defining the method
	//then that method is called as Generic Method 
	
	static <T>void display_data(T element)
	{
		System.out.println("Element = "+element+" "+element.getClass().getName());
	}
	public static void main(String[] args) 
	{
		
		display_data(120);
		display_data("Sunbeam");
		display_data(5.3f);
	}

}
