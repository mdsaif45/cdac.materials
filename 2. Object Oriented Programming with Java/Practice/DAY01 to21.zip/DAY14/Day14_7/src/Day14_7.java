import java.util.ArrayList;

// Requirement : to have values of type reference 
//cant create primitive type array
//non primitive type
//set of elements : List(interface)==> ArrayList 

//ArrayList is generic class
// implements List interface
//add() declaration is present in interface List
//add() definition is present in ArrayList Class
//add() is overridden inside ArrayList



public class Day14_7 
{

	public static void main(String[] args)
	{
		ArrayList al=new ArrayList(); //Raw Type 
		System.out.println("size = "+al.size());
		al.add(10);
		al.add(3.5f);
		al.add(4.2);
		al.add("sunbeam");
		System.out.println("size = "+al.size());
		for(int i=0;i<al.size();i++)
		{
			System.out.print(" "+al.get(i));
		}
		
	}
}



/*

public class Day14_7 
{

	public static void main(String[] args)
	{
		int[] arr=new int[5]; 
		// arr is array of value type
		// int is primitive type 
		arr[0]=10;
		arr[1]=20;
		arr[2]=30;
		arr[3]=40;
		arr[4]=50;
		
		for(int i:arr)
		{
			System.out.print(" "+i);
		}
	}

}
*/






