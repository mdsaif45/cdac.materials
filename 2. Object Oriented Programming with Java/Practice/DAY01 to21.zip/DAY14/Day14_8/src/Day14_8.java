import java.util.ArrayList;
import java.util.Iterator;
import java.util.NoSuchElementException;

public class Day14_8 {

	public static void main(String[] args) {
		ArrayList<Integer> list=new ArrayList<Integer>();
		list.add(10);
		list.add(20);
		list.add(30);
		list.add(40);
		System.out.println(list); //list.toString()
	}
}
*/


/*
public class Day14_8 {

	public static void main(String[] args) {
		ArrayList<Integer> list=new ArrayList<Integer>();
		list.add(10);
		list.add(20);
		list.add(30);
		list.add(40);
		
		System.out.println("Displaying AL elements using Iterator");
		
		Iterator<Integer> itr= list.iterator();
		// need to link list with the iterator() 
		 //iterator() is a method
		//Iterator is a interface 
		 
		//itr is reference of type interface  Iterator 
		//which will iterate through the list of elements inside ArrayList list 
		
		while(itr.hasNext())
		{
			System.out.print("  "+itr.next());
		}
		try
		{
		System.out.println(itr.next());
		}
		catch(NoSuchElementException ex)
		{
			System.out.println("\n Iteration is over ..no more elements");
		}
		
	
	}
}

*/

/*
public class Day14_8 {

	public static void main(String[] args) {
		ArrayList<Integer> list=new ArrayList<Integer>();
		list.add(10);
		list.add(20);
		list.add(30);
		list.add(40);
		//list.add("akshita"); // Not allowed
		
		//accessing the AL elements using for each loop 
		System.out.println("accessing the AL elements using for  loop ");
		for(int i=0;i<list.size();i++)
			System.out.print(" "+list.get(i));
		list.add(60);
		System.out.println();
		for(int i=0;i<list.size();i++)
			System.out.print(" "+list.get(i));
	}

}

*/


/*
public class Day14_8 {

	public static void main(String[] args) {
		ArrayList<Integer> list=new ArrayList<Integer>();
		list.add(10);
		list.add(20);
		list.add(30);
		list.add(40);
		//list.add("akshita"); // Not allowed
		
		//accessing the AL elements using for each loop 
		System.out.println("accessing the AL elements using for each loop ");
		for(int i:list)
			System.out.print(" "+i);
		
	}

}
*/
