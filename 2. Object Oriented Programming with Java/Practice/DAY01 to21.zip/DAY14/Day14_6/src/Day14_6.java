
//Bounded Type Parameter 

class Box<T extends Number>  
{
	T obj;
	T get()
	{
		return obj;
	}
	
	void set(T obj)
	{
		this.obj=obj;
	}
}

public class Day14_6 {

	public static void main(String[] args) 
	{
		Box <Integer>b1=new Box<Integer>(); // OK 
		//System.out.println(b1.get());
		
		System.out.println(b1.get());
		Box <Float>b2=new Box<Float>(); //OK 
		Box <Double>b3=new Box<Double>(); // OK 
		Box <Short>b4=new Box<Short>(); //OK
		//Box <Boolean> b8=new Box<Boolean>();// NOT OK 
		//Box <String>b5=new Box<String>(); //NOT OK (BOUND MISMATCH)
		
		//Box <Character>b6=new Box<Character>(); //NOT OK
		
		Box b7=null; // b7 is null reference 
		System.out.println(b7.get()); //NPE 
		
		//Box b8<T> = new Box<T>;  // WRONG SYNTAX
		
		
	}

}
