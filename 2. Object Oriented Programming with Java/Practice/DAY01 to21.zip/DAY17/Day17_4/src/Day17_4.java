import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Set;
import java.util.TreeMap;


// Lab work
// Employee (name,id,salary,age)
// switch case 1.HashMap
//case 2 : LinkedHashMap
//case 3 : TreeMap 
// case 4: exit


// // Lab work
//Employee (empid , name )
//use Map interface
// case 1 :  print all empids 
// case 2 : print names of all employees
// case 3: display all employee records 





public class Day17_4 {

	public static void main(String[] args) 
	{
		LinkedHashMap<Integer,String> m=new LinkedHashMap<Integer,String>();
		m.put(5, "Akshita");
		m.put(20, "Sparsh");
		m.put(3, "Chanchlani");
		m.put(10, "sunbeam");
		
		System.out.println(m);
		
	
	}
}



/*
public class Day17_4 {

	public static void main(String[] args) 
	{
		TreeMap<Integer,String> m=new TreeMap<Integer,String>();
		m.put(5, "Akshita");
		m.put(20, "Sparsh");
		m.put(3, "Chanchlani");
		m.put(10, "sunbeam");
		
		System.out.println(m);
		System.out.println(m.get(10)); 
		//get(key) ==> it returns value 
	
	}
}

*/

/*
//HashMap key can be unique
//values can be duplicated 


public class Day17_4 {

	public static void main(String[] args) 
	{
		HashMap<Integer,String> m=new HashMap<Integer,String>();
		m.put(1, "Akshita");
		m.put(2, "Sparsh");
		m.put(3, "Chanchlani");
		m.put(4, "sunbeam");
		m.put(4, "trainer");
		m.put(6, "sunbeam");
		System.out.println(m);
		System.out.println(m.containsKey(1));
		System.out.println(m.containsValue("Akshita"));
		
		//if we wish to fetch only values from HashMap use the method values()
		Collection c=m.values();
		System.out.println(c);
		
		Set s=m.entrySet();
		System.out.println(s);
		
		//keySet() is used to fetch keys from the HashMap
		Set k=m.keySet();
		System.out.println(k);
		
		
		
		
	}

}

*/
