import java.util.HashSet;
import java.util.Objects;


//if we wish to check the contents of objects for comparision
// by default equals() is called
// equals method implements an equivalence relation on non-null object references

//but it does not check the contents within the objects 
//so if we would like to check contents then equals() is overridden
//it is generally necessary to override the hashCode method whenever equals()
//method is overridden


class Employee
{
	String name;
	int id;
	public Employee(String name, int id) {
		super();
		this.name = name;
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Override
	public String toString() {
		return "Employee [name=" + name + ", id=" + id + "]";
	}
	@Override
	public int hashCode() {
		return Objects.hash(id, name);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		return id == other.id && Objects.equals(name, other.name);
	}
	
	
}

public class Day17_2 {

	public static void main(String[] args) 
	{
		HashSet<Employee> e=new HashSet<Employee>();
		e.add(new Employee("Akshita",1));
		e.add(new Employee("Sparsh",2));
		//for(Employee emp:e)
			//System.out.println(emp);
		
		System.out.println(e); //toString()
		Employee key=new Employee("Sparsh",2);
		
		
		System.out.println("Contains = "+e.contains(key)); //False 
		
		System.out.println();

	}

}
