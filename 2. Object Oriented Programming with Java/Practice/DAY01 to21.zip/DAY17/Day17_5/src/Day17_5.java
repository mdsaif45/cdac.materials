import java.util.ArrayList;
import java.util.Collections;

//create a class Movie 
// compare the movie based on year 

//if we wish to sort the Movie based on year  (only one parameter)
// we can opt for Comparable  ( override compareTo() ) 




class Movie implements Comparable<Movie>
{
	private int rating;
	private String name;
	private int year;

	@Override
	public int compareTo(Movie o) 
	{
		
		return this.year-o.year;
	}

	
	
	public Movie(int rating, String name, int year) {
		super();
		this.rating = rating;
		this.name = name;
		this.year = year;
	}

	public int getRating() {
		return rating;
	}

	public String getName() {
		return name;
	}

	public int getYear() {
		return year;
	}

	@Override
	public String toString() {
		return "Movie [rating=" + rating + ", name=" + name + ", year=" + year + "]";
	}
		
}

public class Day17_5 {

	public static void main(String[] args) 
	{
		ArrayList<Movie> al=new ArrayList<Movie>();
		al.add(new Movie(3,"m1",2021));
		al.add(new Movie(4,"m2",2020));
		al.add(new Movie(5,"m3",2022));
		al.add(new Movie(2,"m4",2019));
		System.out.println("***BEFORE SORT****");
		for(Movie m:al)
			System.out.println(m);
		
		Collections.sort(al);
		System.out.println("***AFTER SORT****");
		for(Movie m:al)
			System.out.println(m);
		

	}

}
