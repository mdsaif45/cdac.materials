import java.util.HashSet;
import java.util.Objects;

class Employee
{
	String name;
	int id;
	public Employee(String name, int id) {
		super();
		this.name = name;
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Override
	public int hashCode() {
		return Objects.hash(id, name);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		return id == other.id && Objects.equals(name, other.name);
	}
	
	
	
}



public class Day17_3 {

	public static void main(String[] args) 
	{
		HashSet<Employee> set=new HashSet<Employee>();
		Employee e1 = new Employee("Akshita",1);
		Employee e2= new Employee("Sparsh",2);
		set.add(e1);
		set.add(e2);
		
		Employee key=new Employee("Sparsh",2);
		System.out.println("KEY :"+key);
		System.out.println(set);
		set.add(key); 
		
		System.out.println(set);
		
		
	
		System.out.println("Contains = "+set.contains(key)); //true
		
	

	}

}

/*

class Employee
{
	String name;
	int id;
	public Employee(String name, int id) {
		super();
		this.name = name;
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	
	
}



public class Day17_3 {

	public static void main(String[] args) 
	{
		HashSet<Employee> set=new HashSet<Employee>();
		Employee e1 = new Employee("Akshita",1);
		Employee e2= new Employee("Sparsh",2);
		set.add(e1);
		set.add(e2);
		
		Employee key=new Employee("Sparsh",2);
		System.out.println("KEY :"+key);
		System.out.println(set);
		set.add(key); //Sparsh 2 (duplicate entry of data )
		//when we have created key , it is a new reference
		//duplication of reference is not there 
		//thats why duplicate data is entered in HashSet 
		System.out.println(set);
		
		
	
		System.out.println("Contains = "+set.contains(key)); //False 
		
	

	}

}
*/