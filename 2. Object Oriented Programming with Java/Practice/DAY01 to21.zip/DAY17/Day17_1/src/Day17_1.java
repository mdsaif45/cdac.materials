import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;


public class Day17_1 {

	public static void main(String[] args) 
	{
		LinkedHashSet<String> s=new LinkedHashSet<String>();
		s.add("Akshita");
		s.add("Sunbeam");
		s.add("Pune");
		System.out.println(s+" "+s.hashCode());
		LinkedHashSet<String> s1=(LinkedHashSet<String>) s.clone();
		//s.clone() it will clone s and returns one Object
		//so we need to typecast Object in proper format 
		
		LinkedHashSet<String> s2=s; //reference copy
		System.out.println(s+ " "+s.hashCode()); //shallow copy
		System.out.println(s1+ " "+s1.hashCode()); //shallow copy
		System.out.println(s2+ " "+s2.hashCode()); //shallow copy
		
		s.add("Trainer");
		System.out.println("S = "+s+" "+s.hashCode());
		System.out.println("S1 = "+s1+" "+s1.hashCode());
		System.out.println("S2 = "+s2+" "+s2.hashCode());
				
		
		
	}
	
	}


/*
public class Day17_1 {

	public static void main(String[] args) 
	{
		//Set<String> s=new HashSet<String>();
		//Set<String> s=new TreeSet<String>();
		Set<String> s=new LinkedHashSet<String>();
		s.add("ABC");
		s.add("DEF");
		s.add("PQR");
		s.add("ABC");
		s.add("abc");
		System.out.println(s);
		
	}
}

*/

/*
public class Day17_1 {

	public static void main(String[] args) 
	{
		Set<Integer> s=new HashSet<Integer>();
		s.add(10);
		s.add(25);
		s.add(null);
		s.add(35);
		s.add(null);
		System.out.println(s);
		System.out.println(s.contains(25)); //true
		System.out.println(s.contains(45)); //false
		System.out.println("size = "+s.size());
		
		System.out.println(s.getClass());
		
	}
}
*/

/*

public class Day17_1 {

	public static void main(String[] args) 
	{
		Set<Integer> s=new LinkedHashSet<Integer>();
		s.add(10);
		s.add(15);
		s.add(5);
		s.add(40);
		s.add(25);
		s.add(40); //duplicate is eliminated 
		System.out.println(s);
	}

}

*/


/*
public class Day17_1 {

	public static void main(String[] args) 
	{
		Set<Integer> s=new TreeSet<Integer>();
		s.add(10);
		s.add(15);
		s.add(5);
		s.add(40);
		s.add(25);
		s.add(40);
		System.out.println(s);
	}

}

*/

/*
public class Day17_1 {

	public static void main(String[] args) 
	{
		Set<Integer> s=new HashSet<Integer>();
		s.add(10);
		s.add(15);
		s.add(5);
		s.add(40);
		s.add(25);
		s.add(40);
		System.out.println(s);
	}

}
*/