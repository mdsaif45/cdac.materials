import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

//create a class Movie 
// compare the movie based on year , based on rating , based on name 

//if we wish to sort the Movie based multiple parameters 
//then solution is Comparator (interface) java.util package
//	and override compare(T o1, T o2) method 

// for using Comparator 
//1. create a class implements Comparator
//2. override compare() 
//3. call Collections.sort() 




class Movie implements Comparable<Movie>
{
	private int rating;
	private String name;
	private int year;

	@Override
	public int compareTo(Movie o) 
	{	
		return this.year-o.year;
	}

	
	public Movie(int rating, String name, int year) {
		super();
		this.rating = rating;
		this.name = name;
		this.year = year;
	}

	public int getRating() {
		return rating;
	}

	public String getName() {
		return name;
	}

	public int getYear() {
		return year;
	}

	@Override
	public String toString() {
		return "Movie [rating=" + rating + ", name=" + name + ", year=" + year + "]";
	}
		
}


//class to compare Movies by Ratings (use Comparator)
class RatingCompare implements Comparator<Movie>
{

	@Override
	public int compare(Movie o1, Movie o2) {
		if(o1.getRating()<o2.getRating())
			return -1;
		if(o1.getRating()>o2.getRating())
			return 1;
		else 
			return 0;
	}
	
}


class NameCompare implements Comparator<Movie>
{

	@Override
	public int compare(Movie o1, Movie o2) 
	{
		return o1.getName().compareTo(o2.getName());
	}
	
}


public class Day17_6 {

	public static void main(String[] args) 
	{
		ArrayList<Movie> al=new ArrayList<Movie>();
		al.add(new Movie(3,"m4",2021));
		al.add(new Movie(4,"m2",2020));
		al.add(new Movie(5,"m1",2022));
		al.add(new Movie(2,"m3",2019));
		
		RatingCompare rc=new RatingCompare();
		NameCompare nc=new NameCompare();
		System.out.println("***BEFORE SORT BASED on RATING ****");
		for(Movie m:al)
			System.out.println(m);
		
		Collections.sort(al,rc);
		System.out.println("***AFTER SORT BASED on RATING ****");
		for(Movie m:al)
			System.out.println(m);
		
		
		System.out.println("***BEFORE SORT BASED on NAME ****");
		for(Movie m:al)
			System.out.println(m);
		
		Collections.sort(al,nc);
		System.out.println("***AFTER SORT BASED on NAME ****");
		for(Movie m:al)
			System.out.println(m);

	}

}
/*
public class Day17_6 {

	public static void main(String[] args) 
	{
		ArrayList<Movie> al=new ArrayList<Movie>();
		al.add(new Movie(3,"m1",2021));
		al.add(new Movie(4,"m2",2020));
		al.add(new Movie(5,"m3",2022));
		al.add(new Movie(2,"m4",2019));
		System.out.println("***BEFORE SORT BASED on Year ****");
		for(Movie m:al)
			System.out.println(m);
		
		Collections.sort(al);
		System.out.println("***AFTER SORT BASED on Year ****");
		for(Movie m:al)
			System.out.println(m);
		

	}

}

*/
