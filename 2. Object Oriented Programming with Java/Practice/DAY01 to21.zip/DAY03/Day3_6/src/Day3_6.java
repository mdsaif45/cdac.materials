
public class Day3_6 {

	public static void main(String[] args) 
	{
			System.out.println(Integer.MAX_VALUE+"  "+Integer.MIN_VALUE);
			System.out.println(Float.MAX_VALUE+"  "+Float.MIN_VALUE);
			System.out.println((int)Character.MAX_VALUE+"  "+(int)Character.MIN_VALUE);
		
	}

}
