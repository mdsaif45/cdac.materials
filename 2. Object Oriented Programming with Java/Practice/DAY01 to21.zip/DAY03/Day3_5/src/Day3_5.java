
//TYPECASTING
//boxing and unboxing
// UNBOXING = NON PRIMITIVE TO PRIMITIVE
// BOXING = PRIMITIVE TO NON PRIMITIVE

// eg. (args[0]) ===> String ==> NP and ref
// int i ==> int ==> p ==> value
// with the help of Wrapper classes
// NP to P ===> UNBOXING 


//int to String ==> boxing ==> toString()

// char ch=String.valueOf("Akshita").charAt(0);
// char ch = return String . charAt(0)
// char ch = "Akshita" .charAt(0)
// char ch = String Object (String object) UNBOXING 
// String to charAt(0) fetch single character
// single character inside a char ch ==> BOXING 




// String to int ==> parseInt() 
// int to String ==> toString()



public class Day3_5 {

	public static void main(String[] args) 
	{
		char ch=String.valueOf("Akshita").charAt(0);
		//char ch = "Akshita".charAt(0)
		// char ch = A 
		System.out.println(ch);
	}

}




/*
public class Day3_5 {

	public static void main(String[] args) 
	{
		int num=50;
		String str=Integer.toString(num); // boxing
		//num ==> Primitive , value type
		//str ==> Non primitive, reference type 
		System.out.println(str);
		
	}
}

*/



/*
public class Day3_5 {

	public static void main(String[] args) 
	{
		Integer i=new Integer("1234"); // i is object of Integer class
		// this is depreciated 
		int num=i.intValue(); // intValue() non static method of Integer class
		// converting NP to P
		// unboxing
		System.out.println("Num = "+num);
		

	}

}

*/


// Non Primitive to primitive ==> UNBOXING 
// String to int value ===> parseInt()
// String to float value ==> parseFloat()
// Integer to int ====> intValue()
// Double to double ==>  doubleValue()
// Float to float ==> floatValue()


/*

public class Day3_5 {

	public static void main(String[] args) 
	{
		String str="45"; //str is non primitive 
		int number  = Integer.parseInt(str); // unboxing
		System.out.println("Number = "+number);
		

	}

}

*/
