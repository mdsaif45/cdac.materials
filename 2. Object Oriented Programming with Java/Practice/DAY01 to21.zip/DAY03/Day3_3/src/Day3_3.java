import java.util.Scanner;


//AIOOBE 
// NFE
// IME

//this program is used to take input from the user
// by using Scanner class ===> java.util 
public class Day3_3
{
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Number : ");
		int i = sc.nextInt();
		System.out.println("Enter Name : ");
		String str = sc.next();
		System.out.println("I = "+i+ " Str = "+str);
		int val=Integer.parseInt(str); // NFE 
		System.out.println("Val "+val);
	}
}



/*

 // This program takes input using cmd line arguments 
  
public class Day3_3 {

	public static void main(String[] args) 
	{
		int i=Integer.parseInt(args[0]);
		String str=args[1];
		double d=Double.parseDouble(args[2]);
		System.out.println("I = "+i);
		System.out.println("Str = "+str);
		System.out.println("D = "+d);

	}

}


*/