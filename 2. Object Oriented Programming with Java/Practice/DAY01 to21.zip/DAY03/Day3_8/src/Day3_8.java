import java.util.Scanner;

class Employee
{
	String name; //first field
	int id; // second field 
	int salary; //third field 
	Scanner sc=new Scanner(System.in); // fourth field  
	
	void accept()
	{
		System.out.println("Enter Name ");
		name=sc.next();
		System.out.println("Enter EmpID ");
		id=sc.nextInt();
		System.out.println("Enter Salary ");
		salary=sc.nextInt();
		
	}
	void disp()
	{
		System.out.println("Name = "+name+" EMPID = "+id+" Salary = "+salary);
	}
}


public class Day3_8 {

	public static void main(String[] args) 
	{
		Employee eobj=new Employee(); //created object of Employee class 
		// Classname objname = new classname(); 
		eobj.accept();
		eobj.disp();
		
		Employee eobj1=new Employee();
		//whenever we allocate memory to object 
		// by default it is assigned with default values 
		eobj1.disp();
		eobj1.accept();
		eobj1.disp();

	}

}
