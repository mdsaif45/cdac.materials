
public class Day3_2 {

	public static void main(String[] args) 
	{
		String s1="123"; // s1 is object of String class  (s1 is a variable)
		// s1 is of type String
		//s1 is storing integer type of data
		System.out.println("S1 "+s1.getClass()); //getClass() is a method returns name of the class 
		int num1=Integer.parseInt(s1);
		System.out.println("Num1 "+num1);
		
		String s2="125.30f"; // s2 is String holding float
		float f1=Float.parseFloat(s2);
		System.out.println("F1 = "+f1);
		
		String s3="3.5"; //it is double value 
		double d=Double.parseDouble(s3);
		System.out.println("D = "+d);
		
		String s4="123abcd";
		int n1=Integer.parseInt(s4); // NFE (NumberFormatException)
		System.out.println("N1 = "+n1);
		
	}

}
