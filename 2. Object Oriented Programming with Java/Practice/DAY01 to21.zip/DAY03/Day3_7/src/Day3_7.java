import java.util.Scanner;

public class Day3_7 {

	public static void main(String[] args) 
	{
		String name;
		int age;
		float salary;
		int num=32;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Name = ");
		name=sc.next();
		System.out.println("Enter Age = ");
		age=sc.nextInt();
		System.out.println("Enter Salary = ");
		salary=sc.nextFloat();
		System.out.println("Name = "+name+" Age = "+age+" Salary = "+salary);
		System.out.printf("\n %s %d %f",name,age,salary);
		System.out.printf("\n %10s %10d %10.2f",name,age,salary);
		System.out.printf("\n Num = %d Num = %x Num = %o",num,num,num);
	}
}



/*
public class Day3_7 {

	public static void main(String[] args) 
	{
		System.out.println((int)Character.MIN_VALUE);
		System.out.println((int)Character.MAX_VALUE); 

	}

}
*/