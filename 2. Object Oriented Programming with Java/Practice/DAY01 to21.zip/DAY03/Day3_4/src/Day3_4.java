

//CONVERSION FROM ONE PRIMITIVE TO ANOTHER PRIMITIVE 
// NARROWING AND WIDENING 

// conversion of one type to another is called as TYPECASTING
// HIGHER BYTE INTO LOWER ===> NARROWING
// LOWER BYTES INTO HIGHER ==> WIDENING 


public class Day3_4
{

	public static void main(String[] args) 
	{
		int n1=35; // Primitive / Value type 
		double n2=n1; // primitive 
		//double n2=(double)n1; // Equivalent to double n2=n1 
		//WIDENING
		//INCASE OF WIDENING THERE IS NO NEED TO EXPLICITELY 
		//WRITE THE CONVERSION
		
		System.out.println("N1 = "+n1+" N2 = "+n2);
		 
		
	}
}



/*
public class Day3_4 {

	public static void main(String[] args) 
	{
		float fval=5.3f; // value type  //float 
		//int i = fval;  // javac error 
		int num=(int)fval; // VALID 
		// IN CASE OF NARROWING IT IS COMPULSORY
		 // TO TYPECAST IT OTHERWISE javac ERROR 
		System.out.println("Fval = "+fval );
		System.out.println("Num = "+num);

	}

}
*/


/*
public class Day3_4 {

	public static void main(String[] args) 
	{
		double d=50; // value type  // double 8bytes 
		int i = (int)d;  // value type   // 4bytes // javac error 
		System.out.println("D= "+d+" I = "+i);

	}

}

*/

	
		