package p1;

public class Demo 
{
	void disp()
	{
		System.out.println("inside disp function");
	}
}
