package p3;
import java.util.Scanner;

import p1.Demo;

public class Trial 
{
	Scanner sc=new Scanner(System.in);

}
