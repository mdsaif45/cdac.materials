import java.util.ArrayList;
import java.util.LinkedList;



/*
class Student
{
	int rollno;
	int age;
	String name;
	
	Student(int rollno,int age,String name)
	{
		this.rollno=rollno;
		this.age=age;
		this.name=name;
	}

	
}

public class Day15_5 {

	public static void main(String[] args) 
	{
		Student s1=new Student(1,25,"P1"); //s1 non primitive object 
		Student s2=new Student(2,22,"P2");
		Student s3=new Student(3,30,"P3");
		
		LinkedList<Student> a1=new LinkedList<Student>();
		a1.add(s1); //adding object in array list 
		a1.add(s2);
		a1.add(s3);
		
		System.out.println(a1);
		
		for(int i=0;i<a1.size();i++)
		{
			System.out.println("Rollno = "+a1.get(i).rollno+" Age "+a1.get(i).age+" Name = "+a1.get(i).name);
		}
		
		//for each student s inside arraylist a1 
		//display each student s 
		for(Student s:a1)
			System.out.println(s); //s.toString()
		
		System.out.println("Second Student Name  "+a1.get(1).name);
		//we can access AL elements in random way by using get() method 
		
		
		
		
		
		

	}

}
*/




/*

public class Day15_5 {

	public static void main(String[] args) 
	{
		LinkedList<Integer> l1=new LinkedList<Integer>();
		l1.add(15);
		l1.add(25);
		l1.add(35);
		System.out.println(l1);
		System.out.println(l1.get(1));
	}
}

*/





