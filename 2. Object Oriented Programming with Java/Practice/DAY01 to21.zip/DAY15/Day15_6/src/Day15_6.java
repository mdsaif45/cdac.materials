import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;

public class Day15_6 {

	public static void main(String[] args) {
		LinkedList<String> l1=new LinkedList<String>();
		l1.add("Akshita");
		l1.add("Sunbeam");
		l1.add("Pune");
		System.out.println(l1);
		l1.addFirst("Chanchlani"); //creates a head node and adds data 
		System.out.println(l1);
		l1.addLast("Trainer"); // creates a node and adds data at the end 
		System.out.println(l1);
		System.out.println(l1.contains("Akshita")); // search in LinkedList
		System.out.println("First Node =  "+l1.getFirst()); //return head node 
		System.out.println("Last Node = "+l1.getLast()); //return last/tail node 
		System.out.println("get at index = "+l1.get(1)); //will return some specific node data 
		//though we have passed index but as far as LinkedList 
		//implementation is concerned the accessing of elements
		//will be in sequential way 
		
		l1.set(2, "Sparsh"); // it will add node in between the LinkedList
		System.out.println(l1);
		System.out.println("Sorted LinkedList ");
		Collections.sort(l1);
		System.out.println(l1);
		
		System.out.println("");
		Iterator<String> itr=l1.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		
		
	}

}
