import java.util.Iterator;
import java.util.Stack;

public class Day15_7 {

	public static void main(String[] args) 
	{
		Stack<Integer> stk=new Stack<Integer>();
		stk.push(10); //top 4
		stk.push(20); //top 3
		stk.push(30); // top 2
		stk.push(5); //top 1 
		System.out.println(stk.search(30));
		System.out.println(stk.search(10));
		System.out.println(stk.contains(10));
		System.out.println(stk.search(40));
		
	}
}

/*
public class Day15_7 {

	public static void main(String[] args) 
	{
		Stack<Integer> stk=new Stack<Integer>();
		stk.push(10);
		stk.push(20);
		stk.push(30);
		stk.push(5);
		stk.push(15);
		
	//	System.out.println(stk);
		//stk.pop();
		//System.out.println(stk);
		
		//Iterator<Integer> itr=stk.iterator();
		//while(itr.hasNext()) //iterator has created for stack 
		//{
			//System.out.print(" "+itr.next());
			//stk.push(99); //fail-fast Condition : modification is performed on stack while the iteration is going on 
		//}
		
		for(int i=0;i<stk.size();i++)
		{
			System.out.print(" "+stk.get(i));
			//stk.push(99); //not allowed //Unexpected Result 
		}
		
		stk.pop();
		stk.pop();
		stk.pop();
		stk.pop();
		stk.pop();
		stk.pop(); //Exception : EmptyStackException
		
		

	}

}
*/
