
import java.lang.reflect.*;

//Requirement : to know the class name
//to know the methods,fields,constructors of ReflectionDemo class

class ReflectionDemo
{
	private String str;
	
	public ReflectionDemo()
	{
		str="Akshita Sunbeam";
	}
	
	public void method1()
	{
		System.out.println("Inside Method1 = "+str);
	}
	
	
	public String getStr() {
		return str;
	}

	public void method2(int num1)
	{
		System.out.println("Inside Method2 = "+num1);
	}
	
	private void method3()
	{
		System.out.println("Inside Method3 ");
	}
	
	
	
}

public class Day20_1 {

	public static void main(String[] args) throws NoSuchMethodException, SecurityException, NoSuchFieldException, IllegalArgumentException, IllegalAccessException, InvocationTargetException
	{
		ReflectionDemo obj=new ReflectionDemo();
		
		Class cls=obj.getClass(); //upcasting
		System.out.println("The name of the class = "+cls.getName());
		
		//obj.method1();
		//obj.method2(50);
		//obj.method3();
		
		Method m1=cls.getDeclaredMethod("method1");
		System.out.println("First method declaration = "+m1);
		m1.invoke(obj);
		
		Method m2=cls.getDeclaredMethod("method2", int.class);
		//method2() is taking one argument of type int
		//so we need to pass type parameter at the time of using of getDeclaredMethod()
		
		System.out.println("Second method declaration = "+m2);
		m2.invoke(obj,45);
				
		Method m3=cls.getDeclaredMethod("method3");
		System.out.println("Third method declaration = "+m3);
		m3.setAccessible(true); // because method3() was private 
		m3.invoke(obj);
		
		
	}
}

/*

public class Day20_1 {

	public static void main(String[] args) throws NoSuchMethodException, SecurityException, NoSuchFieldException, IllegalArgumentException, IllegalAccessException
	{
		ReflectionDemo obj=new ReflectionDemo();
		
		System.out.println("Initial State str= "+obj.getStr());
		Class cls=obj.getClass(); //upcasting
		System.out.println("The name of the class = "+cls.getName());
		
		
		Constructor cstr=cls.getConstructor();
		System.out.println("Constructor Declaration = "+cstr);
		System.out.println("Name of Constructor = "+cstr.getName());
		
	
		System.out.println("Methods Information");
		Method[] m= cls.getMethods();
		for(Method mtd:m)
			System.out.println(mtd.getName());
		
		System.out.println("Field Information");
		Field f = cls.getDeclaredField("str");
		System.out.println(f);
		//f.set(obj, "JAVA"); //throw EXCEPTION 
		//please set the field f (indirectly str) of obj (object of ReflectionDemo)
		// data is to be set as JAVA 
		// We can not access private fields outside the class
		// throwing IllegalAccessException
		
		f.setAccessible(true);
		f.set(obj, "JAVA");
		
		System.out.println("After Setting new Value "+obj.getStr());
	}
	

}


*/