package p1;

import java.lang.annotation.Annotation;

public class Day20_3
{

	public static void main(String[] args) 
	{
		Class c=Book.class;
		Annotation[] an = c.getDeclaredAnnotations();
		// an will store all the annotations which are used
		//inside the Book class
		
		for(Annotation a:an) //iterating through all the annotations 
		{
			if(a instanceof Author) //if a is annotation of type Author 
				//if it is yes , then we are trying to fetch the values of annotation
			{
				Author value=(Author) a;
				System.out.println(value.firstName());
				System.out.println(value.lastName());
				
				
				
			}
			
			
		}
		
		

	}

}
