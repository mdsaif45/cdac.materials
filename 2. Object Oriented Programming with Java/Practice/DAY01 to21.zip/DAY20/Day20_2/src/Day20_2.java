import java.util.ArrayList;
import java.util.Scanner;




public class Day20_2 {

	
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static void main(String[] args) 
	{
		
		ArrayList al=new ArrayList(); // RAW TYPE 
		al.add(10);
		al.add("akshita");
		al.add(30);
		
	}
}

/*
public class Day20_2 {

	
	
	public static void main(String[] args) 
	{	
		@SuppressWarnings("deprecation")
		Integer i=new Integer(45);
		System.out.println(i);
		
		@SuppressWarnings("resource")
		Scanner sc=new Scanner(System.in);
		int val=sc.nextInt();
		System.out.println(val);
		
		
	}

}
*/

/*

//TARGET for override is toString()

class Student
{
	String name;

	@Override
	public String toString() {
		return "Student [name=" + name + "]";
	}
	
}

*/

/*
class Test
{
	void printData()
	{
		System.out.println("Inside printData of Test class");
	}
}

class Demo extends Test
{
	@Override
	void printData()
	{
		System.out.println("Inside Demo class");
		super.printData();
	}
}


public class Day20_2 {

	public static void main(String[] args) 
	{
		Demo dobj=new Demo();
		dobj.printData();

	}

}

*/
