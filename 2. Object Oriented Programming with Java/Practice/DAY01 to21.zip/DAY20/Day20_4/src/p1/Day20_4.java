package p1;

import java.lang.annotation.Annotation;

public class Day20_4
{

	public static void main(String[] args) 
	{
		@SuppressWarnings("rawtypes")
		Class c=Book.class;
		Annotation[] an = c.getDeclaredAnnotations();
		// an will store all the annotations which are used
		//inside the Book class
		
		
		
		
			for(Annotation a:an) //iterating through all the annotations 
		{
			if(a instanceof Author) //if a is annotation of type Author 
				//if it is yes , then we are trying to fetch the values of annotation
			{
				System.out.println("Display annotation for author");
				Author value=(Author) a;
				System.out.println(value.firstName());
				System.out.println(value.lastName());		
				
			}
			else
			{
				System.out.println("Displaying Annotation Values from Organization ");
				
				Organization org=(Organization)a;
				System.out.println(org.name());
				System.out.println(org.location());
			}
			
		}
		
		
		
		System.out.println("Displaying Annotation Values from Book1 Class ");
		@SuppressWarnings("rawtypes")
		Class c1=Book1.class;
		Annotation[] an1 = c1.getDeclaredAnnotations();
		
		
		for(Annotation a1:an1) //iterating through all the annotations 
		{
			if(a1 instanceof Author) //if a is annotation of type Author 
				//if it is yes , then we are trying to fetch the values of annotation
			{
				Author value=(Author) a1;
				System.out.println(value.firstName());
				System.out.println(value.lastName());		
				
			}
			
		}
		

	}

}

