package p1;

@Author(firstName="Akshita",lastName="Chanchlani")
@Organization(name="Sunbeam",location="Pune")
public class Book 
{

}
