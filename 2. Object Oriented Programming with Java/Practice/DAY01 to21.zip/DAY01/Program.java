// Recommendation : use the same name as file name
// for the class in which main() is available

class Program
{
    public static void main(String args[])
    {
        System.out.println("Welcome you all at Sunbeam");
        //println() is defined inside PrintStream class
        // out is a static object created inside System class
        // static PrintStream out;
        
        
    }
}

// public ==> it can be accessed outside the class 
// who calls main() ==> OS 
// OS is external to your program 

// main() is defined in class Program
// have we created object of class Program??? No
// if we wish to give a call to main() function
// I do not create object of the class in which main() is defined
// thats why we declare main as static compulsory

// main() is not returning anything
//main() is having return type as void 

// main is itself a keyword which indicates as a entry point function

//String args[] : if we want to take command line arguments 
//we take it using String args[]


// Home work 
//C++ ==> class, object, constructor , destructor , static 
// revise
// variable, datatype, operator, control statments 




