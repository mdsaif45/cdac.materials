
// develop a application in which take input from user one number command line arguments
// then check if number is >100 then display some messege 

//donot use if and else
//use concept of exception handling 

//is we wish to create user defined exception in java
//1. we need to create own class extends Exception
//2. create a String argument constructor to pass custom messege 


class NumberIsGreaterException extends Exception
{
	NumberIsGreaterException()
	{
		System.out.println("User Exception Occured");
	}
	
}

public class Day13_4
{

	public static void main(String[] args) 
	{
		try
		{
		int m=Integer.parseInt(args[0]);
			if(m>100)
			{
				throw new NumberIsGreaterException();
			}
		}
		catch(NumberIsGreaterException e)
		{
			//System.out.println(e);
			e.printStackTrace();
		}
	}

}
