import java.util.Scanner;

//All sub classes of RunTimeException class are called as UNCHECKED EXCEPTION
// It is not compulsory to handle unchecked exception while development of program
// if we have not handled unchecked exceptions JVM will handle it 


//Checked Exceptions must be handled compulsory in the program
//while development of the programs 
//otherwise it will give java compile time error as Unhandled Exception

//throws is used for delegation of Exception
//throws is used to inform java compiler that
//this particular method is going to handle the exception on its own
//that means caller of the program will handle the unhandled exception
//[DELEGATION]

//sleep() method may throw checked Exception that is InterrruptedException
//Rule: we need to handle checked exception
//otherwise it gives unhandled exception error
//Solution :
//1. use try and catch prior to the use of method 
//2. delegate it to the caller of the method by using throws keyword

//if we write throws IE infornt of main()
// so it means sleep() is called from main() , main() is caller of the method
//i am giving duty to main() to handle this unhandled exception

/*
public class Day13_2 {

	public static void main(String[] args)throws InterruptedException 
	{
		System.out.println("hello");
		Thread.sleep(2500);
		System.out.println("students ");
	}
}
*/


/*
//we have handled checked exception by writing try and catch block 
public class Day13_2 {

	public static void main(String[] args)
	{
		System.out.println("Hello");
		try 
		{
			Thread.sleep(2500);
		}
		catch (InterruptedException e)
		{
			e.printStackTrace();
		}
		System.out.println(" everyone");
	}

}
*/
/*
public class Day13_2 {

	public static void main(String[] args)
	{
		//int num=Integer.parseInt(args[0]);
		//System.out.println("Num = "+num);
		
		//int result=8/0;
		//System.out.println("Result = "+result);
		
		//int a[]=new int[-3]; // NegativeArraySizeException
		
		
		
	}
}
*/


/*
//try block handler is used to check particular resource 


public class Day13_2 {

	public static void main(String[] args)
	{
		int a,b;
		
		try(Scanner sc=new Scanner(System.in)) //try block handler / try with resources 
		{
		
		System.out.println("Enter First Number ");
		a=sc.nextInt();
		System.out.println("Enter Second Number ");
		b=sc.nextInt();
		
		
			int result=a/b;
			System.out.println("Result "+result);
		
		}
	
	}

}

*/


/*
public class Day13_2 {

	public static void main(String[] args)
	{
		int a,b;
		
		try(Scanner sc=new Scanner(System.in)) //try block handler / try with resources 
		{
		
		System.out.println("Enter First Number ");
		a=sc.nextInt();
		System.out.println("Enter Second Number ");
		b=sc.nextInt();
		
		
			int result=a/b;
			System.out.println("Result "+result);
		
		}
		
		
		finally
		{
			System.out.println("inside finally block");
		}
		
		

	}

}
*/
