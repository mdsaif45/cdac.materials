import java.util.Scanner;

// Speed of vehicle 


class SpeedUtils
{
	public static final int MIN_SPEED;
	public static final int MAX_SPEED;
	
	static
	{
		MIN_SPEED=30;
		MAX_SPEED=80;
	}
	
	public static void validatespeed(int speed) throws SpeedOutOfRangeException
	{
		System.out.println("SPEED = "+speed);
		if(speed <MIN_SPEED)
				throw new SpeedOutOfRangeException("You are too slow");
		if(speed >MAX_SPEED)
				throw new SpeedOutOfRangeException("You are too fast");
		
	}
}

class SpeedOutOfRangeException extends Exception
{
	SpeedOutOfRangeException(String mesg)
	{
		super(mesg);
	}
}


public class Day13_6
{
	public static void main(String args[]) throws SpeedOutOfRangeException 
	{
	
		try(Scanner sc=new Scanner(System.in))
		{
			System.out.println("Enter Speed ");
			SpeedUtils.validatespeed(sc.nextInt());
		
		}
	}

}
