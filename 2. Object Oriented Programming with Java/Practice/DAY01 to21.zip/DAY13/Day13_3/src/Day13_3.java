
public class Day13_3 {

	public static void main(String[] args) 
	{
		System.out.println("sunbeam");
		try {
			Thread.sleep(2500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("akshita");
		}

}
