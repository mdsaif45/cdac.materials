import java.util.InputMismatchException;
import java.util.Scanner;






class WrongDataException extends Exception
{
	WrongDataException()
	{
		
	}
}

public class Day13_5
{
	public static void main(String args[]) 
	{
		Scanner sc=new Scanner(System.in);
		int a,b;
		try
		{
			System.out.println("Enter Number ");
			a=sc.nextInt();
			if(a<0)
			{
				throw new InputMismatchException();
			}
			System.out.println("Enter Number ");
			b=sc.nextInt();
			if(b>50)
			{
				throw new WrongDataException();
			}
			System.out.println("A = "+a+ " B = "+b);
		}
		catch(InputMismatchException e)
		{
			System.out.println("input is not given correctly");
		}
		catch(WrongDataException e)
		{
			System.out.println("for variable b data is wrong ");
		}
	}

}



/*
public class Day13_5
{
	public static void main(String args[]) 
	{
		Scanner sc=new Scanner(System.in);
		int a,b;
		System.out.println("Enter Number ");
		a=sc.nextInt();
		System.out.println("Enter Number ");
		b=sc.nextInt();
		System.out.println("A = "+a+ " B = "+b);
	}

}

*/
