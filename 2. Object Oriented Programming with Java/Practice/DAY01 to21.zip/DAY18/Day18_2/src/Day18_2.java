import java.io.File;
import java.io.IOException;


public class Day18_2 {

	public static void main(String[] args) 
	{
		String path="D:/PG-CDAC.txt"; //ABSOLUTE PATH
		File fobj=new File(path); 
		//fobj is object of File type holding reference of "Test.txt"
		boolean status;
		try {
			status = fobj.createNewFile();
			System.out.println("File Creation Status ="+status);
		} 
		catch (IOException e)
		{
			
			e.printStackTrace();
		}
		

	}

}





/*
public class Day18_2 {

	public static void main(String[] args) 
	{
		String path="Sunbeam.txt"; //RELATIVE PATH 
		File fobj=new File(path); 
		//fobj is object of File type holding reference of "Test.txt"
		boolean status;
		try {
			status = fobj.createNewFile();
			System.out.println("File Creation Status ="+status);
		} 
		catch (IOException e)
		{
			
			e.printStackTrace();
		}
		

	}

}

*/


/*
public class Day18_2 {

	public static void main(String[] args) throws IOException
	{
		String path="Test.txt";
		File fobj=new File(path); 
		//fobj is object of File type holding reference of "Test.txt"
		boolean status = fobj.createNewFile();
		System.out.println("File Creation Status ="+status);

	}

}
*/