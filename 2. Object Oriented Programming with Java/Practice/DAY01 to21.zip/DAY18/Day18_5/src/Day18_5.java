import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

// take choice from user
//1. write the single byte to binary file (FileOutputStream)
//2. read a single byte from binary file (FileInputStream)
//3. exit 

public class Day18_5 
{
	static Scanner sc=new Scanner(System.in);
	static String path="Demo.dat";
	
	public static int menuList()
	{
		System.out.println(" Enter Choice 0.Exit 1.Write 2.Read");
		return sc.nextInt();
	}
	
	
	public static void writeRecord()
	{
		FileOutputStream fos=null;
		
		try 
		{
			fos=new FileOutputStream(new File(path));
			//fos=new FileOutputStream(new File("File.data"));
			//Constructor calling = FileOutputStream(String name)
			byte data=123; //0111 1011 //byte array 
			fos.write(data);
			//	write(byte[] b)
			System.out.println("DATA is written successfully in binary file ");
			
		}
		catch (FileNotFoundException e) 
		{
			e.printStackTrace();
		} 
		catch (IOException e) {
			
			e.printStackTrace();
		}
		
	}
	public static void readRecord()
	{
		FileInputStream fis=null;
		
		try 
		{
			fis=new FileInputStream(new File(path));
			//FileInputStream(String name)
			
			byte data=(byte)fis.read();
			
			System.out.println("Data Reading Success !! "+data);
			
			
		}
		catch (FileNotFoundException e) 
		{
			
			e.printStackTrace();
		}
		catch (IOException e) {
			
			e.printStackTrace();
		}
		
	}
	public static void main(String[] args) 
	{
		int choice;
		while((choice=menuList())!=0)
		{
			switch(choice)
			{
			case 1:
				writeRecord();
			break;
			case 2:
				readRecord();
			break;
			}
		}

	}

}
