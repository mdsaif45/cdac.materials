import java.io.File;
import java.io.IOException;



public class Day18_3 {

	public static void main(String[] args) throws IOException 
	{
		String pathName="JAVA";
		File fobj=new File(pathName);
		boolean status=fobj.mkdir();
		System.out.println("Director Created " +status );
		
		System.out.println("deleting the directory");
		status=fobj.delete();
		System.out.println("Directory deletion status ="+status);
	}
}


/*

public class Day18_3 {

	public static void main(String[] args) throws IOException 
	{
		String pathName="File.txt";
		File fobj=new File(pathName);
		//fobj is File class object , when we create object
		// constructro gets called , to initialize the object
		//File(String pathname)
		boolean status=fobj.delete();
		//delete() is method defined inside File class
		//delete() is non static
		// to give a call to delete() method we need Object of File class
		
		System.out.println(status);

	}

}
*/

/*
public class Day18_3 {

	public static void main(String[] args) throws IOException 
	{
		String pathName="File.txt";
		File fobj=new File(pathName);
		boolean status=fobj.createNewFile();
		System.out.println(status);

	}

}
*/
