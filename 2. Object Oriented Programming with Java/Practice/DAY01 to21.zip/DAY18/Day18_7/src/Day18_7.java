import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

// take choice from user
//1. write the single byte to binary file (FileOutputStream)
//2. read a single byte from binary file (FileInputStream)
//3. exit 

//try block handler 

public class Day18_7 
{
	static Scanner sc=new Scanner(System.in);
	static String path="Demo.dat";
	
	public static int menuList()
	{
		System.out.println(" Enter Choice 0.Exit 1.Write 2.Read");
		return sc.nextInt();
	}
	
	
	public static void writeRecord() throws Exception
	{		
		try(FileOutputStream fos=new FileOutputStream(new File(path)); )
		{
			
			for(char ch='A';ch<='Z';ch++)
				fos.write(ch);
			
			System.out.println("DATA is written successfully in binary file ");
			
		}	
		
	}
	public static void readRecord()throws Exception
	{
		
		try(FileInputStream fis=new FileInputStream(new File(path)); )
		{
			int data;
			while((data=fis.read())!=-1)
			{
				System.out.print((char)data+ " ");
			}
		
		}
	
	}
	public static void main(String[] args) throws Exception
	{
		int choice;
		while((choice=menuList())!=0)
		{
			switch(choice)
			{
			case 1:
				writeRecord();
			break;
			case 2:
				readRecord();
			break;
			}
		}

	}

}
