import java.io.File;
import java.io.IOException;


public class Day18_4 {

	public static void main(String[] args) throws IOException 
	{
		String pathName="File.txt";
		File fobj=new File(pathName);
		boolean status=fobj.createNewFile();
		System.out.println(status);
		System.out.println("Name = "+fobj.getName());
		System.out.println("Absoulte Path = "+fobj.getCanonicalPath());
		System.out.println("Parent = " +fobj.getParent());
		System.out.println("Path = "+fobj.getPath());//relative
	}

}

