import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

// take choice from user
//1. write the single byte to binary file (FileOutputStream)
//2. read a single byte from binary file (FileInputStream)
//3. exit 

//try block handler 

public class Day18_6 
{
	static Scanner sc=new Scanner(System.in);
	static String path="Demo.dat";
	
	public static int menuList()
	{
		System.out.println(" Enter Choice 0.Exit 1.Write 2.Read");
		return sc.nextInt();
	}
	
	
	public static void writeRecord() throws Exception
	{		
		try(FileOutputStream fos=new FileOutputStream(new File(path)); )
		{
			byte data=123; 
			fos.write(data);
			System.out.println("DATA is written successfully in binary file ");
			
		}	
		
	}
	public static void readRecord()throws Exception
	{
		
		try(FileInputStream fis=new FileInputStream(new File(path)); )
		{
			byte data=(byte)fis.read();
			System.out.println("Data Reading Success !! "+data);
		
		}
	
	}
	public static void main(String[] args) throws Exception
	{
		int choice;
		while((choice=menuList())!=0)
		{
			switch(choice)
			{
			case 1:
				writeRecord();
			break;
			case 2:
				readRecord();
			break;
			}
		}

	}

}
