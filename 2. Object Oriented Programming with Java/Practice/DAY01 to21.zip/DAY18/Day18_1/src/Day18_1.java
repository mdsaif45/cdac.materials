import java.util.HashSet;
import java.util.SortedSet;
import java.util.TreeSet;

public class Day18_1 {

	public static void main(String[] args) {
		HashSet<Integer> hs=new HashSet<Integer>();
		hs.add(50);
		hs.add(45);
		hs.add(25);
		hs.add(55);
		System.out.println(hs);
		
		
		SortedSet<Integer> ss=new TreeSet<Integer>();
		ss.add(50);
		ss.add(45);
		ss.add(25);
		ss.add(55);
		System.out.println(ss);

	}

}
