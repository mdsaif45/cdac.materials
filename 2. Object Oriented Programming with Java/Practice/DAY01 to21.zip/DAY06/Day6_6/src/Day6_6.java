
class Bank
{
	static int balance;
	static int ifsc;
	
	void deposit()
	{
		balance=balance+500;
	}
	void withdraw()
	{
		balance = balance-100;
	}
	
	static
	{
		balance = 2000;
		ifsc=12345;
	}
	void info()
	{
		System.out.println("Current Balance = "+balance);
		System.out.println("IFSC = "+ifsc);
	}
}


public class Day6_6 {

	public static void main(String[] args)
	{
		Bank b1=new Bank();
		b1.info();
		b1.deposit();
		b1.info();
		b1.deposit();
		b1.info();
		b1.withdraw();
		b1.info();
		Bank b2=new Bank();
		b2.info();
	}

}
