
public class Day6_2 
{
	void sum() // non static method 
	{
		System.out.println("Inside sum function");
	}
	
	void sub()
	{
		System.out.println("inside sub function");
	}

	public static void main(String[] args)
	{
		Day6_2 obj=new Day6_2();  //not recommended 
		obj.sum(); // VALID
		obj.sub(); // VALID 
		
		//sum();//javac error 
		//static methods cannot give a call to non static methods
	
		//Day6_2.sum(); // javac error 
		//because we can not give a call to non static methods
		// on class name 
	}

}
