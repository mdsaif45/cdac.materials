
//Solution
// ensure static initializer block 
// it ensures that static fields must be initialized only once during the
//life cycle of the program 
//static initializer block gets loaded during class loading time 

class Test
{
	int num1; //non static field //0
	
	int num2; //non static field //0
	static int s_var; //static field  //0 
	
	static
	{
		System.out.println("inside static initializer block");
		s_var=50;
	}
	
	Test()
	{
		System.out.println("Inside Parameterless constructor");
		this.num1=10;
		this.num2=10;
		
	}
	
	void disp()
	{
		System.out.println("Num1 = "+this.num1+" Num2 = "+this.num2+" S_VAR = "+s_var);
	}
	
	void update()
	{
		s_var=s_var+50;
	}
}


public class Day6_5 
{
	public static void main(String[] args) 
	{
		Test t1=new Test();
		t1.disp(); //10 10 50
		Test t2=new Test();
		t2.disp();  //10 10 50 
		t1.update();
		t1.disp();//10 10 100
		t2.disp(); //10 10 100 
		Test t3=new Test();
		t3.disp(); //10 10 100
		t3.update();
		t1.disp();
		t2.disp();
		t3.disp();
		
		
		

	}

}
