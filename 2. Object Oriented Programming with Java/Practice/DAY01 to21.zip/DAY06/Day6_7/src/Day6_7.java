



//getter and setters 
// for non static fields getter and setter must be declared as non static
// for static fields getter and setters must be declared as static 

//static methods = class level methods
// non static mehtods = instance methods 

class Test
{
	int num1;
	int num2;
	static int num3;
	
	static
	{
		num3=25;
	}
	
	public Test()
	{
		this.num1=5;
		this.num2=5;
	}

	public Test(int num1, int num2) 
	{
		
		this.num1 = num1;
		this.num2 = num2;
	}

	public int getNum1() {
		return num1;
	}

	public void setNum1(int num1) {
		this.num1 = num1;
	}

	public int getNum2() {
		return num2;
	}

	public void setNum2(int num2) {
		this.num2 = num2;
	}

	public static int getNum3()  //called with the help of classname
	// CLASS LEVEL METHODS 
	{
		return num3;
	}

	public static void setNum3(int num3)  
	{
		//this.num1=50;  // can not use static in this context 
		//this.num2=40; // can not use static in this context 
		Test.num3 = num3;
	}
		
	void disp() //can be called with the help of object name
	// Instance Method / Concrete Method
	{
		System.out.println("Num1 "+num1+" Num2 "+num2+" Num3 "+num3);
	}
	
	
}
public class Day6_7 
{
		public static void main(String[] args) 
	{
		Test t1=new Test();
		t1.disp();
		System.out.println(Test.getNum3());

	}

}


