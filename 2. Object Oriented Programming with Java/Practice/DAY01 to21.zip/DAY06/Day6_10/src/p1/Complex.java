// created a package p1
//class Complex belongs to package p1

package p1;

public class Complex
{
	int real;
	int imag;
	public Complex() 
	{
		this.real=5;
		this.imag=5;
	}
	public Complex(int real, int imag) 
	{
		
		this.real = real;
		this.imag = imag;
	}
	@Override
	public String toString() 
	{
		return "Complex [real=" + real + ", imag=" + imag + "]";
	}
	
	public void disp()
	{
		System.out.println("Inside display function");
	}
	
	static public void test()
	{
		System.out.println("inside test function");
	}
	
}
