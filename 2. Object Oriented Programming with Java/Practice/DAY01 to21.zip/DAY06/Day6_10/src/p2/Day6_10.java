package p2;

import p1.Complex; //in this program I may use Complex class from package p1

public class Day6_10 {

	public static void main(String[] args) 
	{
		Complex c1=new Complex(20,10); //paramatrized constructor 
		System.out.println(c1); //c1.toString() 
		 // toString() is called from Complex class
		
		System.out.println("calling display function from complex class");
		c1.disp();
		
		System.out.println("calling test() from complex ");
		Complex.test();
		//c1.test(); //ok // not recommended 
	}

}
