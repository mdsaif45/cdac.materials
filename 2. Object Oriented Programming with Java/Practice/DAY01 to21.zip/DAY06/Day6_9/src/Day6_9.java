
import static java.lang.Integer.*;

public class Day6_9
{
	
	public static void main(String[] args)
	{
		String str="123";
		int i = parseInt(str);
		System.out.println("Value of ="+i);
	}
}




/*

//if we would like to import all the static methods of some specific class
// then we should use static import statement 

//import static java.lang.*; //Invalid 
import static java.lang.Math.*;

public class Day6_9
{
	
	public static void main(String[] args)
	{
		System.out.println(sqrt(9));
		System.out.println(abs(6.3));
		System.out.println(pow(4, 2));
		System.out.println(PI);
	}

}


*/


/*
public class Day6_9
{
	
	public static void main(String[] args)
	{
		System.out.println(Math.sqrt(9));
		System.out.println(Math.abs(6.3));
		System.out.println(Math.pow(4, 2));
		System.out.println(Math.PI);
	}

}

*/
