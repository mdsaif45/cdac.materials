package p1;

public class Employee 
{
	String name;
	int id;
	float salary;
	public Employee() {
		
	}
	public Employee(String name, int id, float salary) 
	{
		
		this.name = name;
		this.id = id;
		this.salary = salary;
	}
		

}
