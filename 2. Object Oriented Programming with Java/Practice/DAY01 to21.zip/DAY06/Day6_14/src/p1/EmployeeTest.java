package p1;

import java.util.Scanner;

public class EmployeeTest 
{
	Employee e=new Employee();
	Scanner sc=new Scanner(System.in);
	void accept_record()
	{
		System.out.println("Enter name");
		e.setName(sc.next());
		
		System.out.println("Enter ID ");
		e.setId(sc.nextInt());
		
		System.out.println("Enter Salary ");
		e.setSalary(sc.nextFloat());
		
				
	}
	
	void disp()
	{
		System.out.println("Name "+e.getName()+" ID "+e.getId()+" Salary "+e.getSalary());
	}

}
