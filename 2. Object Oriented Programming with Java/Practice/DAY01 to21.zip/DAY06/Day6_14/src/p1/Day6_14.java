package p1;

public class Day6_14 {

	public static void main(String[] args)
	{
		EmployeeTest e1=new EmployeeTest();
		e1.accept_record();
		e1.disp();

	}

}
