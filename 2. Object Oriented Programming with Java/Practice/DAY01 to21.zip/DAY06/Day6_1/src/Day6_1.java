

// if we want to access method which is defined
//inside the same class in which main() is residing
//then we should declare that method as static

//can not make a static reference to non static method 


public class Day6_1 
{

	static int sum(int n1,int n2)
	{
		return (n1+n2);
	}
	
	static int sub(int n1,int n2)
	{
		return (n1-n2);
	}
	static int mul(int n1,int n2)
	{
		return (n1*n2);
	}
	static int div(int n1,int n2)
	{
		return (n1/n2);
	}
	
	//void print()
	//{
		//System.out.println("Inside Print function");
	//}
	
	public static void main(String[] args)
	{
		//System.out.println(sum(50,50));
		//System.out.println(sub(60,20));
		System.out.println(Day6_1.sum(60,20));
		System.out.println(Day6_1.sub(60,20));
		System.out.println(Day6_1.mul(60,20));
		System.out.println(Day6_1.div(60,20));
		//print(); // NOT ALLOWED //javac error
	}

}
