package p1;



public class MathDemo 
{
	public static int sum(int num1,int num2)
	{
		return num1+num2;
	}
	
	Complex c1=new Complex(60,30); //valid 
	
}
