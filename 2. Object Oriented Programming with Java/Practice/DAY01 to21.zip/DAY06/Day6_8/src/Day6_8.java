import java.util.Scanner;

//CAN I ACCESS NON STATIC FIELD WITHIN STATIC METHOD (NO) 



public class Day6_8 
{
	 static int num1; // static field of the class
	 static int num2; // static field of the class
	 static float fval;
	 static Scanner sc;  // sc is class field //sc is static reference 
	 
	 static
	 {
		 sc=new Scanner(System.in);
		 
	 }
	 
	 static void accept()
	 {
		 System.out.println("Enter Flaot value ");
		 fval=sc.nextFloat();
		 System.out.println("Fval = "+fval);
	 }
	 
	 
	  
	public static void main(String[] args)
	{
		
		System.out.println("Enter Num1 ");
		num1=sc.nextInt();
		System.out.println("Enter Num2 ");
		num2=sc.nextInt();
		System.out.println("Addition = "+(num1+num2));
		accept();
	}

}



/*
public class Day6_8 
{
	 static int num1; // static field of the class
	 static int num2; // static field of the class
	 static Scanner sc=new Scanner(System.in); // sc is class field 
	 //sc is Static Object 
	public static void main(String[] args)
	{
		System.out.println("Enter Num1 ");
		num1=sc.nextInt();
		System.out.println("Enter Num2 ");
		num2=sc.nextInt();
		System.out.println("Addition = "+(num1+num2));
	}

}


*/




/*
public class Day6_8 
{
	 int num1; // non static field of the class
	 int num2; // non static field of the class 

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		 // sc is object //it is local variable inside main() 
		Day6_8 obj=new Day6_8(); 
		System.out.println("Enter Num1 ");
		obj.num1=sc.nextInt();
		System.out.println("Enter Num2 ");
		obj.num2=sc.nextInt();
		System.out.println("Num1 = "+obj.num1+" Num2 = "+obj.num2);
		System.out.println("Num1 + Num2 = "+(obj.num1+obj.num2));


	}

}


*/



/*

public class Day6_8 
{
	public static void main(String[] args)
	{
		int num1; //num1 is method local variable 
		int num2; // num2 is method local variable 
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Num1 ");
		num1=sc.nextInt();
		System.out.println("Enter Num2 ");
		num2=sc.nextInt();
		System.out.println("Num1 = "+num1+" Num2 = "+num2);
		System.out.println("Num1 + Num2 = "+(num1+num2));


	}

}

*/


//static methods can access static fields 

/*
public class Day6_8 
{
	static int num1; // static field of the class
	static int num2; // static field of the class 

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Num1 ");
		num1=sc.nextInt();
		System.out.println("Enter Num2 ");
		num2=sc.nextInt();
		System.out.println("Num1 = "+num1+" Num2 = "+num2);
		System.out.println("Num1 + Num2 = "+(num1+num2));


	}

}

*/
