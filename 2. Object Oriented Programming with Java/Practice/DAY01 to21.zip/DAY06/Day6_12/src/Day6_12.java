
//can main() be overloaded ? YES 
public class Day6_12
{
	static void main() //user defined method
	{
		System.out.println("Inside void main() ");
	}
	
	static void main(int a) //user define method 
	{
		System.out.println("Value of a = "+a);
	}
	
	public static void main(String[] args) //entry point method
	{
		System.out.println("Inside Main Function");
		main(); 
		main(25);
	}
	
}	
	


/*
//Method Overloading 
public class Day6_12
{

	static int sum(int a,int b)
	{
		return a+b;
	}
	
	
	static int sum(int a,int b,int c )
	{
		return a+b+c;
	}
	
	static float sum(float a,float b)
	{
		return a+b;
	}
	
	public static void main(String[] args)
	{
		System.out.println(Day6_12.sum(5,2));  //sum(5,2) ;
		System.out.println(Day6_12.sum(5,2,4));  //sum(5,2,4);
		System.out.println(Day6_12.sum(3.3f,2.5f));  //sum(3.3f,2.5f)

	}

}


*/