
//if we have static field inside the class
// then while creating the object static fields will receive default value 

// WE NEVER INTIALIZE THE STATIC FIELDS WITHIN CONSTRUCTOR 

class Test
{
	int num1; //non static field //0
	// can be accesses with object name 
	int num2; //non static field //0
	static int s_var; //static field  //0 
	
	Test()
	{
		System.out.println("Inside Parameterless constructor");
		this.num1=10;
		this.num2=10;
		s_var=50; //not recommended to initialize static field inside constructor 
		//if we initialize static variabel inside the constructor
		//it is violating the property of static 
		
	}
	
	void disp()
	{
		System.out.println("Num1 = "+this.num1+" Num2 = "+this.num2+" S_VAR = "+s_var);
	}
	
	void update()
	{
		s_var=s_var+50;
	}
}

public class Day6_4 
{
	public static void main(String[] args) 
	{
		Test t1=new Test(); //10  10  50 
		t1.disp(); //10  10   50 
		t1.update(); 
		t1.disp();  //10   10   100 
		Test t2=new Test(); // 10   10  50
		t2.disp(); //10  10   50  //static variable is not retaining its last updated value
		t1.disp(); //10  10   50  // Wrong output (UNEXPECTED)
		

	}

}
