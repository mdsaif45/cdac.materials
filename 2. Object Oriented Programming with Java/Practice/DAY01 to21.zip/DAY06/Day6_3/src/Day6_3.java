
//if we have static field inside the class
// then while creating the object static fields will receive default value 

class Test
{
	int num1; //non static field //0
	// can be accesses with object name 
	int num2; //non static field //0
	static int s_var; //static field  //0 
	
	Test()
	{
		System.out.println("Inside Parameterless constructor");
		this.num1=10;
		this.num2=10;
	}
	
	void disp()
	{
		System.out.println("Num1 = "+this.num1+" Num2 = "+this.num2+" S_VAR = "+s_var);
	}
}

public class Day6_3 
{
	

	public static void main(String[] args) 
	{
		Test t1=new Test();
		Test t2=new Test();
		Test t3=new Test();
		t1.disp();
		t2.disp();
		t3.disp();
		

	}

}
