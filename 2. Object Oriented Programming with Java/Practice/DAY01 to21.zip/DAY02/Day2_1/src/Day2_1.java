
// name of the file is same as 
// the name of the class in which main() is residing 
public class Day2_1 {

	public static void main(String[] args) 
	{
		System.out.println("Welcome to STS");

	}

}
