import java.util.Scanner;

// package java.util
// class Scanner 

// accept two numbers from user
// switch case
// 1.add 2.sub 3.mul d.div 

public class Day2_5 {

	public static void main(String[] args) 
	{
		int n1;
		int n2;
		int choice;
		Scanner sc=new Scanner(System.in);
		//C++ classname objname; 
		// java classname objname = new classname(); 
		System.out.println("Enter First Numebr : ");
		n1=sc.nextInt();
			
		System.out.println("Enter Second Number : ");
		n2=sc.nextInt();
		
		System.out.println("N1 = "+n1+ " N2 = "+n2);
		
		
		do
		{
			System.out.println("Enter Choice 1.Add 2.Sub 3.Mul 4.Div 0.Exit");
			choice=sc.nextInt();
			switch(choice)
			{
			case 1:
				System.out.println("Addition = "+(n1+n2));
			break;
			case 2:
				System.out.println("Subtraction = "+(n1-n2));
			break;
			case 3:
				System.out.println("Multiplication = "+(n1*n2));
			break;
			case 4:
				System.out.println("Division = "+(n1/n2));
			break;
				
			}
		}
		while(choice!=0);
		sc.close();
	}
	

}
