
//Command line arguments 
// these are the values which are supplied during the execution of the program

//STEPS FOR VS Code 
//Compilation : javac Day2_4.java
// Execution : java Day2_4 sunbeam pune
// sunbeam is first command line argument will get stored args[0]
// pune is second command line argument will get stored in args[1] 

public class Day2_4 {

	public static void main(String[] args) 
	{
		String str1=args[0];
		String str2=args[1];
		int i=Integer.parseInt(args[2]);
		float f=Float.parseFloat(args[3]);
		double d=Double.parseDouble(args[4]);
		System.out.println("arg[0] "+str1);
		System.out.println("arg[1] "+str2);
		System.out.println("arg[2] "+i);
		System.out.println("arg[3] "+f);
		System.out.println("arg[4] "+d);
		
		System.out.println(str1+ " "+str2 + "  "+i+ " "+f+"  "+d);
		
		

	}

}
