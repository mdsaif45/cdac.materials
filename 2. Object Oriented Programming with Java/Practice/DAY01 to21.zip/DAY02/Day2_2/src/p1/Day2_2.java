package p1;
class Demo
{
	
}
class Test
{
	
}
class Day2_2
{
	public static void main(String args[])
	{
		int a; // variable declaration
		a=45; // variable definition
		System.out.println(" value of a "+a);
	}
}


/*
class Day2_2
{
	public static void main(String args[])
	{
		int num=30;//initialized variable
		int num1=50;
		int num2=40;
		//System.out.println(num);
		//System.out.println("Number = "+num); // Concatination ==> appending
		               //   Number = 30
		//System.out.println("result = "+(num+20));
		System.out.println(num1+num2);
	}
}
*/





/*
// class Day2_2 belongs to package p1

public class Day2_2 {

	public static void main(String[] args) 
	{
		int a; // variable declaration // error //Compilation phase error
		// javac error  //java compiler 
		//java does not allows uninitialized variables 
		// in java gargbage values can not be assigned 
		System.out.println(a);
		

	}

}

*/
