

public class cmd_demo 
{

	public static void main(String[] args) //String args[] valid 
	{
		int n1=Integer.parseInt(args[0]);
		//parseInt() is declared statically inside the Integer class 
		//args is of type String
		// n1 is of type int
		// we can not store String to int
		//we need to convert String to int 
		// parseInt()
		// parseFloat()
		//parseDouble()
		
		int n2=Integer.parseInt(args[1]);
		System.out.println("N1 = "+n1);
		System.out.println("N2 = "+n2);
		System.out.println("Addition = "+(n1+n2));
		
		
		
	}

}