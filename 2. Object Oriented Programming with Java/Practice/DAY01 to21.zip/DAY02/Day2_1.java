
// number of class files generated in java program
//is equal to number of classes present in the program
class A
{

}
class B
{
   
}
class Day2_1
{
    public static void main(String args[])
    {
        System.out.println("Day2_1");
        
    }
}

// IDE 
// Integrated Development Environment 

//main() is a function / method 
// main() is declared in which class?? Day2_1
// we don't create object of the class in which main() is residing 
