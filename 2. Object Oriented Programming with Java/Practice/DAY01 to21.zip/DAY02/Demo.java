
public class Demo 
{
    public static void main(String args[])
    {
        System.out.println("Day2");
        System.out.println("Day2_folder program");
    }
}


