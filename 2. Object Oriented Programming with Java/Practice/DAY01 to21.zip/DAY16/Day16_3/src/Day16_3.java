import java.util.ArrayDeque;
import java.util.PriorityQueue;
import java.util.Queue;


/*
public class Day16_3 {

	public static void main(String[] args) 
	{
		
		Queue<Integer>q=new PriorityQueue<Integer>();
		//upcasting
		q.add(40);
		q.add(11);
		q.add(22);
		q.add(31);
		System.out.println("PriorityQueue "+q);
		Integer ele=null;
		while(!q.isEmpty())
		{
			ele=q.element();
			System.out.println("Element = "+ele);
			q.remove();
		}
		
		
	}
}
*/


/*
public class Day16_3 {

	public static void main(String[] args) 
	{
		
		Queue<Integer>q=new ArrayDeque<Integer>();
		//upcasting
		q.add(40);
		q.add(11);
		q.add(22);
		q.add(31);
		System.out.println("ARRAY DEQUEUE "+q);
		Integer ele=null;
		while(!q.isEmpty())
		{
			ele=q.element();
			System.out.println("Element = "+ele);
			q.remove();
		}
		
		
	}
}
*/


/*
public class Day16_3 {

	public static void main(String[] args) 
	{
		
		Queue<Integer>q=new ArrayDeque<Integer>();
		//upcasting
		q.add(40);
		q.add(10);
		q.add(20);
		q.add(30);
		System.out.println("ARRAY DEQUEUE "+q);
		
		Queue<Integer>q1=new PriorityQueue<Integer>();
		//upcasting
		q1.add(40);
		q1.add(10);
		q1.add(20);
		q1.add(30);
		System.out.println("PriorityQueue "+q1);
	
		
		
	}
}

*/

//offer() and poll() methods are used to add and remove the elements in Queue
// if there is not space or if the queue is empty then it never throws Eception

//add() and remove() these methods throws Exception
//if queue is full or queue is empty 


/*

public class Day16_3 {

	public static void main(String[] args) 
	{
		PriorityQueue<String> q=new PriorityQueue<String>();
		
		q.add("AKSHITA"); 
		q.add("SUNBEAM"); 
		q.add("PUNE");  
		q.add("JAVA");
		System.out.println(q);
		q.remove();
		System.out.println(q);
		q.remove();
		System.out.println(q);
		q.remove();
		System.out.println(q);
		q.remove();
		System.out.println(q);
		System.out.println(q.remove());
	}
}

*/

/*
public class Day16_3 {

	public static void main(String[] args) 
	{
		PriorityQueue<String> q=new PriorityQueue<String>();
		
		q.offer("AKSHITA"); 
		q.offer("SUNBEAM"); 
		q.offer("PUNE");  
		q.offer("JAVA");
		System.out.println(q);
		q.poll();
		System.out.println(q);
		q.poll();
		System.out.println(q);
		q.poll();
		System.out.println(q);
		q.poll();
		System.out.println(q);
		System.out.println(q.poll());
	}
}


*/



/*
public class Day16_3 {

	public static void main(String[] args) 
	{
		PriorityQueue<String> q=new PriorityQueue<String>();
		
		q.add("AKSHITA"); 
		q.add("SUNBEAM"); 
		q.add("PUNE");  
		q.add("JAVA");
		//it checks ascii values and sorts it in ascending order
		//then it adds into the queue 
		//also it checks length 
		
		
		System.out.println(q);
		System.out.println("Head of Queue = " +q.element());
		
		q.remove();
		System.out.println("Head of Queue = " +q.element());
		System.out.println("Peek " +q.peek());
		
		
		
	}

}
*/