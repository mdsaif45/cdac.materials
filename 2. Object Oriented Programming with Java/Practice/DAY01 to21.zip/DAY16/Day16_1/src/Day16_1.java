import java.util.ArrayList;
import java.util.Iterator;
import java.util.Stack;


public class Day16_1 {

	public static void main(String[] args)
	{
		ArrayList<Integer> a1=new ArrayList<Integer>();
		a1.add(10);
		a1.add(20);
		a1.add(30);
		System.out.println(a1 +" Class "+a1.getClass());
		
		Object[] intArr = a1.toArray(); 
		for(int i=0;i<intArr.length;i++)
			System.out.println(intArr[i]);
		
		System.out.println("intArr Class "+intArr.getClass());
	}
}


/*
//Requirement is to convert stack elements in an array
// toArray() 

public class Day16_1 {

	public static void main(String[] args)
	{
		Stack<Integer> stk=new Stack<Integer>();
		stk.push(10); 
		stk.push(15); 
		stk.push(20); 
		stk.push(25); 
		System.out.println(stk+" Size "+stk.size());
		System.out.println("Class "+stk.getClass());
		Object[] strArray=stk.toArray();
		
		
		System.out.println("Array Contents ");
		for(int i=0;i<strArray.length;i++)
			System.out.print(" "+strArray[i]);
		
		System.out.println("\n Class "+strArray.getClass());
		
	}
}
*/

/*
public class Day16_1 {

	public static void main(String[] args)
	{
		Stack<Integer> stk=new Stack<Integer>();
		stk.push(10); 
		stk.push(15); 
		stk.push(20); 
		stk.push(25); 
		System.out.println(stk+" Size "+stk.size());
		Integer element = null;
		
		
		while(!stk.empty()) //if stack is not empty 
		{
			element = stk.peek(); //peek() will take the element pointed by top
			System.out.println("Element = "+element); //print the element 
			stk.pop(); // remove the element 
		}
		System.out.println(stk+" Size "+stk.size());
	}
}

*/



/*
public class Day16_1 {

	public static void main(String[] args)
	{
		Stack<Integer> stk=new Stack<Integer>();
		stk.push(10); //  position from top  = = 4 
		stk.push(15); // position from top = = 3 
		stk.push(20); //  position from top  = = 2 
		stk.push(25); // position from top  = 1 
		System.out.println(stk);
		
		System.out.println(stk.search(25));
		System.out.println(stk.search(20));
		System.out.println(stk.search(15));
		System.out.println(stk.search(10));
		
		stk.pop();
		stk.pop();
		stk.pop();
		stk.pop();
		System.out.println("all elements are popped"+stk);
		stk.pop(); //Exception 
		
		
	}
}

*/

/*
public class Day16_1 {

	public static void main(String[] args)
	{
		Stack<Integer> stk=new Stack<Integer>();
		stk.push(10);
		stk.push(15);
		stk.push(20);
		stk.push(25);
		System.out.println(stk);
		
		//iterator is supplied to stack stk 
		System.out.println("\n Printing data using iterator");
		
		Iterator<Integer>  itr=stk.iterator();
		//traverse through stack
		while(itr.hasNext())
			{
				System.out.print(" "+itr.next());
				//stk.push(55); //Fail-Fast 
			}
		
		//for each loop internally uses iterator
		
		System.out.println("\n Printing data using for each");
		for(int i:stk)
			{
			System.out.print(" "+i);
		//	stk.push(55); // Fail-Fast 
			}
		System.out.println("\n Printing data using for loop");
		for(int i=0;i<stk.size();i++)
			{
			System.out.print(" "+stk.get(i));
			//stk.push(55); //Fail-Safe  //run time error 
			}
		
	}

}
*/