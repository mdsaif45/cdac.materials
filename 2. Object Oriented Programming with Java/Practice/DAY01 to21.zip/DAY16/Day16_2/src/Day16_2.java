import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.Vector;

public class Day16_2 {

	public static void main(String[] args)
	{
		ArrayList<Integer>a1=new ArrayList<Integer>();
		a1.add(10);
		a1.add(20);
		a1.add(30);
		
		//Vector(Collection<? extends E> c)
		Vector<Integer>v=new Vector<Integer>(a1); 
		
		System.out.println("Array List = "+a1);
		System.out.println("Vector = "+v+ " Size = "+v.size()+ " Capacity = "+v.capacity() );
	
		ArrayList a2=new ArrayList();
		a2.add("Akshita");
		a2.add(34);
		a2.add(60000.56f);
		//o="Akshita" ==> String ==> Object = String ===> Upcasting 
		//o = 34  ===> Integer ==> Object = Integer ==> Upcasting
		//o = 60000.56f ==> Float ==> Object = Float ==> Upcasting 
		
		for(Object o:a2) 
			System.out.println(o);
			
		//for(ArrayList a:a2) //javac error
			//System.out.println(a); 
	}
}


/*

public class Day16_2 {

	public static void main(String[] args)
	{
		//Vector(int initialCapacity, int capacityIncrement)
		Vector<Integer> v=new Vector<Integer>(3,5);
		v.addElement(10);
		v.addElement(20);
		v.addElement(30);
		System.out.println(v+" "+"size = "+v.size()+ " Capacity = "+v.capacity());
		v.addElement(40);
		System.out.println(v+" "+"size = "+v.size()+ " Capacity = "+v.capacity());
		
		//applying enumeration to vector elements 
		//internally iteration is applied 
		Enumeration<Integer> e = v.elements();
		
		while(e.hasMoreElements())
			{
			System.out.print(" "+e.nextElement());
			
			}
		//if after completer iteration we try to access the element
		// It will throw exception 
		System.out.println(e.nextElement()); //NoSuchElementException
		
	}
}
*/

/*

public class Day16_2 {

	public static void main(String[] args)
	{
		Vector<String> v=new Vector<String>(5);
		System.out.println(v+" "+"size = "+v.size()+ " Capacity = "+v.capacity());
		
		v.addElement("Akshita");
		v.addElement("Chanchlani");
		System.out.println(v+" "+"size = "+v.size()+ " Capacity = "+v.capacity());
		v.addElement("Sunbeam");
		v.addElement("Pune");
		v.addElement("Karad");
		System.out.println(v+" "+"size = "+v.size()+ " Capacity = "+v.capacity());
		
		System.out.println("elements = "+v);
		System.out.println("For loop ");
		for(int i=0;i<v.size();i++)
			System.out.print(" "+v.get(i));
		System.out.println("\n using Iterator ");
		Iterator itr = v.iterator();
		while(itr.hasNext())
			{
			System.out.print(" "+itr.next());
			//v.addElement("java"); //fail-fast // ConcurrentModificationException
			}
		
		System.out.println("\n using List Iterator ");
		ListIterator itr1 = v.listIterator();
		while(itr1.hasNext())
			System.out.print(" "+itr1.next());
		
		System.out.println("\n using enumeration ");
		Enumeration e = v.elements();
		while(e.hasMoreElements())
			{
			System.out.print(" "+e.nextElement());
			//v.addElement("java"); //fail-safe 
			}
		
		System.out.println("\n using for each");
		for(String i:v)
			System.out.print(" " +i);
		
		
		
		
	}
}


*/



/*

public class Day16_2 {

	public static void main(String[] args)
	{
		Vector<String> v=new Vector<String>(5);
		System.out.println(v+" "+"size = "+v.size()+ " Capacity = "+v.capacity());
		
		v.addElement("Akshita");
		v.addElement("Chanchlani");
		System.out.println(v+" "+"size = "+v.size()+ " Capacity = "+v.capacity());
		v.addElement("Sunbeam");
		v.addElement("Pune");
		v.addElement("Karad");
		System.out.println(v+" "+"size = "+v.size()+ " Capacity = "+v.capacity());
		v.addElement("Trainer");
		System.out.println(v+" "+"size = "+v.size()+ " Capacity = "+v.capacity());
		
		System.out.println("At location 3 element is = "+v.get(3));
		System.out.println(v.firstElement());
		
	}
}

*/

/*
public class Day16_2 {

	public static void main(String[] args)
	{
		Vector<Integer> v=new Vector<Integer>();
		System.out.println(v+" "+"size = "+v.size()+ " Capacity = "+v.capacity());
		System.out.println("Capacity = "+v.capacity());
		v.add(10);
		System.out.println(v+" "+"size = "+v.size()+ " Capacity = "+v.capacity());
		v.add(20);
		v.add(30);
		v.add(40);
		v.add(50);
		v.add(60);
		v.add(70);
		System.out.println(v+" "+"size = "+v.size()+ " Capacity = "+v.capacity());
		v.add(80);
		v.add(90);
		v.add(100);
		System.out.println(v+" "+"size = "+v.size()+ " Capacity = "+v.capacity());
		v.add(110);
		System.out.println(v+" "+"size = "+v.size()+ " Capacity = "+v.capacity());
		
	}

}
*/