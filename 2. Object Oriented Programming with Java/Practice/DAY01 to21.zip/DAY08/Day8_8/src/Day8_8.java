


enum Color
{
	RED,GREEN,BLUE; //sole constructor will be called
	// RED , GREEN , BLUE will be static fields inside Color enum class
}
public class Day8_8
{

	public static void main(String[] args) 
	{
		Color c[]=Color.values();
		for(Color clr:c)
			System.out.println(clr.name()+" "+clr.ordinal());
		
	}
}

/*
public class Day8_8
{

	public static void main(String[] args) 
	{
		Color clr=Color.RED;
		
		System.out.println("Name = "+clr.name());
		System.out.println("Ordinal value  = "+clr.ordinal());
		
		clr=Color.GREEN;
		System.out.println("Name = "+clr.name());
		System.out.println("Ordinal value  = "+clr.ordinal());
	}
}

*/
/*
public class Day8_8
{

	public static void main(String[] args) 
	{
		System.out.println(Color.RED);
		System.out.println(Color.GREEN);
		System.out.println(Color.BLUE);
		

	}

}

*/
