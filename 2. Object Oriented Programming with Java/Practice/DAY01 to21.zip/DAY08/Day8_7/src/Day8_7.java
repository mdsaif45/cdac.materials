
//to declare a single constant
//we use a keyword final keyword 

public class Day8_7
{

	public static void main(String[] args) 
	{
		final float PI=3.14f;
		System.out.println(PI);
		//PI++; // Invalid 
		//System.out.println(PI);

	}

}
