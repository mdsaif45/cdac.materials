import java.util.Scanner;

enum Operations
{
	ADD,SUB,MUL,DIV,MOD;
}

public class Day8_10 {



	public static void main(String[] args) 
	{
		int n1,n2;
		int choice;
		Scanner sc=new Scanner(System.in);
		
		Operations o[]=Operations.values();
		
		for(Operations val:o)
			System.out.print(" "+val);
		
		System.out.println("Enter First Numebr : ");
		n1=sc.nextInt();
		System.out.println("Enter Second Numebr : ");
		n2=sc.nextInt();
		do
		{
				System.out.println("Enter Choice : 0.ADD,1.SUB,2.MUL,3.DIV,4.MOD,5.Exit ");
				choice=sc.nextInt();
				
				Operations op=Operations.values()[choice];
				
				
				
				
				switch(op)
				{
				case ADD:
					System.out.println("Addition = "+(n1+n2));
				break;
				case SUB:
					System.out.println("Subtraction = "+(n1-n2));
				break;
				case MUL:
					System.out.println("Multiplication = "+(n1*n2));
				break;
				case DIV:
					System.out.println("Division = "+(n1/n2));
				break;
				case MOD:
					System.out.println("Mod = "+(n1%n2));
				break;
				}
		}
		while(choice!=5);

	}

}
