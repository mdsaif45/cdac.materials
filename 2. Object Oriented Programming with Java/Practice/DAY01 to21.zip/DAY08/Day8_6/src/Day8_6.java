
//Variable number of arguments while method call
//Variable Arity Method 


public class Day8_6 
{

	static void sum(int... args) 
	{
		int result=0;
		System.out.println("Arguments = "+args.length);
		
		//for(int i=0;i<args.length;i++)
			//result=result+args[i];
		
		for(int element:args)
			result=result+element;
		System.out.println("Addition = "+result);
	}
	public static void main(String[] args) // VALID 
	{
		sum(); 
		sum(5,4);
		sum(10,20,30);
		sum(1,2,3,4);
	
	}

}


/*
public class Day8_6 {

	public static void main(String... args) // VALID 
	{
		System.out.println("inside main");

	}

}
*/