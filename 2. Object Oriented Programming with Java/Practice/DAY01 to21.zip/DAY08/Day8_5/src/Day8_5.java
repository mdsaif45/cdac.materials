import java.util.Arrays;

public class Day8_5 {

	public static void main(String[] args)
	{
		int[][] arr=new int[][] {{1,2,3},{4,5,6},{7,8,9}};
		System.out.println(arr);
		System.out.println(Arrays.toString(arr));
		System.out.println(Arrays.toString(arr[0]));
		System.out.println(Arrays.toString(arr[1]));
		System.out.println(Arrays.toString(arr[2]));
		
	}
}


/*
public class Day8_5 {

	public static void main(String[] args)
	{
		int[][] arr=new int[][] {{1,2,3},{4,5,6},{7,8,9}};
		
		//for each row of type int[] inside arr
		// row = arr[0]   row = arr[1]  row = arr[2] 
		     // {1,2,3}        {4,5,6}        {7,8,9}
		for(int[] row:arr)
		{
			//for each col of type int inside row 
			for(int col:row)
			{
				System.out.print(col+" ");
			}
			System.out.println();
		}

	}

}

*/
