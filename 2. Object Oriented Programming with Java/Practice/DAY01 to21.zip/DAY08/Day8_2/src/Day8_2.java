import java.util.Arrays;


public class Day8_2 {

	public static void main(String[] args) 
	{
		int arr1[]=new int[] {33,44,11,22,67,55};
		int arr2[]=new int[] {33,44,11,22,67,55};
		int arr3[]=new int[] {11,22,33,5,7};
		System.out.println(Arrays.equals(arr1, arr2));
		System.out.println(Arrays.equals(arr1, arr3));
		
		int arr4[]= new int[5];
		Arrays.fill(arr4, 0);
		System.out.println(Arrays.toString(arr4));
		
	}
}

/*
public class Day8_2 {

	public static void main(String[] args) 
	{
		int arr1[]=new int[] {33,44,11,22,67,55};
		int arr2[]=Arrays.copyOfRange(arr1, 2, 5);//it consider "from" value as (n-1) and produces unsorted array as o/p
		System.out.println(Arrays.toString(arr1));
		System.out.println(Arrays.toString(arr2));
	}
}
*/

/*
public class Day8_2 {

	public static void main(String[] args) 
	{
		int arr[]=new int[] {33,44,11,22,67,55};
		System.out.println(Arrays.toString(arr));
		Arrays.sort(arr);
		System.out.println(Arrays.toString(arr));
	}
}

*/

/*
public class Day8_2 {

	public static void main(String[] args) 
	{
		int arr[]=new int[] {11,22,33,44,55};
		int result = Arrays.binarySearch(arr, 33);
		System.out.println("Index = "+result);
		result=Arrays.binarySearch(arr, 35); //-4 // 4th location can be considered for insertion of elements 
		System.out.println("Result = "+result);
		
	}
}
*/
/*
public class Day8_2 {

	public static void main(String[] args) 
	{
		Integer i=new Integer(55);
		//i=55; 
		System.out.println("value of i = "+i);
		System.out.println("get class = "+i.getClass());
		String str=Integer.toString(i);
		System.out.println("str = "+str);
		System.out.println("get class = "+str.getClass());
		
	}
	
}
*/
/*
public class Day8_2 {

	public static void main(String[] args) 
	{
		int arr[]=new int[] {45,11,122,13,15,76};
		//System.out.println(arr);
		//System.out.println(arr.toString());
		//System.out.println(arr.getClass());
		System.out.println(Arrays.toString(arr));
	
		
	}

}
*/