// if we pass enum elements along with some user defined values
//then its a duty of developer to specify the constructor 
//matching with it 

// class Day extends Enum
// fields ==> static final ==> SUN MON TUES
// constructor ==> sole emitted / Day(int,String) 
// methods ==> four  ,user defined two getters() , two values() valueof()

enum Day
{
	SUN(10,"Sunday"),MON(20,"Monday"),TUES(30,"Tuesday");

	private int dayNumber;
	private String dayName;
	
	Day(int dayNumber, String dayName)
	{
		this.dayNumber=dayNumber;
		this.dayName=dayName;
	}

	public int getDayNumber() {
		return dayNumber;
	}

	public String getDayName() {
		return dayName;
	}
		
}

public class Day8_9 {

	public static void main(String[] args) 
	{
		Day d=Day.SUN;
		System.out.println(d.hashCode());
		System.out.println("Name = "+d.name());
		System.out.println("Ordinal = "+d.ordinal());
		System.out.println(" Day Number = "+d.getDayNumber());
		System.out.println(" Day Name = "+d.getDayName());
		
		
		d=Day.MON;
		System.out.println("Name = "+d.name());
		System.out.println("Ordinal = "+d.ordinal());
		System.out.println(" Day Number = "+d.getDayNumber());
		System.out.println(" Day Name = "+d.getDayName());
		
		d=Day.TUES;
		System.out.println("Name = "+d.name());
		System.out.println("Ordinal = "+d.ordinal());
		System.out.println(" Day Number = "+d.getDayNumber());
		System.out.println(" Day Name = "+d.getDayName());
		
		

	}

}
