package p1;

public enum Maths 
{
	EXIT,ADD,SUB
}
