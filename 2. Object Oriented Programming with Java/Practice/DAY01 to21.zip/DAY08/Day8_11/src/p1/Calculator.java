package p1;

public class Calculator
{
	public static int sum(int num1,int num2)
	{
		return num1+num2;
	}
	public static int sub(int num1,int num2)
	{
		return num1-num2;
	}
}
