package p1;

import java.util.Scanner;

public class Day8_11 
{
	static Scanner sc=new Scanner(System.in);
	
	public static Maths menuOptions()
	{
		System.out.println("Enter Choice 0.EXIT 1.ADD 2.SUB");
		return Maths.values()[sc.nextInt()];
		
	}
	
	public static void main(String[] args) 
	{
		Maths m; //m is reference of enum type Maths  
		while((m=menuOptions())!=Maths.EXIT)
		{
			switch(m)
			{
			case ADD:
				System.out.println(Calculator.sum(50,25));
				
			break;
			case SUB:
				System.out.println(Calculator.sub(30,20));
			break;
			
			}
		}
	}

}
