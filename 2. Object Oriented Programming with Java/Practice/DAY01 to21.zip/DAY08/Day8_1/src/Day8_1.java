

class Test
{
	void f1()
	{
		System.out.println("inside f1");
	
	}
	
	String f2()
	{
		return "inside f2";
	}
}
public class Day8_1 {

	public static void main(String[] args)
	{
		
		Test t1=new Test();
		//System.out.println(t1.f1());
		
		System.out.println(t1.f2());
	}

}
