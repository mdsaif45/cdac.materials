import java.util.Arrays;
import java.util.Scanner;



public class Day8_4 
{
	static Scanner sc=new Scanner(System.in);

	public static void main(String[] args) 
	{
		int a[][]=new int[3][3];
		int b[][]=new int[3][3];
		accept_record(a);
		accept_record(b);
		disp_record(a);
		disp_record(b);
		sum(a,b);
	
		
		
	}

	static void disp_record(int[][] arr) 
	{
		for(int row=0;row<arr.length;row++)
		{
			for(int col=0;col<arr[row].length;col++)
			{
				System.out.print(" "+arr[row][col]);
			}
			System.out.println();
		}
		
	}

	static void accept_record(int[][] arr) 
	{
		for(int row=0;row<arr.length;row++)
		{
			for(int col=0;col<arr[row].length;col++)
			{
				arr[row][col]=sc.nextInt();
			}
		}
		
	}
	
	
	 static void sum(int[][] a1,int[][] a2 ) 
	{
		int c[][]=new int[3][3];
		for(int row=0;row<a1.length;row++)
		{
			for(int col=0;col<a1[row].length;col++)
			{
				c[row][col]=a1[row][col]+a2[row][col];
			}
		}
		
		//for(int row=0;row<c.length;row++)
		//{
			//for(int col=0;col<c[row].length;col++)
			//{
				//System.out.print(" "+c[row][col]);
			//}
			//System.out.println();
		//}
		

			disp_record(c);
	}
}

/*
public class Day8_3 {

	public static void main(String[] args) 
	{
		int arr[][]=new int[3][3];
		System.out.println(arr.length); //lenght will return row count 
		//output = 3 
	}
}

*/

/*
public class Day8_3 {

	public static void main(String[] args) 
	{
		int arr[]= {1,2,3}; // VALID 
		//int arr[]=new int[3];
		//arr is name of an array // reference // stack
		// 1 2 3 heap 
		System.out.println(arr);
		System.out.println(Arrays.toString(arr));
		
	}
}
*/



/*
public class Day8_3 {

	public static void main(String[] args) 
	{
		int a1[][]=new int[3][3]; // VALID 
		int[][] a2=new int[4][2];//VALID 
		int[][] a3=new int[][] {{1,2,3},{4,5,6}}; // VALID 
		// int[][] a3=new int[2][3];
		
		int[][]a4= {{1,2},{3,4},{5,6},{7,8}}; //VALID //array is of type value type
		//int[][] a5=new int[4][3] {{1,2,3},{4,5,6},{7,8,9},{10,11,12}}; // INVALID 
		
		
		

	}

}

*/
