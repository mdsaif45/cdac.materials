import java.util.Arrays;
import java.util.Scanner;



public class Day8_3 
{
	static Scanner sc=new Scanner(System.in);

	public static void main(String[] args) 
	{
		int arr[][]=new int[4][3];
		accept_record(arr);
		disp_record(arr);
	}

	private static void disp_record(int[][] arr) 
	{
		for(int row=0;row<arr.length;row++)
		{
			for(int col=0;col<arr[row].length;col++)
			{
				System.out.print(" "+arr[row][col]);
			}
			System.out.println();
		}
		
	}

	private static void accept_record(int[][] arr) 
	{
		for(int row=0;row<arr.length;row++)
		{
			for(int col=0;col<arr[row].length;col++)
			{
				arr[row][col]=sc.nextInt();
			}
		}
		
	}
}

/*
public class Day8_3 {

	public static void main(String[] args) 
	{
		int arr[][]=new int[3][3];
		System.out.println(arr.length); //lenght will return row count 
		//output = 3 
	}
}

*/

/*
public class Day8_3 {

	public static void main(String[] args) 
	{
		int arr[]= {1,2,3}; // VALID 
		//int arr[]=new int[3];
		//arr is name of an array // reference // stack
		// 1 2 3 heap 
		System.out.println(arr);
		System.out.println(Arrays.toString(arr));
		
	}
}
*/



/*
public class Day8_3 {

	public static void main(String[] args) 
	{
		int a1[][]=new int[3][3]; // VALID 
		int[][] a2=new int[4][2];//VALID 
		int[][] a3=new int[][] {{1,2,3},{4,5,6}}; // VALID 
		// int[][] a3=new int[2][3];
		
		int[][]a4= {{1,2},{3,4},{5,6},{7,8}}; //VALID //array is of type value type
		//int[][] a5=new int[4][3] {{1,2,3},{4,5,6},{7,8,9},{10,11,12}}; // INVALID 
		
		
		

	}

}

*/
