import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Scanner;

// Requirement : to read and write Non primitive data (Object) inside binary files 
//ObjectOutputStream and ObjectInputStream

//if we write , implements serializable infront of class name while declaring the
//class, it means whenever we create object of that class
//object becomes serializable  object
//serializable object means it can be written inside the file using ObjectOutputStream
//Deserialization of Object means it can be read from the file using ObjectInputStream

// Serialization means writting oebject to file 
// Deserialization means reading object from file 

class Employee implements Serializable
{
	private String name;
	private int empid;
	private float salary;
	
	public Employee(String name, int empid, float salary)
	{
		super();
		this.name = name;
		this.empid = empid;
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Employee [name=" + name + ", empid=" + empid + ", salary=" + salary + "]";
	}
	

	
}


public class Day19_2
{
	static Scanner sc=new Scanner(System.in);
	static String path="Demo.dat";
	
	private static int menuList() 
	{
		System.out.println("Enter Choice 0.Exit 1.Read 2.Write");
		return sc.nextInt();
	}

	
	private static void readRecord() throws FileNotFoundException, IOException, ClassNotFoundException
	{
		try(ObjectInputStream ois=new ObjectInputStream(new BufferedInputStream(new FileInputStream(new File(path))));)
		{
			Employee emp=(Employee)ois.readObject();
			System.out.println(emp);
			
		}
		
	}
	
	private static void writeRecord() throws Exception
	{
		try(ObjectOutputStream oos=new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(new File(path))));)
		{
			Employee e1=new Employee("Akshita",123,60000);
			oos.writeObject(e1);
		}
	}

	
	public static void main(String[] args) throws Exception 
	{
	
		int choice;
		while((choice=menuList())!=0)
		{
			switch(choice)
				{
				case 1:
					readRecord();
					break;
				case 2:
					writeRecord();
					break;
					
				}
			
		}

	}


	


}
