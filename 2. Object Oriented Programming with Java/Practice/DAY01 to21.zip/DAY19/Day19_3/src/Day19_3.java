import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Scanner;

class Date implements Serializable
{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4241634228071899296L;
	
	int day;
	int month;
	int year;
	Date()
	{
		
	}
	Date(int day,int month,int year)
	{
		this.day=day;
		this.month=month;
		this.year=year;
	}
	@Override
	public String toString() {
		return "Date [day=" + day + ", month=" + month + ", year=" + year + "]";
	}
	
	
}

class Employee implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -8290285480913216318L;
	private String name;
	private int empid;
	private float salary;
	Date joinDate =new Date();
	
	Employee()
	{
		
	}
	


	public Employee(String name, int empid, float salary, Date joinDate) {
		super();
		this.name = name;
		this.empid = empid;
		this.salary = salary;
		this.joinDate = joinDate;
	}



	@Override
	public String toString() {
		return "Employee [name=" + name + ", empid=" + empid + ", salary=" + salary + ", joinDate=" + joinDate + "]";
	}


	
}


public class Day19_3
{
	static Scanner sc=new Scanner(System.in);
	static String path="Demo.dat";
	
	private static int menuList() 
	{
		System.out.println("Enter Choice 0.Exit 1.Read 2.Write");
		return sc.nextInt();
	}

	
	private static void readRecord() throws FileNotFoundException, IOException, ClassNotFoundException
	{
		try(ObjectInputStream ois=new ObjectInputStream(new BufferedInputStream(new FileInputStream(new File(path))));)
		{
			Employee emp1=(Employee)ois.readObject();
			System.out.println(emp1);
			
			Employee emp2=(Employee)ois.readObject();
			System.out.println(emp2);
			
		}
		
	}
	
	private static void writeRecord() throws Exception
	{
		try(ObjectOutputStream oos=new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(new File(path))));)
		{
			Date d1=new Date(4,4,2021);
			Employee e1=new Employee("Akshita",123,60000,d1);
			oos.writeObject(e1);
			
			Date d2=new Date(5,4,2022);
			Employee e2=new Employee("Sunbeam",456,70000,d2);
			oos.writeObject(e2);
		}
	}

	
	public static void main(String[] args) throws Exception 
	{
	
		int choice;
		while((choice=menuList())!=0)
		{
			switch(choice)
				{
				case 1:
					readRecord();
					break;
				case 2:
					writeRecord();
					break;
					
				}
			
		}

	}


	


}
