
//javap is a utility which is help for all java docs 

class Simple
{
	
}
class Day19_8
{
	Simple obj=new Simple();
	void test()
	{
		System.out.println("Inside test function");
		Class c=obj.getClass();
		System.out.println(c.getName());
	}
	public static void main(String args[])
	{
		Simple s=new Simple();
		Day19_8 d1=new Day19_8();
		d1.test();
	}
}



/*

public class Day19_8
{

	public static void main(String[] args) throws ClassNotFoundException 
	{
		Class c = Class.forName("Day19_8");
		System.out.println(c);
		System.out.println(c.getName());
	}

}
*/