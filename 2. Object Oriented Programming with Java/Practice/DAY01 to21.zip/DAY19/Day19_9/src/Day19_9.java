import java.lang.reflect.*;

public class Day19_9 {

	public static void main(String[] args) throws ClassNotFoundException 
	{
		Class c=Class.forName(args[0]);
		Method m[] =c.getDeclaredMethods();
		for(int i=0;i<m.length;i++)
			System.out.println(m[i].toString());
	}

}
