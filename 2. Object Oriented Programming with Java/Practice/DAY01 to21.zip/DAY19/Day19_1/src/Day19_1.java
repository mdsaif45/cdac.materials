import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;
// Requirement : to read and write Primitive type of data inside the file(binary)s

public class Day19_1
{
	static Scanner sc=new Scanner(System.in);
	static String path="Demo.dat";
	
	private static int menuList() 
	{
		System.out.println("Enter Choice 0.Exit 1.Read 2.Write");
		return sc.nextInt();
	}

	
	private static void readRecord() throws FileNotFoundException, IOException
	{
		try(DataInputStream dis=new DataInputStream(new BufferedInputStream(new FileInputStream(new File(path))));)
		{
			String name = dis.readUTF();
			int age=dis.readInt();
			float salary=dis.readFloat();
			System.out.println("Name "+name+" Age="+age+" Salary = "+salary);
		}
		
	}
	
	private static void writeRecord() throws Exception
	{
		try(DataOutputStream dos=new DataOutputStream(new BufferedOutputStream(new FileOutputStream(new File(path))));)
		{
			dos.writeUTF("Akshita"); //{'A','k','s','h','i','t','a'}==>character array primitive 
			dos.writeInt(34);
			dos.writeFloat(60000.5f);
		}
	}

	
	public static void main(String[] args) 
	{
	
		int choice;
		while((choice=menuList())!=0)
		{
			try
			{
				switch(choice)
				{
				case 1:
					readRecord();
					break;
				case 2:
					writeRecord();
					break;
					
				}
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}

	}


	


}
