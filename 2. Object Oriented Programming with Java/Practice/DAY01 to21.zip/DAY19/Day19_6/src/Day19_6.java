import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Scanner;

public class Day19_6 
{
	static Scanner sc=new Scanner(System.in);
	static String path="Demo.txt"; // text file 
	
	public static int menuList()
	{
		System.out.println(" Enter Choice 0.Exit 1.Write 2.Read");
		return sc.nextInt();
	}
	
	
	public static void writeRecord()throws Exception 
	{
		try(FileWriter fw=new FileWriter(new File(path)))
		{
			for(char ch='A';ch<='Z';ch++)
				fw.write(ch);
		}
		
	}
	public static void readRecord()throws Exception 
	{
		try(FileReader fr=new FileReader(new File(path)))
		{
			int data;
			while((data=fr.read())!=-1)
				System.out.print((char)data+" ");
		}
	}
	public static void main(String[] args) throws Exception 
	{
		int choice;
		while((choice=menuList())!=0)
		{
			switch(choice)
			{
			case 1:
				writeRecord();
			break;
			case 2:
				readRecord();
			break;
			}
		}

	}

}
