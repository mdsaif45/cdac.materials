import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Scanner;

//Practice Question
// 1. take name from user put it inside text file
// 2. take mobile number from user put it inside text file
// 3. take age , id, location from user put it inside text file
// you can add few more fields also 

// 4. Read the complete data from Text file 





//Writing multiple lines in text document 
public class Day19_7 
{
	static Scanner sc=new Scanner(System.in);
	static String path="Demo.txt"; // text file 
	
	public static int menuList()
	{
		System.out.println(" Enter Choice 0.Exit 1.Write 2.Read");
		return sc.nextInt();
	}
	
	
	public static void writeRecord()throws Exception 
	{
		try(BufferedWriter bw=new BufferedWriter(new FileWriter(new File(path))))
		{
			bw.write("Akshita Chanchlani");
			bw.newLine();
			bw.write("Trainer");
			bw.newLine();
			bw.write("Sunbeam");
			bw.newLine();
		}
		
	}
	public static void readRecord()throws Exception 
	{
		try(BufferedReader br=new BufferedReader(new FileReader(new File(path))))
		{
			String line;
			while((line=br.readLine())!=null)
			{
				System.out.println(line);
			}
		}
	}
	public static void main(String[] args) throws Exception 
	{
		int choice;
		while((choice=menuList())!=0)
		{
			switch(choice)
			{
			case 1:
				writeRecord();
			break;
			case 2:
				readRecord();
			break;
			}
		}

	}

}
