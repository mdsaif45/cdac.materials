
// String class is having equals() overridden
// so if we compare two String objects using equals() contents are checked



public class Day9_3
{

	public static void main(String[] args) 
	{
		StringBuffer sb1=new StringBuffer("Sunbeam");
		StringBuffer sb2=new StringBuffer("Sunbeam");
		StringBuffer sb3=sb2;
		
		System.out.println(sb1==sb2);
		System.out.println(sb2==sb3);
		
		System.out.println(sb1.equals(sb2));
		System.out.println(sb2.equals(sb3));
		
	}
}


//StringBuffer and StringBuilder are not having equals() definition
// so if we compare two objects of StringBuffer and StringBuilder
//then equals() is called from Object class

// as per the equals() of Object class
// if obj1==obj2 (reference equality is false) then obj1.equals(obj2) will also return false 



/*



public class Day9_3
{

	public static void main(String[] args) 
	{
		StringBuffer sb1=new StringBuffer("Sunbeam");
		StringBuffer sb2=new StringBuffer("Sunbeam");
		System.out.println("Original SB1 = "+sb1+" SB2 = "+sb2);
		System.out.println(sb1.hashCode());
		System.out.println(sb2.hashCode());
		
		System.out.println(sb1==sb2); // false //reference equality
		System.out.println(sb1.equals(sb2)); //false
		
		
	}
}

*/
/*
public class Day9_3
{

	public static void main(String[] args) 
	{
		StringBuffer sb1=new StringBuffer("Sunbeam");
		
		System.out.println("Original = "+sb1);
		sb1.reverse();
		System.out.println("Reversed = "+sb1);
		
	}
}
*/


/*

public class Day9_3
{

	public static void main(String[] args) 
	{
		String s1="Akshita"; //valid 
		String s2=new String("Akshita"); //valid
		
		//StringBuilder s3="Akshita"; // Invalid
		//StringBuffer s4="Akshita"; //Invalid 
		
		StringBuilder s3=new StringBuilder("Akshita");//VALID // Mutable 
		StringBuffer s4=new StringBuffer("Akshita");//VALID // Mutable 
		
	}
}
*/

 /*
public class Day9_3
{

	public static void main(String[] args) 
	{
		StringBuilder str1=new StringBuilder("sunbeam");
		System.out.println("Original String = "+str1);
		str1.insert(3, "pune");
		System.out.println("Modified String = "+str1);
		
		StringBuilder str2=new StringBuilder("hello");
		
		System.out.println("Original String = "+str2);
		str2.reverse();
		System.out.println("Reverse  String = "+str2);
		
		
		
	}
}

*/


/*
public class Day9_3
{

	public static void main(String[] args) 
	{
		StringBuilder str1=new StringBuilder("sunbeam");
		System.out.println("Original "+str1);
		str1.append("Pune");
		System.out.println("After Append  "+str1);
	}
}
*/




/*
//by default compiler gives us initial capacity is 16 character 

public class Day9_3
{

	public static void main(String[] args) 
	{
		StringBuilder str1=new StringBuilder("sunbeam");
		System.out.println("Original Str = "+str1);
		System.out.println("Length ="+str1.length());
		System.out.println("Capacity = "+str1.capacity());
		
		StringBuilder str2=new StringBuilder("pune");
		System.out.println("Original Str = "+str2);
		System.out.println("Length ="+str2.length());
		System.out.println("Capacity = "+str2.capacity());
		
		StringBuilder str3=new StringBuilder();
		System.out.println("Original Str = "+str3);
		System.out.println("Length ="+str3.length());
		System.out.println("Capacity = "+str3.capacity());
		
		
			
		
	}
}

*/

