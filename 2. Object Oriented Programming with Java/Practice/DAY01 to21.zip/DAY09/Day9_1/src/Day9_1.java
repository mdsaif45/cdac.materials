

// == comapres references 
// equals() compares the contents 

public class Day9_1
{
	public static void main(String[] args)
	{
		String s1=new String("Sunbeam Pune"); //s1 = non literal
		s1=s1.intern();  // s1 literal 
		String s2=s1; //s2 literal 
		System.out.println(s1==s2);
	}
}

/*
public class Day9_1
{
	public static void main(String[] args)
	{
		String s1=new String("Sunbeam Pune").intern();
		String s2=s1;
		System.out.println(s1==s2); //true
	}
}
*/

/*
public class Day9_1
{
	public static void main(String[] args)
	{
		String s1=new String("Sunbeam Pune"); //s1 = non literal
		String s2=s1.intern();  // s2 = literal 
		System.out.println(s1==s2); // false 
	}
}

*/

/*
public class Day9_1
{

	public static void main(String[] args)
	{
		String s1="hello"; //literal  ==> ref1
		String s2="Hello";// literal ==> ref2 
		System.out.println("s1==s2 "+(s1==s2));//false 
		System.out.println(s1.equals(s2));//false (contents)
		
		System.out.println(s1.equalsIgnoreCase(s2)); //true 
		System.out.println(s1.hashCode());
		System.out.println(s2.hashCode());
		
		String s3=new String(s1);
		System.out.println(s3.hashCode());
		System.out.println(s1==s3); // false 
		
		String s4=new String(s1).intern(); 
		//s4 will point to literal pool
		System.out.println(s4.hashCode());
		System.out.println(s1==s4); //true
		
		
		
		
		
	}
}
*/


/*

public class Day9_1
{

	public static void main(String[] args)
	{
		String s1="hello"; // s1 ===> literal string object
		//char []charArray={'h','e','l','l','o'};
		// String s1=new String(charArray);
		String s2=new String(s1); //s2==> non literal String
		//String s2=new String(s1).intern();
		
		String s3="hello"; // s3==>String literal 
		String s4="Hello" ;// s4==> String Literal 
		
		System.out.println("S1 = "+s1+" S1 Hashcode = "+s1.hashCode());
		System.out.println("S2 = "+s2+" S2 Hashcode = "+s2.hashCode());
		System.out.println("S3 = "+s3+" S3 Hashcode = "+s3.hashCode());
		System.out.println("S4 = "+s4+" S4 Hashcode = "+s4.hashCode());
		
		System.out.println("S1==s2 "+(s1==s2));  //false 
		//s1 is literal s2 is non literal (even though contents are same still it will return false)
		System.out.println("S1==s3 "+(s1==s3)); //true
		//s1 and s3 literals contents are also same 
		System.out.println("S1==s4 "+(s1==s4)); //false 
		//s1 and s4 are literals but contents are different 
		
		System.out.println("s1 equals s2 "+(s1.equals(s2)));
		//s1 literal s2 is non literal , equals() checks the contents within the string 
		System.out.println("s1 equals s3 "+(s1.equals(s3)));
		System.out.println("s1 equals s4 "+(s1.equals(s4)));
		
		
		
	}
}

*/

/*
public class Day9_1
{

	public static void main(String[] args)
	{
		String s1="Sunbeam"; //String Literal
		String s2=new String("Akshita"); //string object (non literal)
		
	}

}

*/
