
//Immutable String 
// If we try to do some modifications in string
//original string remains the same
//until and unless we initialize it again

/*

public class Day9_2 
{

	public static void main(String[] args) 
	{
		String str="hello";
		System.out.println("Original Str = "+str);
		System.out.println(str.toUpperCase());// another object //non literal 
		System.out.println("After Uppercase Str = "+str);
		str=str.toUpperCase();
		System.out.println("One more time Uppercase Str = "+str);
		
		
		
		
	}
}


*/


/*
public class Day9_2 
{

	public static void main(String[] args) 
	{
		String str="Soon";
		String newStr=str.replace('S', 'M');
		System.out.println("Old Str "+str);
		System.out.println("New str "+newStr);
	}
}

*/


/*

public class Day9_2 
{

	public static void main(String[] args) 
	{
		String str="akshita";
		System.out.println(str.indexOf('a'));  // will return first occurrence 
		
		System.out.println(str.indexOf('z')); //if character is not present it returns -1 
		
		System.out.println(str.indexOf('a', 2));
	}
}
*/


/*
public class Day9_2 
{

	public static void main(String[] args) 
	{
		String s1="Sun";
		String s2="beam";
		String s3="Akshita";
		System.out.println(s1+s2); //concatinate the string 
		System.out.println(s1+s2+s3);
		System.out.println("Concatination = "+s1.concat(s2));
		System.out.println("Concatination = "+s1.concat(s2).concat(s3));
	}
}
*/
/*
public class Day9_2 
{

	public static void main(String[] args) 
	{
		String s1="Akshita";
		String s2="AKshita";
				
		System.out.println(s1.compareToIgnoreCase(s2));
	}
}

*/



/*
public class Day9_2 
{

	public static void main(String[] args) 
	{
		//String s1="Akshita";
		//String s2="AKshita";
		
		//String s1="abce"; //e 101
		//String s2="abcde"; // d 100 
		
		//String s1="AKSHITA";
		//String s2="AKSHITA";
		
		String s1="AKSHITA1";
		String s2="AKSHITA123";
		System.out.println(s1.length());
		System.out.println(s2.length());
		
		
		
		System.out.println(s1.compareTo(s2));
	}
}

*/

/*
public class Day9_2 
{

	public static void main(String[] args) 
	{
		String str="Sunbeam";
		System.out.println(str.charAt(1));
		
		String s1="Akshita";
		String s2="akshita";
		System.out.println(s1.compareTo(s2));
		//A = 65
		//a = 97
		// s1 compare to s2 
		// 65 - 97 = -32 
		// compares the characters within the string based on ASCII value 
		
		
		
	}

}
*/