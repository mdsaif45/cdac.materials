import java.util.Objects;

class Demo
{
	int num1;
	Demo()
	{
		num1=20;
	}
	@Override
	public String toString() {
		return "Demo [num1=" + num1 + "]";
	}
	@Override
	public int hashCode() {
		return Objects.hash(num1);
	}
	
	//d1.equals(d2)
	//this===> d1  obj ===> d2 
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Demo other = (Demo) obj;
		return num1 == other.num1;
	}
	
	
	
}
public class Day9_4 {

	public static void main(String[] args)
	{
		Demo d1=new Demo();
		Demo d2=new Demo();
		System.out.println(d1==d2);
		System.out.println(d1.equals(d2));
		// equals() method is called upon d1 object 
		//this ===> d1 

	}

}
