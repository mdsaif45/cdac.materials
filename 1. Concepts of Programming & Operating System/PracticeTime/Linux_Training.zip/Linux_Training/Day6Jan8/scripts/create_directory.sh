#!/bin/bash

mkdir temp
ls -l
