#!/bin/bash

name="Siddhant"
x="sid"

if [[ $name == $x ]];
then
	echo "$name and $x is same"
else
	echo "$name and $x is not same"
fi
