#!/bin/bash


a=10
b=20
c=$a+$b #this statement is going t perform concatination
echo $c #10+20

echo $(( a + b ))
echo $(( a - b ))
