#include<stdio.h>

int main()
{
	int n = 10; int m=50;
	int *p;int *q;
	p = &n;
	n = 11;
	*p = 15;
	q = p; // wherever p points, q also points	
	*q = 20;
	
	q = &m;	
	
	
	printf("n is %d\n", n);
	printf("*p is %d\n", *p);
	printf("*q is %d\n", *q);
	printf("m is %d\n", m);
	printf("address of n is %p\n", &n); // print adress as unsigned
	printf("value inside p is %p\n", p);
	
	return 0;
} 
