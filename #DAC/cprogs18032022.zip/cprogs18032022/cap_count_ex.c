#include<stdio.h>

int main()
{
	int i=0, num_cap=0;
	char mystr[50];
	printf("Enter string: ");
	scanf("%[^\n]s", mystr);
	
	while(1)
	{
		// am I reached to end of string ?
		if(mystr[i] == '\0') {
			break;
		}
		else
		{
			if(mystr[i] >= 'A' && mystr[i] <= 'Z')
			{
				num_cap++;
				i++;
			}
			else
			{
				i++;
			}
		}
	}
	printf("Total CAP letters in %s are %d\n", mystr, num_cap);
	return 0;
}
