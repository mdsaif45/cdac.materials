#include<stdio.h>

int main()
{
	int myarr[5]={1,2,3,4,5};
	int *p; int i;
	/*
	p = &myarr[0];
	for(i = 0; i < 5;i++)
	{
		printf("%d\n", *p);
		p++;
	}
	*/
	p = &myarr[4];
	for(i = 0; i < 5;i++)
	{
		printf("%d\n", *p);
		p--;
	}
	return 0;
}
