#include<stdio.h>

int main()
{
	int i=0, num_cap=0;
	char mystr[50];
	printf("Enter string: ");
	scanf("%[^\n]s", mystr); // take all charactera and stop when new line character
	// simple %s will not accept space, tab-space, and other invisible characters
	
	while(mystr[i] != '\0')
	{
		if(mystr[i] >= 'A' && mystr[i] <= 'Z')
			num_cap++;		
		i++;
	}
	printf("Total CAP letters in %s are %d\n", mystr, num_cap);
	return 0;
}
