#include<stdio.h>

int main()
{
	int i=0, num_cap=0;
	char mystr[50];
	printf("Enter string: ");
	scanf("%[^\n]s", mystr);
	
	while(mystr[i] != '\0')
	{
		if(mystr[i] >= 'A' && mystr[i] <= 'Z')
		{
			num_cap++;
		}
		else
		{
			; // null statement, do nothing
		}
		i++;
	}
	printf("Total CAP letters in %s are %d\n", mystr, num_cap);
	return 0;
}
