#include <stdio.h>
#include <string.h>
struct employee {
        int id;
        char name[20];
        float salary;
        char gender;
 };

void print_details(struct employee);

int main () {
	        struct employee emp1;
        emp1.id=1;
        strcpy(emp1.name, "Ravi");
        emp1.salary = 25234.5;
        emp1.gender = 'M';
        print_details(emp1);
        return 0;
}

void print_details(struct employee e)
{
        printf(" Emp id  is: %d \n", e.id);
        printf(" Emp Name is: %s \n", e.name);
        printf(" Emp salary is: %f \n", e.salary);
        printf(" gender is: %c \n", e.gender);
}
