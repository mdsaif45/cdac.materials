#include <stdio.h>
#include <string.h>
struct group_detail
{
int grp_id;
char grp_name[10];
};

struct employee {
   int id;
   char name[20];
   float salary;
   struct group_detail grp_dtl;
 };


int main () {
        struct employee emp1;
        emp1.id=1;
        strcpy(emp1.name, "Ravi");
        emp1.salary = 25234.5;

        emp1.grp_dtl.grp_id=1;
	
        strcpy(emp1.grp_dtl.grp_name,"embeded");


        printf(" Emp id  is: %d \n", emp1.id);
        printf(" Emp Name is: %s \n", emp1.name);
        printf(" Emp salary is: %f \n", emp1.salary);
	printf("grp_id = %d\n", emp1.grp_dtl.grp_id);
	printf("grp_name = %s\n", emp1.grp_dtl.grp_name);
	return 0;
}


