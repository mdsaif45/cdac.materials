#include <stdio.h>
#include <string.h>

struct bookinfo 
{ 
	char bookname[100]; 
	int pages; 
	int price;
};

int main() {
	struct bookinfo books[3];
	books[0].pages = 200;
	books[0].price = 30;
	strcpy(books[0].bookname, "C programming");

	printf("book name %s\n", books[0].bookname);
	printf("pages: %d\n", books[0].pages);
	printf("price: %d\n", books[0].price);
	return 0;
}
