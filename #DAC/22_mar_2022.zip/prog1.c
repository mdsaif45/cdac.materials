#include <stdio.h>
#include <string.h>
struct employee {
        int id;
        char name[20];
        float salary;
        char gender;
 }emp1;

int main() {
	//struct employee emp1;
	emp1.id = 22;
	emp1.salary = 40000.2395;
	emp1.gender = 'M';
	char emp_name[20];
	strcpy(emp1.name, "Ravi");

	printf("the id is %d\n", emp1.id);
	printf("the name is %s\n", emp1.name);
	printf("gender: %c\n", emp1.gender);
	printf("salary: %f\n", emp1.salary);

	struct employee emp2;
	printf("enter and id:\n");
	scanf("%d", &emp2.id);
	printf("enter salary:\n");
	scanf("%f", &emp2.salary);

	printf("enter gender\n");
        scanf(" %c", &emp2.gender);

        printf("enter name\n");
        scanf("%[^\n]s", emp2.name);

	
	printf("the id is %d\n", emp2.id);
	printf("the name is %s\n", emp2.name);
	printf("gender: %c\n", emp2.gender);
	printf("salary: %f\n", emp2.salary);


	return 0;

}
