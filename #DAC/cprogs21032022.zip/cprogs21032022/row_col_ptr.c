#include<stdio.h>
#define NR 3
#define NC 4

int main()
{
	int arr[NR][NC]= { {1,2, 3, 4}, {5,6,7,8}, {9,10,11,12}};
	int *p;
	int (*q)[NC]; // q is column pointer, q will hold address
				// of an integer array of size 3
	int i, j;
	/*
	for(i=0 ; i< 3 ; i++) {
		for(j=0;j<3; j++) {
			scanf("%d", &arr[i][j]);
		}
	}
	*/
	
	printf("Before\n");
	for(i=0 ; i< NR ; i++) {
		for(j=0;j<NC; j++) {
			printf("%d ", arr[i][j]);
		}
		printf("\n");
	}
	p = arr[1];// p points for 2nd row 1st element
	// for(p points to 2ndRow1stElement;p less than 3rdRowFirstElement;p++)
	
	for(p=arr[1] ; p < arr[1] + NC ; p++)
		*p = 0;
	
		
	for(q= &arr[0]; q < arr[NR] ; q++) // q++ will increment row wise
		(*q)[1] = -1; // same as *(q+1)
	
	
	
	printf("After\n");
	for(i=0 ; i< NR ; i++) {
		for(j=0;j<NC; j++) {
			printf("%d ", arr[i][j]);
		}
		printf("\n");
	}
	return 0;
}
