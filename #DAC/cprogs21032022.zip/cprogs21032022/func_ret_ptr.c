#include<stdio.h> // <...> means look into sys dir 
#include"func_ret_ptr.h" // "..." means look into current directory, then sys dir

int main()
{
	int a, b;
	int *p;
	printf("Enter a and b: ");
	scanf("%d %d", &a, &b); // actual args
	
	p = max_addr(&a, &b); //function call
	printf("Max val is: %d\n", *p);
	return 0;
}


int * max_addr(int *x, int *y) //formal args
{
	//never return address of local variable
	if(*x > *y)
		return x;
	else
		return y;
}
