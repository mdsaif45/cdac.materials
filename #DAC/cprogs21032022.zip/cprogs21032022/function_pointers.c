#include<stdio.h>

void foo(int);

int main()
{
	int a=10;int b =20;
	void (*foov2)(int);
	foov2 = foo;
	
	
	
	foo(a);
	
	(*foov2)(100);
	(*foov2)(90);
	foov2(70);
	(*foov2)(b);
	
	
	
	return 0;
}
void foo(int x)
{
	printf("I am inside foo, got val: %d\n", x);
	return ;
}
