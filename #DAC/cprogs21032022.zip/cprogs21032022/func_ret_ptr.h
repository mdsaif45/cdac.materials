int *max_addr(int *, int *);
