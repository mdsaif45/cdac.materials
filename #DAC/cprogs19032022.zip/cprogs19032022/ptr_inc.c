#include<stdio.h>

int main()
{
	int arr[]={10,20,30};
	int *ptr_arr = arr; // same as *ptr_arr = &arr[0]
	
	printf("%d\n", *ptr_arr); // prints 10
	printf("%d\n", *ptr_arr++); // prints 10
	
	printf("%d\n", *ptr_arr); // prints 20
	printf("%d\n", *++ptr_arr); // first incremnt ptr_arr then use
				// prints 30
	
	printf("%d\n", *--ptr_arr); // prints 20
	printf("%d\n", *ptr_arr); 
	
	printf("%d\n", ++*ptr_arr); //same as ++(*ptr_arr), 
			// incremnt array value // arr {10,21,30}
	
	
	
	
	printf("%d %d %d\n", arr[0], arr[1], arr[2]);
	return 0;
}
