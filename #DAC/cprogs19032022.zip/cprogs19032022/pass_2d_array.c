#include<stdio.h>

//double avg(int [][2], int); // function prototype decleration

// function definition
double avg(int arr[][2], int rows)
{
	double sum=0.0;
	int i, j;
	int total = rows * 2;
	for(i=0; i < rows ; i++)
	{
		for(j=0 ; j < 2 ; j++)
		{
			sum += arr[i][j];
			
		}
	}
	/*
	for(i=rows-1; i >= 0 ; i--)
	{
		for(j=2-1 ; j >= 0 ; j--)
		{
			sum += arr[i][j];
			
		}
	}
	*/	
	return sum / total;
}

int main()
{
	int a[2][2] = {{11,21},{30,40}};
	printf("Avg is %lf\n", avg(a, 2)); // 2 means number of rows
	return 0;
}

	/*
	// syntax of while
	i=0;
	while(i < rows)
	{
		...
		...
		++i;
	}
	
	// syntax of for
	for (i=0; i < rows ; ++i)
	{
		...
		...
	}
	
	*/
