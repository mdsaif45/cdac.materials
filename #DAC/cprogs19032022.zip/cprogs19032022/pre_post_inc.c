#include<stdio.h>

int main()
{
	int i =10;
	int a;
	a=i++; // i++ first use i later increment i
	
	printf("a=%d, i=%d\n", a, i);
	a=++i; // ++i first increment i later use it 
	printf("a=%d, i=%d\n", a, i);
	
	
	return 0;
}
