void f(const int *p) // change in *p is not allowed
{
	int n;
	*p=0; // error
	n = *p;
}
int main()
{
	int n=0;
	int *p = &n;
	f(p);
	return 0;
}
