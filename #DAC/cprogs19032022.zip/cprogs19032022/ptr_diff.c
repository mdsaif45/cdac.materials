 #include<stdio.h>
 
 int main()
 {
 	int a[] = {10,20,30,40,50};
 	int *p = &a[1];
 	
 	int *q;
 	q = &a[4];
 	
 	printf("q-p is: %ld\n", q-p);
 	printf("*q-*p is: %d\n", *q-*p);
 	return 0;
 }
