#include<stdio.h>
// double average(int arr[], int size);
double average(int [], int);

int main()
{
	int a[] = {11,15,20,25};
	int i, n;
	double res; // res will hold average value
	n = sizeof a / sizeof a[0];
	printf("calculated arrray size is: %d\n", n);
	res = average(a, n);
	printf("Avg result is: %lf\n", res);
	
	
	return 0;
}
//double average(int arr[], int size)
double average(int *arr, int size)
{
	int m;
	int sum=0; int i;
	int myarr[5];
	double avg_res = 0.0;
	// m = sizeof arr / sizeof arr[0]; // WRONG
	// printf("size of arr is: %lu\n", sizeof arr);
	// printf("calculated arrray size in average function is: %d\n", m);
	for (i=0 ; i< size; ++i)
		sum += arr[i]; // sum += *(arr + i)
	avg_res = (double)sum / size; // not typecasting to (double) give integer result
	return avg_res;
}
 
