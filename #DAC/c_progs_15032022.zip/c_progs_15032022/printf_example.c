#include<stdio.h>

int main()
{
	int num=65;
	float fnum=65.5e-1;
	printf("[%d]\n", num); // % means format conversion: binary to decimal
	printf("%o\n", num); // o means binary to octal
	printf("%x\n", num); // x means binary to hexadecimal
	printf("%c\n", num); // c means binary to chararcter
	
	printf("[%5d]\n", num); // right justified
	printf("[%-5d]\n", num); // left justified
	printf("[%5.3d]\n", num); // print num in 3 digits
	printf("[%5.1d]\n", num);
	printf("hello DAC 2022 student\n");
	
	printf("%f\n", fnum); // binary to float_sting
	printf("%.2f\n", fnum); // .2f mean 2 digits after point(.)
	printf("%e\n", fnum);
	return 0;
}
