#include<stdio.h>

int main()
{
	// these varaible are automatic/local variables
	int n=0;
	int sum=0; int i; // i has garbage value
	
	
	while(n < 10)// loops runs for n: 0 to 9
	{
		printf("Enter non zero value: ");
		scanf("%d", &i);
		if(i == 0)
		{
			//printf("Sorry, try again\n");
			//continue;
			
			// printf("Bye Bye\n");
			// break;
			goto mylabel;
			
		}
		sum += i;  // same as sum = sum + i;
		n++;
		/* continue jumps here*/
	}
	/*break jumps here*/
	printf("Sum is %d\n", sum);
	
	return 0;
	mylabel: printf("reached through goto\n");
}
	
