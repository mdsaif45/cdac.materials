#include<stdio.h>

#define N 15
int main()
{
	// int arr[5]={1,2,3,4,5};
	//int arr[] = {1,2,3,4,5};
	// int arr[15] = {1,2,3,4,5};
	int arr[N] = {1,2,3,4,5};
	int i;
	
	
	
	// i will be 0 to 4
	for(i=0;i<N;i++)
	{
		printf("%d ", arr[i]);
	}
	printf("\n");
	printf("%d\n", arr[0]); //prints first val of array 
	return 0;
}
	
