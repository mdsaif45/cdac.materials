#include<stdio.h>

int main()
{
	int num=010; // 010 means octal 10
	float fnum=0.3f; // 0.3f mean 0.3 in float
	int year, month, day;
	num=0xB; // 0xB means hexadecimal B
	//scanf("%d", &num); // takes input in decimal format
	//scanf("%o", &num); // input in octal format
	//scanf("%x", &num); // input in haxadecimal
	// scanf("%f", &fnum);
	// scanf("%e", &fnum); // takes input in exponential notation
	
	//scanf("%d", &year);
	//scanf("%d", &month);
	//scanf("%d", &day);
	
	// scanf("%d %d %d", &year, &month, &day); 
	scanf("%d/%d/%d", &year, &month, &day);
	
	printf("Year: %d, Month: %.2d, Day:%2d\n", year, month, day);
	printf("%d/%.2d/%.2d\n", day, month, year);
	// printf("num is %d\n", num);
	// printf("fnum is [%5.2f]\n", fnum);
	
	return 0;
}
