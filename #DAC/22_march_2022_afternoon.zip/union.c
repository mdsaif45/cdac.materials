#include <stdio.h>
#include <string.h>
union Data
{
   int i;
   float f;
   char  str[20];
};


int main( )
{
   union Data mydata;        
   strcpy( mydata.str, "C Programming");
   mydata.i = 10;
   mydata.f = 220.5;
   printf( "data.i : %d\n", mydata.i);
   printf( "data.f : %f\n", mydata.f);
   printf( "data.str : %s\n", mydata.str);
   //mydata.i = 225;
   //printf( "data.str : %s\n", mydata.str);
   return 0;
}

