struct printer_status {
	unsigned int emptyPaperTray :1;
	unsigned int paperJam       :1;
	:2; //2 empty bits
	unsigned int lowInk         :1;
	:1;
       	//1 empty bit
	unsigned int needsCleaning  :1;
	:1;

};

