#include <stdio.h>
#include <string.h>
struct employee {
        int id;
        char name[20];
        float salary;
        char gender;
 };


int main() {
	int id = 22;
	int * myptr = &id;

	struct employee emp1;
	struct employee * emp2;

	emp1.id = 22;
	emp1.salary = 30000;
	strcpy(emp1.name, "Ravi");
	emp1.gender = 'M';

	emp2 = &emp1;


        printf("the id is %d\n", emp2->id);
        printf("the name is %s\n", emp2->name);
        printf("gender: %c\n", emp2->gender);
        printf("salary: %f\n", emp2->salary);
	return 0;
}

