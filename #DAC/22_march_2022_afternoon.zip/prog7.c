#include <stdio.h>

struct hockey
{
    char team1[10];
    char team2[10];
    char venue[20];
    int result;
}match[4] = {
              {"IND","AUS","BANGALROE",1},
              {"IND","PAK","HYDERBAD",1},
              {"IND","NZ","CHENNAI",0},
              {"IND","SA","DELHI",1}
            };


int main() {
struct hockey *ptr = match;// By default match[0],base address
int i;
for(i=0;i<4;i++)
    {
    printf("\nMatch : %d",i+1);
    printf("\n%s Vs %s",ptr->team1,ptr->team2);
    printf("\nPlace : %s\n",ptr->venue);
    if(match[i].result == 1)
        printf("nWinner : %s",ptr->team1);
    else
        printf("nWinner : %s",ptr->team2);
    printf("\n");

    // Move Pointer to next structure element
    ptr++;
    }
}
