#include<stdio.h>

int main()
{
	int grade;
	scanf("%d", &grade);
	
	if(grade == 4)
		printf("Excellent\n");
	else if(grade == 3)
		printf("Good\n");
	else if(grade == 2)
		printf("Average\n");
	else if(grade == 1)
		printf("Poor\n");
	else if(grade == 0)
		printf("Failed\n");
	else
		printf("Invalid grade\n");
	return 0;
}
		
