#include<stdio.h>

int main()
{
	int i = 1;
	printf("i is: %d\n", i);
	i++;
	printf("i is: %d\n", i);
	i++;
	printf("i is: %d\n", i);
	i++;	
	printf("i is: %d\n", i);
	i++;
	printf("i is: %d\n", i);
	i++;
	return 0;
}
	
	
