#include<stdio.h>

int main()
{
	int number, res;
	printf("Please enter a number: ");
	scanf("%d", &number);
	
	res = number % 2;
	if ( res == 1 )
	{
		printf("number %d is odd \n", number);
	}
	else
	{
		printf("Number %d is even\n",number);
	}
	return 0;
}
		
