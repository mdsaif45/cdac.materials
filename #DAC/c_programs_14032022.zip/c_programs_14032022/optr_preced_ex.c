#include<stdio.h>

int main()
{
	int a= 5, b=7, c;
	c=a-++b;
	
	printf("The value of c variable is: %d\n", c);
	return 0;
}
