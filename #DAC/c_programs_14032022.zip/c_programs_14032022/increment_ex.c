#include<stdio.h>

int main()
{
	int a = 10, b = 20;
	a=b++;
	
	printf("a is: %d\n",a);
	printf("b is %d", b); // if use %x prints in hexadecimal format 
	return 0;
}
