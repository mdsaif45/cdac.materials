#include<stdio.h>

int main()
{
	int grade;
	scanf("%d", &grade);
	
	switch(grade)
	{
		case 4: printf("excellent\n");
			break;
		case 3: printf("good\n");
			break;
		case 2: printf("average\n");
			break;
		case 1: printf("poor\n");
			break;
		case 0: printf("Falied\n"); 
			break;			
		case 5: printf("outstanding\n");
			break;
		default:printf("Invalid grade\n");
			break;
		
	}
	return 0;
}
	
