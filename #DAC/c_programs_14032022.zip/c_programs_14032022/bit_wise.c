#include<stdio.h>

int main()
{
	unsigned short int a,b,c;
	a=3; // numbers staring withh 0x or 0X are hexadecimal noation
	b=5;
	
	// c= a^b;
	a = a << 1; // do bits left shift, 1 left shift means multiply by 2
	//printf("C is: %d\n", c); // %x printf in hexadecimal format
	printf("a is: %d\n", a);
	a >>= 1; // same as a = a >> 1;
	printf("again a is: %d\n", a);
	return 0;
}
	
