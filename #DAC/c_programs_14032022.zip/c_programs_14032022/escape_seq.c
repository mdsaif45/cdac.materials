#include<stdio.h>

int main()
{
	printf("n");
	printf("[\n]"); // [] are square brackets, () round brackets
	// {} are curly bracket, <> are angle brackets
	printf("hello world\b"); // \b is backspace character
	return 0;
	
}
