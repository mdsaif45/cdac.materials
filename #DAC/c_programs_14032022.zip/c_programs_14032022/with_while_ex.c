// while loop
#include<stdio.h>
int main()
{
	int i;
	
	i=1; // initilalization
	while(i <= 5) // condition
	{
		if(i%2 == 0)
			printf("i is: %d, EVEN\n", i);
		else
			printf("i is: %d, ODD\n", i);
		i++;  // incement i by 1 // incrementation
	}
	
	while(10)
	{
		printf("This will print infinitely\n");
		printf("use CTRL C to exit from infinite loop");
	}
	return 0;
}
