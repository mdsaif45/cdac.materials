#include<stdio.h>

int main()
{
	char option;int num1, num2;int res;
	printf("Enter your options\n");
	printf("Enter \n+ to add\n- to subtract\n");
	printf("Your Option :");
	scanf("%c", &option);

	printf("enter two numbers");
	scanf("%d %d", &num1, &num2);	
	
	switch(option)
	{
		case '+': 
			res = num1 + num2;
			printf("%d+%d=%d\n", num1, num2, res);
			break;
		case '-':
			printf("%d-%d=%d\n", num1, num2, num1 - num2);
			break;
		default:
			printf("Invalid option, Try again\n");
			break;
	}
	return 0;
}
	
