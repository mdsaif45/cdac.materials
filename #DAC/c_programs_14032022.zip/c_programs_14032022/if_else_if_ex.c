#include<stdio.h>

int main()
{
	int a=300;
	int b;
	
	b = 200;
	
	if(a == 100)
	{
		if (b == 200)
		{
			printf("a is 100\n");
			printf("b is 200\n");
		}
		else
			printf("a is 100 only\n");
	}
	return 0;
}
