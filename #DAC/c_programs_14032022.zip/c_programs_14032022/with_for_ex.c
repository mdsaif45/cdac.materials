// for loop
#include<stdio.h>
int main()
{
	int i;
	
	//for (initilalization;condition;incrementation)
	
	for(i = 1 ; i <= 5 ; i++)
	{
		if(i%2 == 0)
			printf("i is: %d, EVEN\n", i);
		else
			printf("i is: %d, ODD\n", i);
	}
		
	return 0;
}
