#include<stdio.h>
// 5! = 5*4*3*2*1
// 7! = 7*6*5*4*3*2*1
// 1! = 1
// 0! = 1

int main()
{
	long int val, result;
	int i;
	printf("val? :");
	scanf("%ld", &val);
	result = 1;
	for(i = val ; i >= 1 ; i--)
	{
		result = result * i;
	}
	printf("Factorial of %ld is %ld\n", val, result);
	printf("Enter val again: ");
	scanf("%ld", &val);
	result = 1;
	for(i = val ; i >= 1 ; i--)
	{
		result = result * i;
	}
	printf("Factorial of %ld is %ld\n", val, result);
	printf("Enter val third time: ");
	scanf("%ld", &val);
	result = 1;
	for(i = val ; i >= 1 ; i--)
	{
		result = result * i;
	}
	printf("Factorial of %ld is %ld\n", val, result);
	return 0;
}
