#include<stdio.h>
// stdio.h contains prototype declerations of 
// formatted input output functions e.g. printf, scanf,...

long int factorial(long int); // prototype decleration
int main()
{
	long int val, result;
	printf("val: ");
	scanf("%ld", &val);
	
	result = factorial(val); 
	// factorial(val) means function call with parameter val
	
	printf("Facorial of %ld is %ld\n",val, result);
	
	printf("Enter val again: ");
	scanf("%ld", &val);
	result = factorial(val);
	printf("Facorial of %ld is %ld\n",val, result);
	
	printf("Enter val third time: ");
	scanf("%ld", &val);
	result = factorial(val);
	printf("Facorial of %ld is %ld\n",val, result);	
	
	return 0;
}

// definition of factorial function
long int factorial(long int value)
{
	int i;
	long int res;
	res = 1;
	for(i = value ; i >= 1 ; i--)
	{
		res = res * i;
	}
	return res;
}
