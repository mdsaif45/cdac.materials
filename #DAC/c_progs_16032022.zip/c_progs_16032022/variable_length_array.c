// program for varaible lenth array
// introduced in C99 standard

#include<stdio.h>

int main()
{
	int n;
	printf("How much size for array: ");
	scanf("%d", &n);
	int arr[n];
	int i;
	
	// input array elements from user
	for(i=0;i<n;i++)
	{
		scanf("%d", &arr[i]);
	}
	printf("total size of array: %lu\n", sizeof arr);
	printf("You enter array elements: \n");
	// print array elements on screen
	for(i=0;i<n;i++)
		printf("%d ", arr[i]);
	return 0;
}
