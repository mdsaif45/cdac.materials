#include<stdio.h>

int main()
{
	int arr[]={1,2,3,4,5};
	int another_arr[5];
	int sum;int i;
	sum=0;
	for (i = 0 ; i<5;i++)
		scanf("%d", &another_arr[i]);
	
	for(i = 0 ; i < 5 ; i++)
	{
		sum += arr[i];
	}
	printf("sum is: %d\n", sum);
	
	sum = 0;
	for (i =0 ; i< 5; i++)
	{
		sum += another_arr[i];
	}
	printf("sum of another_arr is: %d\n", sum);
		
	
	return 0;
}
	
