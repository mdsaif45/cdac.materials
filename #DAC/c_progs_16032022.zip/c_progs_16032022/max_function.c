#include<stdio.h>

double max(double, double);
int main()
{
	double a, b;double max_val;
	a=18.0;
	b=15.1;
	
	max_val = max(a, b);
	printf("Max of %lf and %lf is %lf\n", a, b, max_val);
	return 0;
}

double max(double a, double a)
{
	/*
	if(a > b)
		return a;
	else
		return b;
	*/
	return a > b ? a : b;
}
	
