#include <stdio.h>
#include <stdlib.h>

int main() {

	FILE * myptr;
	myptr = fopen("myfile.txt", "w");
	if (myptr == NULL) {
		printf("opening file failed\n");
		exit(-1);
	}
	fprintf(myptr, "this will now go in file\n");

	fclose(myptr);
	return 0;
}


