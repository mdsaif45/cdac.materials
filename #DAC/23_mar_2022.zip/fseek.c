#include <stdio.h>
#include <stdlib.h>

int main() {

	FILE * myptr;
	myptr = fopen("myfile.txt", "r");
	if (myptr == NULL) {
		printf("opening file failed\n");
		exit(-1);
	}
	char c;
	fseek(myptr, 12, SEEK_SET);
	

	while ( (c = fgetc(myptr)) != EOF) {
		printf("%c", c);
	}

	fclose(myptr);
	return 0;
}


