#include <stdio.h>
#include <stdlib.h>

int main() {

	FILE * myptr;
	myptr = fopen("temp_dir/sample.txt", "r");
	if (myptr == NULL) {
		printf("opening file failed\n");
		exit(-1);
	}
	char name[50];
	fgets(name, 50 ,myptr);
	printf("%s\n", name);
	printf("stop\n");
	fclose(myptr);
	return 0;
}


