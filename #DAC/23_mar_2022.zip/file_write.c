#include <stdio.h>
#include <stdlib.h>

int main() {

	FILE * myptr;
	FILE * myptr2;
	char name[20];

	myptr = fopen("myfile.txt", "w");
	myptr2 = fopen("sample2.txt", "r");
	if (myptr == NULL) {
		printf("opening file failed\n");
		exit(-1);
	}
	fprintf(myptr, "the content has now changed!\n");
	fgets(name, 5, myptr2);

		
	printf("%s\n", name);
	fclose(myptr);
	fclose(myptr2);
	return 0;
}


