#include <stdio.h>
#include <stdlib.h>

int main() {

	FILE * myptr;
	FILE * myptr2;
	char name[20];

	myptr = fopen("myfile.txt", "a");
	if (myptr == NULL) {
		printf("opening file failed\n");
		exit(-1);
	}
	fprintf(myptr, "this is now also added to the file\n");

		
	fclose(myptr);
	return 0;
}


