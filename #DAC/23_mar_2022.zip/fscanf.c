#include <stdio.h>
#include <stdlib.h>

int main() {

	FILE * myptr;
	myptr = fopen("myfile.txt", "r");
	if (myptr == NULL) {
		printf("opening file failed\n");
		exit(-1);
	}
	char name[50];
	fscanf(myptr, "%[^\n]s", name);
	printf("%s", name);

	fclose(myptr);
	return 0;
}


