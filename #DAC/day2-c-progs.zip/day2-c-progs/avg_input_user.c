// Program to avg 3 numbers

#include<stdio.h>
#include<string.h>

// stdio: standard input output

int main()
{
	
	int num1, num2, num3;// int store values: -4,6,7,...
	
	float sum; // float store values example: 2.5, 3.65,..
	float avg;
	 
	sum = 0; 
	avg = 0;
	
 	printf("Enter num1: ");
 	scanf("%d", &num1); // scanf takes input from kayboard
 	// & means address of
 	
	sum = sum + num1;
	
	printf("Enter num2: ");
	scanf("%d", &num2); // read number 2
	sum = sum + num2;
	
	printf("Enter num3: ");
	scanf("%d", &num3); // input a decimal from keyboard, put in address of num3
	sum = sum + num3;
	
	// int_variable/3; is integer division: remove any fraction
	// flaat_variable/3 is float division
	avg = sum / 3;
	
	printf("Average is: %f\n", avg); 
	return 0;
}
	
