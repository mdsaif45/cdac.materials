// Program to add two numbers

#include<stdio.h>

int main()
{
	// create varibles
	// varaibles store contant values inside them
	// syntax to create: type variable_name
	// keep meaningful variable names
	
	int num1; // num1 is better name than a
	int num2; // num2 is better than b
	int sum; // sum is better than c
	sum = 0; // put 0 into sum, called initialization
	
	num1=5; // put 14 into num1
	num2=6;
	
	sum = num1 + num2;
	
	// print sum in decimal format
	printf("sum is: %d\n", sum); // %d means %decimal(0-9)
	return 0;
}
	
