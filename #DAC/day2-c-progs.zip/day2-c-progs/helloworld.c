// This is a comment, will not be compiled
// What is compilation: converting .c file to executable file(for eg a.out)
// who does compilation: gcc compiler
// what is a compiler: Software Which comverts high level Lang to low level lang
// computer does not understand .c file which is also a text file
// computer understand file having only bits: 0s and 1s, this file is excutable file
// To compile use command: gcc helloworld.c -> generates a.out
// To get customized executable name, use command:
//				gcc helloworld.c -o cdac
// To run cdac executable, use command: ./cdac
// . denotes current directory
// .. demotes parent directory

// what is a c program: C is a programming language
// other languages are: Java, c++, c#, php, python...
// what is a programming language: set of rules to write statements/steps to solve a problem.


#include<stdio.h>
// it a standard header file, which contains functions declerations
// what are functions: block of readymade code to do some specific task
// example printf, scanf, fgets,...

// what is main ?
// main is starting function: program exectutionn starts from here
// int main means main will returm some integer 
int main()
{
	printf("hello world, I am first c program, What can I do?\n");
	printf("hi, how are you? I am doing good");
	// printf is a function to print something on screen
	// here we want main to print a message: "hello world, how are you ?
	// \n is to go to next line
	
	return 0; // return from current function: main
	// will return 0 to calling program, 0 means SUCCESS, non 0 main problem
	
}
