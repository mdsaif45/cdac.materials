#include<stdio.h>

int main()
{
	printf("hello world, how can I help you ?\n");
	return 0;
}
