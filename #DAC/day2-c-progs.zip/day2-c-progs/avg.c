// Program to avg 3 numbers

#include<stdio.h>

int main()
{
	
	int num1, num2, num3;// int store values: -4,6,7,...
	
	float sum; // float store values example: 2.5, 3.65,..
	float avg;
	 
	sum = 0; 
	avg = 0;
	
	num1=5; 
	sum = sum + num1;
	
	num2=6;
	sum = sum + num2;
	
	num3=8;
	sum = sum + num3;
	
	// int_variable = int_variable/3; is integer division
	
	avg = sum / 3;
	
	printf("Average is: %f\n", avg); 
	return 0;
}
	
