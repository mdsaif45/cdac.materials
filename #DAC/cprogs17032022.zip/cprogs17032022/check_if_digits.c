#include<stdio.h>
#include<ctype.h>

int main()
{
	char ch='5';
	//printf("%d\n", isdigit(ch));
	/*
	if(isalpha(ch))
		printf("ch: %c is a alphabet\n", ch);
	else
		printf("ch: %c is NOT a alphabet\n", ch);
	*/
	
	// printf("%c %s\n", ch, isalpha(ch) ? "is an alphabet":"is not alphabet");
	printf("%c %s %s\n", ch, isalpha(ch) ? "is":"is NOT", "an alphabet");
	//printf("%c %s %s\n", ch,		   "is NOT", "an alphabet");
	return 0;
}
