#include<stdio.h>

int multiply(int, int);

int main()
{
	int m=5, n=7;int res;
	res = multiply(m, n);
	printf("%d * %d = %d\n", m, n, res);
	return 0;
}

// a*b = a + (a*(b-1))
int multiply(int a, int b)
{
	int ans;
	printf("a=%d, b=%d\n", a, b);
	// stopping condition
	if(b == 1)
	{
		ans = a;
		printf("Returning ans=%d\n", ans);
		return ans;
	}
	else
	{
		ans = a + multiply(a, b-1);
 		printf("Returning ans=%d\n", ans);
		return ans;
	}
}
		
