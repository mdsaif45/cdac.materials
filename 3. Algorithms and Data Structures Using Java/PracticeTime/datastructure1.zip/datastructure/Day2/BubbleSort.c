#include<stdio.h>
#define SIZE 5
#define SWAP(x,y,type) { type temp; temp=x; x=y; y=temp;}
void display_array_elements(int *p)
{
    int i;
    for(i=0;i<SIZE;i++)
        printf("%4d",p[i]);
}
void bubble_sort(int *p)
{
    int i,j;
    for(i=0;i<SIZE-1;i++) //for pass interation
    {
        for(j=0;j<SIZE-1-i;j++)
        {
            if(p[j] > p[j+1] )  //select 2 bubble elements and compare
                SWAP(p[j],p[j+1],int);
        }
    }
}

int main()
{
    int arr[]={7,1,15,6,3};
    printf("Before Sort state of an array is \n");
    display_array_elements(arr);
    
    bubble_sort(arr);
    
    printf("After Sort state of an array is \n");
    display_array_elements(arr);
}