#include<stdio.h>
#define SIZE 5
#define SWAP(x,y,type) { type temp; temp=x; x=y; y=temp;}
void display_array_elements(int *p)
{
    int i;
    for(i=0;i<SIZE;i++)
        printf("%4d",p[i]);
}
void selection_sort(int *p)
{
    int i,j;
    for(i=0;i<SIZE-1;i++)//select element
    {
        for(j=i+1;j<SIZE;j++) //compare with remaining elements
        {
            if(p[i] > p[j])
                SWAP(p[i],p[j],int);
        }//complettion of particular pass
    }
}

int main()
{
    int arr[]={7,1,15,6,3};
    printf("Before Sort state of an array is \n");
    display_array_elements(arr);
    
    selection_sort(arr);
    
    printf("After Sort state of an array is \n");
    display_array_elements(arr);
}