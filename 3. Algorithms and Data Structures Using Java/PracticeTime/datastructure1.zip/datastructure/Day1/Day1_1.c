#include<stdio.h>
/* Linear Search - Element will visited sequetialy and 
compared with key value to conclude element exist in collection */
#define SIZE 5
int linear_search_return_index(int *p,int key);
int * linear_search_return_add(int *p,int key);
int main()
{
    int arr[SIZE],key,index,*ptr;
    accept_array_elements(arr); //first element address is passed
    display_array_elements(arr);
    printf("Specify Key value to search \n");
    scanf("%d",&key);
    
    index = linear_search_return_index(arr,key);
    if(index == -1)
        printf("%d key is not present\n",key);
    else
        printf("%d key is present at %d index position\n",key,index);

    ptr = linear_search_return_add(arr,key);
    if(ptr ==NULL)
        printf("%d key is not present\n",key);
    else
        printf("%d is found at %d",key,ptr-arr);

}

void accept_array_elements(int p[5])//compiler ignores int p[5] and will consider  int *p
{
    int i;
    printf("Specify array elements \n");
    for(i=0;i<SIZE;i++)
    {
        scanf("%d",p+i);
    }
}

void display_array_elements(int p[5])//compiler ignores int p[5] and will consider  int *p
{
    int i;
    printf(" array elements are \n");
    for(i=0;i<SIZE;i++)
    {
        printf("%4d",*(p+i));
    }
}

int linear_search_return_index(int *p,int key)
{
    int i,comp=0;
    for(i=0;i<SIZE;i++)
    {
        if(p[i] == key)
        {
            comp++;
            return i;
        }
    }
    return -1;
}

int * linear_search_return_add(int *p,int key)
{
    int i,comp=0;
    for(i=0;i<SIZE;i++)
    {
        if(p[i] == key)
        {
            comp++;
            return p+i;
        }
    }
    return NULL;
}






