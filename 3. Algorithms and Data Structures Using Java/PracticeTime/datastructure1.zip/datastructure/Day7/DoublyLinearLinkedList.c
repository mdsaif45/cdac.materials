#include<stdio.h>
#include<stdlib.h>
typedef struct node
{
   struct node *prev;
   int  data;
   struct node *next;
}node_t; //self referential structure is a structure which has atleast one member as pointer which is pointing to self type

node_t *head=NULL;
node_t *tail=NULL;

node_t * create_node()
{
    node_t *temp;
    temp = (node_t *) malloc(sizeof(node_t));
    temp->next = NULL;
    temp->prev=NULL;
    return temp;
}
void add_element_at_first_position(int data)
{
    node_t *newnode ;
    //1. request memory at runtime for one node element
        newnode = create_node();
    //2. assign data inside node
        newnode->data = data;
    //3. attach node in linkedlist
        if(head == NULL && tail==NULL)//3.1 if list is empty
        {
            head = newnode; //3.1.1. attach node
            tail=newnode;
        }
        else//3.2 if list is ready
        {
           newnode->next = head;   //3.2.1 attach node
           head->prev=newnode;
           head = newnode;
        }
}
void add_element_at_last_position(int data)
{
}
void traverse_list()
{
    node_t *trav=head;
    if(head==NULL)
        printf("List is Empty!!!!\n");
    else
    {
        while(trav!=NULL)
        {
            printf("%d-->",trav->data);
            trav = trav->next;
        }

        trav=tail;
        while(trav!=NULL)
        {
            printf("%d-->",trav->data);
            trav = trav->prev;
        }
    }
}

int size()
{
    node_t *trav=head;
    int cnt=0;
    if(head==NULL)
        printf("List is Empty!!!!\n");
    else
    {
        while(trav!=NULL)
        {
            cnt++;
            trav = trav->next;
        }
    }
    return cnt;
}


void add_element_at_given_position(int data,int pos)
{
    node_t *newnode;
    node_t *trav=NULL;
    int p;
    if(pos==1)
        add_element_at_first_position(data);
    else if(pos==(size()+1))
        add_element_at_last_position(data);
    else
    {
        newnode = create_node();
        newnode->data = data;
        trav=head; p=1;
        while(p < pos-1)
        {
            trav=trav->next;
            p++;
        }//traverse till node nxt to which nn to be attached
        newnode->next = trav->next;
        trav->next = newnode;
    }
}
void  delete_element_from_last()
{
    node_t *temp;
    temp=tail;
    if(head==tail)
        {
            head=NULL;
            tail=NULL;
        }
    else
    {
        tail=tail->prev;
        tail->next=NULL;
    }
    free(temp);
    temp=NULL;
}
void delete_element_from_given_pos(int pos)
{
}
int main()
{
    int pos;
    add_element_at_first_position(11);
    add_element_at_first_position(22);
    add_element_at_first_position(33);
    add_element_at_first_position(44);
    add_element_at_first_position(55);
    traverse_list();
    add_element_at_last_position(66);
    printf("Specify position for new element\n");
    scanf("%d",&pos);
    if(pos<=0 || pos> (size()+1))
        printf("Invalid position \n");
    else
        add_element_at_given_position(40,pos);

    traverse_list_in_backward(head);

    delete_element_from_first();
    delete_element_from_last();
   
    printf("Specify position for new element\n");
    scanf("%d",&pos);
    if(pos<=0 || pos> size())
        printf("Invalid position \n");
    else
   
    delete_element_from_given_pos(pos);

    free_list();
}