#include<stdio.h>
#include<stdlib.h>
typedef struct node
{
   int  data;
   struct node *next;
}node_t; //self referential structure is a structure which has atleast one member as pointer which is pointing to self type

node_t *head=NULL;

node_t * create_node()
{
    node_t *temp;
    temp = (node_t *) malloc(sizeof(node_t));
    temp->next = NULL;
    return temp;
}
void add_element_at_first_position(int data)
{
    node_t *newnode,*trav ;
    //1. request memory at runtime for one node element
        newnode = create_node();
    //2. assign data inside node
        newnode->data = data;
    //3. attach node in linkedlist
        if(head == NULL)//3.1 if list is empty
        {
            head = newnode; //3.1.1. attach node
            newnode->next=head;
        }
        else//3.2 if list is ready
        {
           trav=head;
           while(trav->next!=head)
           {
               trav=trav->next;
           }
           newnode->next = head;   //3.2.1 attach node
           head = newnode;
           trav->next=head;
        }
}
void add_element_at_last_position(int data)
{
    node_t *newnode,*trav=NULL ;
    //1. request memory at runtime for one node element
        newnode = create_node();
    //2. assign data inside node
        newnode->data = data;
    //3. attach node in linkedlist
        if(head == NULL)//3.1 if list is empty
        {
            head = newnode; //3.1.1. attach node
            newnode->next = head;
        }
        else//3.2 if list is ready
        {
            trav=head;
            while(trav->next!=head)
            {
                trav = trav->next;
            }//traverse till last element
            trav->next = newnode;//attach nn next to present last node
            newnode->next=head;
        }
}
void traverse_list()
{
    node_t *trav=head;
    if(head==NULL)
        printf("List is Empty!!!!\n");
    else
    {
        do
        {
            printf("%d-->",trav->data);
            trav = trav->next;
        }while(trav!=head);
    }
}

int size()
{
    node_t *trav=head;
    int cnt=0;
    if(head==NULL)
        printf("List is Empty!!!!\n");
    else
    {
        do
        {
            cnt++;
            trav = trav->next;
        }while(trav!=head);
    }
    return cnt;
}

void add_element_at_given_position(int data,int pos)
{
    node_t *newnode;
    node_t *trav=NULL;
    int p;
    if(pos==1)
        add_element_at_first_position(data);
    else if(pos==(size()+1))
        add_element_at_last_position(data);
    else
    {
        newnode = create_node();
        newnode->data = data;
        trav=head; p=1;
        while(p < pos-1)
        {
            trav=trav->next;
            p++;
        }//traverse till node nxt to which nn to be attached
        newnode->next = trav->next;
        trav->next = newnode;
    }
}
void delete_element_from_first()
{
    node_t *temp,*trav;
    temp=head;
    if(head==head->next) //list has single node
    {
        head=NULL;
    }
    else //list has multiple node
        head=head->next;
    
    free(temp);
    temp=NULL;
}

void free_list()
{
    while(head!=NULL)
    {
        delete_element_from_first();
    }
}
void  delete_element_from_last()
{
    node_t *trav=head,*prev=NULL;
    while(trav->next!=head)
    {
        prev=trav;
        trav=trav->next;
    }
    if(prev == NULL) //single node in ll
        head = NULL;
    else    
        prev->next=head;
    
    free(trav);
    trav=NULL;
}
void delete_element_from_given_pos(int pos)
{
    node_t *trav=NULL,*temp=NULL;
    int p;
    if(pos==1)
        delete_element_from_first();
    else if(pos==size())
        delete_element_from_last();
    else
    {
        trav=head;
        p=1;
        while(p < pos-1)
        {
            trav=trav->next;
            p++;
        }
        temp = trav->next;
        trav->next = temp->next;
        free(temp);
        temp=NULL;
    }
}
int main()
{
    int pos;
    add_element_at_first_position(11);
    add_element_at_first_position(22);
    add_element_at_first_position(33);
    add_element_at_first_position(44);
    add_element_at_first_position(55);
    traverse_list();
    add_element_at_last_position(66);
    printf("Specify position for new element\n");
    scanf("%d",&pos);
    if(pos<=0 || pos> (size()+1))
        printf("Invalid position \n");
    else
        add_element_at_given_position(40,pos);

    traverse_list_in_backward(head);

    delete_element_from_first();
    delete_element_from_last();
   
    printf("Specify position for new element\n");
    scanf("%d",&pos);
    if(pos<=0 || pos> size())
        printf("Invalid position \n");
    else
   
    delete_element_from_given_pos(pos);

    free_list();
}