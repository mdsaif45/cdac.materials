#include<stdio.h>
#define TRUE 1
#define FALSE 0
#define SIZE 5

typedef int BOOL;
typedef int ELEMENT;

typedef struct
{
    ELEMENT eles[SIZE];
    int rear,front;
}QUEUE;

void init_queue(QUEUE *q)
{
    q->front = 0;
    q->rear = -1;
    for(int i=0;i<SIZE;i++)
    {
        q->eles[i] = -1;
    }
}

BOOL is_full(const QUEUE *q)
{
    //1. keep on adding element till size-1  none of ele is deleted 
    //2. keep on adding ele till size-1 and no. of eles we dele same no. eles are added back
    return (q->rear==SIZE-1 && q->front==0) || (q->rear==q->front-1)  ? TRUE : FALSE ;
}

void join_element(QUEUE *q,ELEMENT ele)
{
    if(q->rear==SIZE-1)
        q->rear=0;
    else    
        q->rear++; //manage rear position for new element
    
    q->eles[q->rear] = ele;//join element
}

BOOL is_empty(const QUEUE *q)
{
    //1. initial state of queue rear==-1
    //2. after performing combinations of operations
    return q->rear==-1   ? TRUE : FALSE; 
}

void leave_element(QUEUE *q)
{   
    q->eles[q->front] = -1;  //1. assume element is deleted
    //2. decide which will be next element at front
    if(q->rear==q->front) //latest ele which is got deleted was only ele in queue
    {
        q->rear=-1;
        q->front=0;
    }
    else
    {
        if(q->front==SIZE-1)
            q->front=0;
        else
            q->front++;              
    }
}
void traverse_queue(const QUEUE *q)
{
    for(int i=0;i<SIZE;i++)
    {
        printf("%4d",q->eles[i]);
    }
    printf("\t rear=%d front=%d",q->rear,q->front);
}

int main()
{
    QUEUE q1,q2,q3;
    init_queue(&q1);
    //write menu driven program to test application
}