#include<stdio.h>

typedef int BOOL;
typedef int ELEMENT;
#define TRUE 1
#define FALSE 0
#define SIZE 5

ELEMENT info[SIZE]; //actual stack of integers
int top=-1; //always retain the index of top most element
//before start performing operations on stack set initial state of top

typedef enum {EXIT,PUSHELEMENT,POPELEMENT,PEEKELEMENT} MENU;

MENU menu_choice()
{
    MENU mchoice;
    printf("\n0. Exit");
    printf("\n1. Push Element on Stack");
    printf("\n2. Pop Element From Stack");
    printf("\n3. Peek Retrieve ELEMENT FROM Stack");
    scanf("%d",&mchoice);
    return mchoice;
}

BOOL is_full()
{
    return top == SIZE-1 ? TRUE : FALSE ;
}//conclude current state of stack 

void push_element(ELEMENT *p)
{
    top++; //manage top position for new element
    info[top] = *p ;//push element

}

BOOL is_empty()
{
    //1. initially stack empty state
    return top == -1 ? TRUE : FALSE ;
}//conclude current state of stack 

ELEMENT peek_element()
{
    return info[top];   
}

void pop_element()
{
    //assume element on top location is deleted
    top--;//decide which element will be on top
}
void accept_element(ELEMENT *p)
{
    printf("Specify element to be pushed on stack\n");
    scanf("%d",p);
}

void display_element(const ELEMENT *p)
{
    printf("\n ELEMENT=%d",*p);
}
int main()
{
    MENU mchoice;
    ELEMENT ele;
    while((mchoice=menu_choice())!=EXIT)
    {
        switch(mchoice)
        {
            case PUSHELEMENT:
                           if(is_full())// 1.1 check if  stack is full
                            {
                                printf("Stack has reached to overflow state");
                            }    //1.1.1 show error as stack is reach to overflow state
                            else//1.2 stack is not full
                            {     
                                accept_element(&ele);//1.2.1.accept element from user to be pushed stack
                                push_element(&ele);//1.2.2 push element on stack
                            }
                            break;
            case POPELEMENT:
                            if(is_empty())//1.1 if stack is empty
                                printf("Stack has reached to underflow state !!!");//1.1.1 show error stack is empty
                            else //1.2 if stack is not empty
                                {
                                    ele = peek_element();//1.2.1 peek element
                                    display_element(&ele);//1.2.2 display peeked element    
                                    pop_element();          
                                }
                            break;
            case PEEKELEMENT:
                            if(is_empty())//1.1 if stack is empty
                                printf("Stack has reached to underflow state !!!");//1.1.1 show error stack is empty
                            else //1.2 if stack is not empty
                                {
                                    ele = peek_element();//1.2.1 peek element
                                    display_element(&ele);//1.2.2 display peeked element    
                                }
                            break;
        }
    }
}







