package LinkedLists.NthToLast;

public class Node {

  int val;
  Node next;

  public Node(int val) {
    this.val = val;
    this.next = null;
  }
}
