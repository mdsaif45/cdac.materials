-- write a procedure to fetch the data from emp table and looking at sal
-- sort them into differnt categories and insert them in result table.

DROP PROCEDURE IF EXISTS sp_empcategory;
DELIMITER $$
CREATE PROCEDURE sp_empcategory()
BEGIN
DECLARE v_empno INT DEFAULT 0;
DECLARE v_sal DOUBLE DEFAULT 0.0;
DECLARE v_category CHAR(15);
DECLARE v_flag INT DEFAULT 0;

DECLARE v_cur CURSOR FOR SELECT empno,sal FROM emp;

DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_flag=1;

OPEN v_cur;

label:LOOP
    FETCH v_cur INTO v_empno,v_sal;

    IF v_flag = 1 THEN
    LEAVE label;
    END IF;

    CASE
    WHEN v_sal<1500 THEN
        SET v_category = 'POOR';
    WHEN v_sal BETWEEN 1500 AND 2500 THEN
        SET v_category = 'MIDDLE';
    ELSE
        SET v_category = 'RICH';
    END CASE;

    INSERT INTO result VALUES(v_empno,v_category);
END LOOP;

CLOSE v_cur;
END;
$$
DELIMITER ;

-- SOURCE path_of_PSM12.sql_file
-- CALL sp_empcategory();
