-- write a procedure to print hello world on terminal

DROP PROCEDURE IF EXISTS sp_hello;

DELIMITER $$
CREATE PROCEDURE sp_hello()
BEGIN

SELECT "Hello World" AS hello;

END;
$$

DELIMITER ;

-- SOURCE path_of_PSM01.sql_file
-- CALL sp_hello();