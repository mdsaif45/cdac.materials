-- write a procedure to calculate area of rectangle
-- pass the values through terminal
-- insert the area into result table.

DROP PROCEDURE IF EXISTS sp_rectarea;
DELIMITER $$
CREATE PROCEDURE sp_rectarea(IN p_len INT,IN p_bre INT)
BEGIN
DECLARE v_area DOUBLE;

-- SET v_area = p_len * p_bre;
SELECT p_len*p_bre INTO v_area;

INSERT INTO result VALUES(v_area,"Rect Area");

END;
$$
DELIMITER ;

-- SOURCE path to the psm04.sql file
-- CALL sp_rectarea(5,6);