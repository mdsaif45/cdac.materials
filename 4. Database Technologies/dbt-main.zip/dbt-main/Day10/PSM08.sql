-- write a procedure to sum all even numbers in a given range

DROP PROCEDURE IF EXISTS sp_sum_even;

DELIMITER $$
CREATE PROCEDURE sp_sum_even(IN p_low INT,IN p_high INT)
BEGIN
DECLARE v_sum INT DEFAULT 0;

    WHILE p_low<=p_high DO

    IF p_low%2=0 THEN
        SET v_sum=v_sum+p_low;
    END IF;
        SET p_low = p_low + 1;
    END WHILE;

    INSERT INTO result VALUES(v_sum,"sum of even nos");
END;

$$
DELIMITER ;

-- SOURCE path to the psm08.sql file
-- CALL sp_sum_even(1,10);
