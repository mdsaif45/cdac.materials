-- write a function for TITLE case
-- SUNBEAM -- TITLE("SUNBEAM") --> Sunbeam
-- rohan -- TITLE('rohan') --> Rohan

DROP FUNCTION IF EXISTS TITLE;
DELIMITER $$

CREATE FUNCTION TITLE(p_name CHAR(40))
RETURNS CHAR(40)
DETERMINISTIC
BEGIN
DECLARE v_res CHAR(40);
DECLARE v_first CHAR(1) DEFAULT LEFT(p_name,1);
DECLARE v_rest CHAR(40) DEFAULT SUBSTRING(p_name,2);
SET v_res = CONCAT(UPPER(v_first),LOWER(v_rest));

RETURN v_res;
END;
$$
DELIMITER ;

-- SOURCE path_of_PSM13.sql_file
