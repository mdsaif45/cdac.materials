-- write a procedure to check whetehr a given number is prime number.

DROP PROCEDURE IF EXISTS sp_prime;
DELIMITER $$
CREATE PROCEDURE sp_prime(IN p_num INT)
BEGIN
DECLARE v_num INT DEFAULT 2;
DECLARE v_status CHAR(10);

    prime:LOOP
        IF v_num = p_num THEN
            LEAVE prime;
        END IF;
        IF p_num%v_num=0 THEN
            SET v_status = "NOT PRIME";
            LEAVE prime;
        END IF;
        SET v_num = v_num + 1;
    END LOOP;

    IF v_num = p_num THEN
        SET v_status = "PRIME"; 
    END IF;

    SELECT CONCAT(p_num," is a ",v_status) AS status; 

END;
$$
DELIMITER ;

-- SOURCE path to the psm09sql file
-- CALL sp_prime(7);