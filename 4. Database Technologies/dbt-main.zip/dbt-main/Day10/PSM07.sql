-- write a procedure to check whether a given number is even or odd.

DROP PROCEDURE IF EXISTS sp_even_odd;
DELIMITER $$
CREATE PROCEDURE sp_even_odd(IN p_num INT)
BEGIN
DECLARE v_status CHAR(25);
    
    IF p_num%2=0 THEN
        SET v_status = 'is a Even number';
    ELSE
        SET v_status = 'is a Odd number';
    END IF;

    SELECT CONCAT(p_num,'-',v_status) AS status;
    INSERT INTO result VALUES(p_num,v_status);
END;
$$
DELIMITER ;


-- SOURCE path to the psm07.sql file
-- CALL sp_even_odd(5);