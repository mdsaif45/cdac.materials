-- Write a procedure to calculate area of circle display on terminal

DROP PROCEDURE IF EXISTS sp_circlearea;

DELIMITER $$
CREATE PROCEDURE sp_circlearea()
BEGIN
DECLARE v_radius INT DEFAULT 7;
DECLARE v_area DOUBLE;

 SET v_area = 3.14 * v_radius * v_radius;

 SELECT v_radius AS Radius, v_area AS Area;

END;
$$

DELIMITER ;

-- SOURCE path to the psm03.sql file
-- CALL sp_circlearea();