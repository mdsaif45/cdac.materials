-- Write a procedure to take 1 INOUT parameter
-- Calculate a square of a number.

DROP PROCEDURE IF EXISTS sp_square1;
DELIMITER $$
CREATE PROCEDURE sp_square1(INOUT p_sq INT)
BEGIN
SET p_sq = p_sq * p_sq;
END;
$$
DELIMITER ;

-- SOURCE path to the psm06.sql file
-- SET @res1=9;
-- CALL sp_square1(@res1);
-- SELECT @res1;