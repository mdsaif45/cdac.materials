-- write a procedure to insert a book into books table.
-- If their is error dont stop the procedure execution handle it and display proper msg.

DROP PROCEDURE IF EXISTS sp_addbook1;
DELIMITER $$
CREATE PROCEDURE sp_addbook1(IN p_id INT,IN p_name CHAR(30),IN p_price DECIMAL(6,2))
BEGIN
DECLARE v_status CHAR(20) DEFAULT 'BOOK INSERTED';

DECLARE CONTINUE HANDLER FOR 1062 SET v_status = 'Book Insert Failed';

INSERT INTO books(id,name,price) VALUES (p_id,p_name,p_price);
SELECT v_status AS msg;

END;
$$
DELIMITER ;

-- SOURCE path to the psm11.sql file
-- CALL sp_addbook1(give parameters);