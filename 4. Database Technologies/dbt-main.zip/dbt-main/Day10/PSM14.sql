-- write a function to calculate age/exp in terms of years and month
-- do the below setting before importing the NOT deterministic function
-- SET GLOBAL @@log_bin_trust_function_creators=1;

DROP FUNCTION IF EXISTS EXPERIENCE;
DELIMITER $$
CREATE FUNCTION EXPERIENCE(p_date DATE)
RETURNS CHAR(40)
NOT DETERMINISTIC
BEGIN
    DECLARE v_res CHAR(40);
    DECLARE v_year INT;
    DECLARE v_month INT;
    SET v_year = TIMESTAMPDIFF(YEAR,p_date,NOW());
    SET v_month = TIMESTAMPDIFF(MONTH,p_date,NOW()) % 12;
    SET v_res = CONCAT(v_year,' y ',v_month,' m ');
    RETURN v_res;
END;
$$
DELIMITER ;

-- SOURCE path_of_PSM13.sql_file