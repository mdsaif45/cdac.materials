-- Write a procedure to take 1 IN and 1 OUT parameter
-- Calculate a square of a number.

DROP PROCEDURE IF EXISTS sp_square;
DELIMITER $$
CREATE PROCEDURE sp_square(IN p_num INT, OUT p_sq INT)
BEGIN
  SET p_sq = p_num*p_num;
END;
$$
DELIMITER ;

-- SOURCE path to the psm05.sql file
-- CALL sp_square(7,@res);
-- SELECT @res;