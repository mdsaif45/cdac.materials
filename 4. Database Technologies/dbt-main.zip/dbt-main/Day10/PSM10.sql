-- write a procedure to insert a book into books table.
-- If their is error stop the execution handle it and display proper msg.
DROP PROCEDURE IF EXISTS sp_addbook;
DELIMITER $$
CREATE PROCEDURE sp_addbook(IN p_id INT,IN p_name CHAR(30),IN p_price DECIMAL(6,2))
BEGIN

DECLARE EXIT HANDLER FOR 1062 SELECT 'Book insert Failed.' AS error;

INSERT INTO books(id,name,price) VALUES(p_id,p_name,p_price);

END;
$$
DELIMITER ;

-- SOURCE path to the psm10.sql file
-- CALL sp_addbook(give parameters);