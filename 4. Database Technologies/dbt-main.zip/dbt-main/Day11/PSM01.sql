-- write a trigger to update balance in accounts table on insert in transaction table.

DROP TRIGGER IF EXISTS update_balance;
DELIMITER $$
CREATE TRIGGER update_balance
AFTER INSERT ON transactions
FOR EACH ROW
BEGIN

IF NEW.type='Deposit' THEN
    UPDATE accounts SET balance = balance + NEW.amount WHERE id=NEW.acc_id;
    ELSE
    UPDATE accounts SET balance = balance - NEW.amount WHERE id=NEW.acc_id;
END IF;

END;
$$
DELIMITER ;