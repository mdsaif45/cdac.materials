package in.cdac;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBtwebApplicationTests {

	@Test
	void contextLoads() {
	}

}
