package in.cdac;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBtjpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBtjpaApplication.class, args);
	}

}
