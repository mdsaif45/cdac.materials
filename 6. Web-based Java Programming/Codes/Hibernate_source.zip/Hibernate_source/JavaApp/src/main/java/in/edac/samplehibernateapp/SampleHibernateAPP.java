/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package in.edac.samplehibernateapp;

import java.io.File;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

/**
 *
 * @author CDAC
 */
public class SampleHibernateAPP {

    public static void main(String[] args) {
        
        Student std = new Student();
        std.setName("abcd");
        std.setEmail("abcd@cdac.in");
        std.setAge(24);
        std.setMobile("9712813111");  
                
        SessionFactory sf = new Configuration().configure()
                .buildSessionFactory();
        Session sess = sf.openSession();
        
        Transaction trns = sess.beginTransaction();
        sess.save(std);   
        trns.commit();
                
    }
}
