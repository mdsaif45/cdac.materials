/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package in.cdac.hibernatewebapp.db;

import in.cdac.hibernatewebapp.Employee;
import in.cdac.hibernatewebapp.HibernateUtil;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

/**
 *
 * @author CDAC
 */
public class DBOperations 
{
    SessionFactory sf = null;
    Session session = null;
    Transaction tsn = null;
    
    public DBOperations(){
        sf = HibernateUtil.getSessionFactory();
    }
    
    public void saveEmployeeDetails(Employee obj)
    {
        try {
            session = sf.openSession();
            tsn = session.beginTransaction();
            session.save(obj);
            tsn.commit();
        } catch (HibernateException hm) {
            hm.printStackTrace();
        } finally {
            if (session != null) {
                session.close();
            }
        }    
    }
    
    public void getAllEmployees() {
        List<Employee> emp_list = null;
        try {
            session = sf.openSession();
            emp_list = session.createQuery("from Employee", Employee.class).list();
            for (Employee e : emp_list) {
                System.out.println(e.getEmpID() + "==" + e.getName());
            }
        } catch (HibernateException hm) {
            hm.printStackTrace();
        } finally {
            if (session != null) {
                session.close();
            }
        }
    }
    
    public void updateEmployeeDetails(Employee updatedEmp) {
        try {
            session = sf.openSession();
            tsn = session.beginTransaction();
            session.update(updatedEmp);
            tsn.commit();
        } catch (HibernateException hm) {
            hm.printStackTrace();
        } finally {
            if (session != null) {
                session.close();
            }
        }
    }
    
    public void deleteEmployeeDetails(int empID) {
        Employee tobeDeleted;
        try {
            session = sf.openSession();
            tsn = session.beginTransaction();
            tobeDeleted = session.get(Employee.class, empID);
            session.delete(tobeDeleted);
            tsn.commit();
        } catch (HibernateException hm) {
            hm.printStackTrace();
        } finally {
            if (session != null) {
                session.close();
            }
        }
    }
    
    
}
