/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package in.cdac.hibernatewebapp;

import in.cdac.hibernatewebapp.db.DBOperations;

/**
 *
 * @author CDAC
 */
public class Test {
    public static void main(String[] args) {
//        Employee ee = new Employee();
//        ee.setEmpID(2);
//        ee.setName("Employee3");
//        ee.setEmail("employee3@cdac.in");
//        
        DBOperations dop = new DBOperations();
//        dop.saveEmployeeDetails(ee);
//        
//        ee = new Employee();
//        ee.setName("EMP5");
//        ee.setEmail("emp5@cdac.in");
//         dop.saveEmployeeDetails(ee);
       // dop.getAllEmployees();
      // dop.updateEmployeeDetails(ee);
      
      dop.deleteEmployeeDetails(3);
       
    }
}
