import java.sql.*;
public class User {
     private String uname;
     private String password;
   
    public String getUname() {
        return uname;
    }

    public void setUname(String uname) {
        this.uname = uname;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
  
    public boolean validate() {
        
        
        DBConnection dbcon = new DBConnection();
        Connection con = dbcon.getDBConnection();
        
        boolean flag = false;
        
        try{
        String query = "select * from users";
        Statement st = con.createStatement();
        ResultSet rs = st.executeQuery(query);
        
        
        while(rs.next()) {
        
        if(uname.equalsIgnoreCase(rs.getString(1)) && password.equals(rs.getString(2))){
            flag = true;
            break;
        }
        }
        con.close();
        }catch(Exception e){ }
        
       if(flag==true) // if (flag)
           return true;
       else
           return false;
}
}
