/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package in.cdac.hibernatewebapp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;

/**
 *
 * @author CDAC
 */

@Entity
public class UserLoginInfo {    
    @Id
    @Column(name="email_id")
    private String email;
    private String password;

    @OneToOne    
    @MapsId
    @JoinColumn(name="email_id")
    private UserDetails uds;

    public UserDetails getUds() {
        return uds;
    }

    public void setUds(UserDetails uds) {
        this.uds = uds;
    }
    
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
