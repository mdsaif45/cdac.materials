/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package in.cdac.hibernatewebapp;

import java.util.ArrayList;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

/**
 *
 * @author CDAC
 */
public class Test2 {

    SessionFactory sf = null;
    Session session = null;

    public Test2() {
        sf = HibernateUtil.getSessionFactory();
    }
    
    
    
    

    public void saveStudentDetails1() {
        Transaction tns;
        session = sf.openSession();
        tns = session.beginTransaction();

        UserDetails st = new UserDetails();
        st.setName("abc");
        st.setMobile("1234567890");
        st.setEmail("abc@cdac.in");

        
        UserLoginInfo ulinfo = new UserLoginInfo();
        ulinfo.setPassword("abc@123");
        ulinfo.setUds(st);
        
        session.save(st);
        session.save(ulinfo);        

        tns.commit();
    }
    
     public void saveStudentDetails2() {
        Transaction tns;
        session = sf.openSession();
        tns = session.beginTransaction();

        UserDetails st = new UserDetails();
        st.setName("abc");
        st.setMobile("1234567890");
        st.setEmail("abc@cdac.in");
                
        Books bk = new Books();
        bk.setName("Java");
        bk.setAuthor("ABC");
        bk.setStd(st);
        
        Books bk1 = new Books();
        bk1.setName("HTML");
        bk1.setAuthor("DEF");
        bk1.setStd(st);
        
        st.getBk().add(bk);
        st.getBk().add(bk1);
        
        session.save(st);
        session.save(bk);
        session.save(bk1);
        

        UserDetails uds = session.get(UserDetails.class, "abc@cdac.in");
        List<Books> ls = uds.getBk();     
//        for(Books bk1 : ls){
//            System.out.println("=="+bk1.getName());
//        }      

        tns.commit();
    }
    
    
    public void saveStudentDetails3() {
        Transaction tns;
        session = sf.openSession();
        tns = session.beginTransaction();

        UserDetails st = new UserDetails();
        st.setName("abc");
        st.setMobile("1234567890");
        st.setEmail("abc@cdac.in");
                
        Books bk = new Books();
        bk.setName("Java");
        bk.setAuthor("ABC");
        //bk.getUserList().add(st);
        
        Books bk1 = new Books();
        bk1.setName("HTML");
        bk1.setAuthor("DEF");
        //bk.getUserList().add(st);
        
        st.getBk().add(bk);
        st.getBk().add(bk1);
        
        session.save(st);
        session.save(bk);
        session.save(bk1);       
         

        tns.commit();
    }

    public static void main(String[] args) {
        Test2 t = new Test2();
        //t.saveStudentDetails1(); //OneToOne
        t.saveStudentDetails2(); //OneToMany
       // t.saveStudentDetails3(); //ManyToMany
    }
}
