/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package in.cdac.hibernatewebapp;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

/**
 *
 * @author CDAC
 */
@Entity
public class UserDetails {
    private String name;
    @Id
    @Column(name="email_id")
    private String email;
    private String mobile;

    @OneToOne(mappedBy = "uds")
    private UserLoginInfo ulinfo;
        
    @OneToMany(mappedBy = "std")
    //@OneToMany
    private List<Books> bk = new ArrayList<Books>();

    public List<Books> getBk() {
        return bk;
    }

    public void setBk(List<Books> bk) {
        this.bk = bk;
    }
           


    public UserLoginInfo getUlinfo() {
        return ulinfo;
    }

    public void setUlinfo(UserLoginInfo ulinfo) {
        this.ulinfo = ulinfo;
    }
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }
    
}
