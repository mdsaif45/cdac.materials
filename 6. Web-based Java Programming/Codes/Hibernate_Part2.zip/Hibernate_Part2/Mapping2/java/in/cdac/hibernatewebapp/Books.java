/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package in.cdac.hibernatewebapp;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import org.hibernate.annotations.ManyToAny;

/**
 *
 * @author CDAC
 */
@Entity
public class Books {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int bookid;
    private String name;
    private String author;    
   
    
    @ManyToOne
    private UserDetails std;

    public UserDetails getStd() {
        return std;
    }

    public void setStd(UserDetails std) {
        this.std = std;
    }
    
    
//    @ManyToMany(mappedBy = "bk")
//    private List<UserDetails> userList = new ArrayList<UserDetails>();
//
//    public List<UserDetails> getUserList() {
//        return userList;
//    }
//
//    public void setUserList(List<UserDetails> userList) {
//        this.userList = userList;
//    }
    
    public int getBookid() {
        return bookid;
    }

    public void setBookid(int bookid) {
        this.bookid = bookid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }
        
    
    
}
