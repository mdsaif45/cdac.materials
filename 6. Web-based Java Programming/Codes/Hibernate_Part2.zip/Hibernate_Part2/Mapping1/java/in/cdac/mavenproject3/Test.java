/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package in.cdac.mavenproject3;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

/**
 *
 * @author CDAC
 */
public class Test {
    
    SessionFactory sf = null;
    Session session = null;
    public Test(){
        sf = HibernateUtil.getSessionFactory();
    }
    
    public void saveStudentDetails(){
        Transaction tns;
        session = sf.openSession();        
        tns = session.beginTransaction();
                 
        Address ads = new Address();
        ads.setHno("Hno:2");
        ads.setState("TS");
        ads.setCountry("IN");
        
        Student std = new Student();
        std.setName("abc");
        std.setEmail("abc@cdac.in");
        std.setMobile("1234567890");
        std.setAddress(ads);
        
        session.save(ads);
        session.save(std);                                                                
        
        tns.commit();
//        
//        Student s = session.get(Student.class, 1);
//        Address a = session.get(Address.class, 1);
//        System.out.println("=="+a.getHno());
//        System.out.println("=="+a.getStd().getEmail());
//        System.out.println(""+s.getAddress().getHno());
        session.close();
    }
    
    
    public static void main(String[] args) {       
        Test t = new Test();
        t.saveStudentDetails();                      
        
    }
            
}
